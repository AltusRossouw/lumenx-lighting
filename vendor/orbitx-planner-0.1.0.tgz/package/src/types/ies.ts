export interface IESProfile {
  id: string
  productSlug: string
  productName: string
  variantLabel: string
  url: string
  lumens?: number | null
  beamAngle?: number | null
}
