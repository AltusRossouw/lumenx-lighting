declare module 'three/examples/jsm/loaders/IESLoader.js' {
  import { DataTexture, Loader, LoadingManager } from 'three'

  export class IESLoader extends Loader<DataTexture> {
    constructor(manager?: LoadingManager)
    load(
      url: string,
      onLoad: (texture: DataTexture) => void,
      onProgress?: (event: ProgressEvent<EventTarget>) => void,
      onError?: (event: unknown) => void
    ): DataTexture
  }
}
