/**
 * OrbitX Lighting Planner - Project Storage Hook
 * 
 * Provides IndexedDB-based persistence for lighting projects:
 * - Save projects to browser storage
 * - Load projects from storage
 * - List all saved projects
 * - Delete projects
 * - Auto-save with debounce
 */

'use client'

import { useState, useCallback, useEffect, useRef } from 'react'
import { get, set, del, keys, values, createStore, UseStore } from 'idb-keyval'
import { usePlannerStore } from '../stores/plannerStore'
import type { Project, ProjectListItem, RoomConfig, LuminaireInstance } from '../lib/photometry/types'

// =============================================================================
// Constants
// =============================================================================

const DB_NAME = 'orbitx-planner'
const STORE_NAME = 'projects'
const AUTO_SAVE_DELAY = 3000 // 3 seconds debounce

// Custom IndexedDB store
let customStore: UseStore | null = null

function getStore(): UseStore {
  if (!customStore) {
    customStore = createStore(DB_NAME, STORE_NAME)
  }
  return customStore
}

// =============================================================================
// Types
// =============================================================================

interface UseProjectStorageReturn {
  // State
  projects: ProjectListItem[]
  isLoading: boolean
  isSaving: boolean
  error: string | null
  lastSaved: Date | null
  
  // Actions
  saveProject: (name?: string, generateThumbnail?: () => Promise<string | null>) => Promise<string>
  loadProject: (id: string) => Promise<void>
  deleteProject: (id: string) => Promise<void>
  listProjects: () => Promise<ProjectListItem[]>
  duplicateProject: (id: string) => Promise<string>
  exportProjectJSON: (id?: string) => Promise<string>
  importProjectJSON: (json: string) => Promise<void>
}

// =============================================================================
// Helper Functions
// =============================================================================

function generateId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`
}

function formatRoomDimensions(room: RoomConfig): string {
  return `${room.width}m × ${room.length}m × ${room.height}m`
}

function createProjectListItem(project: Project): ProjectListItem {
  return {
    id: project.id,
    name: project.name,
    updatedAt: project.updatedAt,
    luminaireCount: project.luminaires.length,
    roomDimensions: formatRoomDimensions(project.room),
    thumbnail: project.thumbnail
  }
}

// =============================================================================
// Hook Implementation
// =============================================================================

export function useProjectStorage(): UseProjectStorageReturn {
  const [projects, setProjects] = useState<ProjectListItem[]>([])
  const [isLoading, setIsLoading] = useState(false)
  const [isSaving, setIsSaving] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [lastSaved, setLastSaved] = useState<Date | null>(null)
  
  // Store selectors
  const projectId = usePlannerStore(s => s.projectId)
  const projectName = usePlannerStore(s => s.projectName)
  const room = usePlannerStore(s => s.room)
  const luminaires = usePlannerStore(s => s.luminaires)
  const activityType = usePlannerStore(s => s.activityType)
  const results = usePlannerStore(s => s.results)
  const loadProjectToStore = usePlannerStore(s => s.loadProject)
  const markClean = usePlannerStore(s => s.markClean)
  
  /**
   * Load the list of all saved projects
   */
  const listProjects = useCallback(async (): Promise<ProjectListItem[]> => {
    try {
      setIsLoading(true)
      setError(null)
      
      const store = getStore()
      const allProjects = await values<Project>(store)
      
      // Sort by updatedAt descending (most recent first)
      const sorted = allProjects
        .sort((a, b) => new Date(b.updatedAt).getTime() - new Date(a.updatedAt).getTime())
        .map(createProjectListItem)
      
      setProjects(sorted)
      return sorted
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to list projects'
      setError(message)
      console.error('Error listing projects:', err)
      return []
    } finally {
      setIsLoading(false)
    }
  }, [])
  
  /**
   * Save the current project state
   */
  const saveProject = useCallback(async (
    name?: string,
    generateThumbnail?: () => Promise<string | null>
  ): Promise<string> => {
    try {
      setIsSaving(true)
      setError(null)
      
      const store = getStore()
      const now = new Date().toISOString()
      const id = projectId || generateId()
      
      // Generate thumbnail if function provided
      let thumbnail: string | undefined
      if (generateThumbnail) {
        try {
          const thumb = await generateThumbnail()
          if (thumb) thumbnail = thumb
        } catch (e) {
          console.warn('Failed to generate thumbnail:', e)
        }
      }
      
      // Get unique IES profile IDs
      const iesProfileIds = Array.from(new Set(luminaires.map(l => l.iesProfileId)))
      
      const project: Project = {
        id,
        name: name || projectName || 'Untitled Project',
        createdAt: projectId ? (await get<Project>(projectId, store))?.createdAt || now : now,
        updatedAt: now,
        room,
        luminaires,
        activityType,
        iesProfileIds,
        lastResults: results || undefined,
        thumbnail
      }
      
      await set(id, project, store)
      
      // Update store with new project ID if it was new
      if (!projectId) {
        usePlannerStore.setState({ projectId: id })
      }
      
      markClean()
      setLastSaved(new Date())
      
      // Refresh project list
      await listProjects()
      
      return id
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to save project'
      setError(message)
      console.error('Error saving project:', err)
      throw new Error(message)
    } finally {
      setIsSaving(false)
    }
  }, [projectId, projectName, room, luminaires, activityType, results, markClean, listProjects])
  
  /**
   * Load a project by ID
   */
  const loadProject = useCallback(async (id: string): Promise<void> => {
    try {
      setIsLoading(true)
      setError(null)
      
      const store = getStore()
      const project = await get<Project>(id, store)
      
      if (!project) {
        throw new Error(`Project not found: ${id}`)
      }
      
      loadProjectToStore(project)
      setLastSaved(new Date(project.updatedAt))
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load project'
      setError(message)
      console.error('Error loading project:', err)
      throw new Error(message)
    } finally {
      setIsLoading(false)
    }
  }, [loadProjectToStore])
  
  /**
   * Delete a project by ID
   */
  const deleteProject = useCallback(async (id: string): Promise<void> => {
    try {
      setIsLoading(true)
      setError(null)
      
      const store = getStore()
      await del(id, store)
      
      // Refresh project list
      await listProjects()
      
      // If we deleted the currently loaded project, clear the ID
      if (projectId === id) {
        usePlannerStore.setState({ projectId: null })
      }
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to delete project'
      setError(message)
      console.error('Error deleting project:', err)
      throw new Error(message)
    } finally {
      setIsLoading(false)
    }
  }, [projectId, listProjects])
  
  /**
   * Duplicate a project
   */
  const duplicateProject = useCallback(async (id: string): Promise<string> => {
    try {
      setIsLoading(true)
      setError(null)
      
      const store = getStore()
      const original = await get<Project>(id, store)
      
      if (!original) {
        throw new Error(`Project not found: ${id}`)
      }
      
      const now = new Date().toISOString()
      const newId = generateId()
      
      const duplicate: Project = {
        ...original,
        id: newId,
        name: `${original.name} (Copy)`,
        createdAt: now,
        updatedAt: now
      }
      
      await set(newId, duplicate, store)
      
      // Refresh project list
      await listProjects()
      
      return newId
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to duplicate project'
      setError(message)
      console.error('Error duplicating project:', err)
      throw new Error(message)
    } finally {
      setIsLoading(false)
    }
  }, [listProjects])
  
  /**
   * Export project as JSON string
   */
  const exportProjectJSON = useCallback(async (id?: string): Promise<string> => {
    try {
      let project: Project
      
      if (id) {
        const store = getStore()
        const stored = await get<Project>(id, store)
        if (!stored) {
          throw new Error(`Project not found: ${id}`)
        }
        project = stored
      } else {
        // Export current state
        const now = new Date().toISOString()
        const iesProfileIds = Array.from(new Set(luminaires.map(l => l.iesProfileId)))
        
        project = {
          id: projectId || generateId(),
          name: projectName || 'Untitled Project',
          createdAt: now,
          updatedAt: now,
          room,
          luminaires,
          activityType,
          iesProfileIds,
          lastResults: results || undefined
        }
      }
      
      // Remove thumbnail from export to reduce file size
      const { thumbnail, ...exportData } = project
      
      return JSON.stringify(exportData, null, 2)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to export project'
      setError(message)
      throw new Error(message)
    }
  }, [projectId, projectName, room, luminaires, activityType, results])
  
  /**
   * Import project from JSON string
   */
  const importProjectJSON = useCallback(async (json: string): Promise<void> => {
    try {
      setIsLoading(true)
      setError(null)
      
      const data = JSON.parse(json) as Partial<Project>
      
      // Validate required fields
      if (!data.room || !Array.isArray(data.luminaires)) {
        throw new Error('Invalid project data: missing room or luminaires')
      }
      
      // Generate new ID and timestamps
      const now = new Date().toISOString()
      const project: Project = {
        id: generateId(),
        name: data.name || 'Imported Project',
        description: data.description,
        createdAt: now,
        updatedAt: now,
        room: data.room,
        luminaires: data.luminaires,
        activityType: data.activityType || 'office-general',
        iesProfileIds: data.iesProfileIds || [],
        notes: data.notes
      }
      
      // Save to IndexedDB
      const store = getStore()
      await set(project.id, project, store)
      
      // Load the imported project
      loadProjectToStore(project)
      setLastSaved(new Date())
      
      // Refresh project list
      await listProjects()
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to import project'
      setError(message)
      console.error('Error importing project:', err)
      throw new Error(message)
    } finally {
      setIsLoading(false)
    }
  }, [loadProjectToStore, listProjects])
  
  // Load project list on mount
  useEffect(() => {
    listProjects()
  }, [listProjects])
  
  return {
    projects,
    isLoading,
    isSaving,
    error,
    lastSaved,
    saveProject,
    loadProject,
    deleteProject,
    listProjects,
    duplicateProject,
    exportProjectJSON,
    importProjectJSON
  }
}

// =============================================================================
// Auto-Save Hook
// =============================================================================

interface UseAutoSaveOptions {
  enabled?: boolean
  delay?: number
  generateThumbnail?: () => Promise<string | null>
}

export function useAutoSave(options: UseAutoSaveOptions = {}) {
  const { enabled = true, delay = AUTO_SAVE_DELAY, generateThumbnail } = options
  
  const { saveProject, isSaving, lastSaved } = useProjectStorage()
  
  const projectId = usePlannerStore(s => s.projectId)
  const isDirty = usePlannerStore(s => s.isDirty)
  
  const saveTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  
  // Auto-save when dirty
  useEffect(() => {
    if (!enabled || !isDirty || !projectId) return
    
    // Clear existing timeout
    if (saveTimeoutRef.current) {
      clearTimeout(saveTimeoutRef.current)
    }
    
    // Set new timeout
    saveTimeoutRef.current = setTimeout(async () => {
      try {
        await saveProject(undefined, generateThumbnail)
      } catch (err) {
        console.error('Auto-save failed:', err)
      }
    }, delay)
    
    return () => {
      if (saveTimeoutRef.current) {
        clearTimeout(saveTimeoutRef.current)
      }
    }
  }, [enabled, isDirty, projectId, delay, saveProject, generateThumbnail])
  
  return {
    isSaving,
    lastSaved
  }
}

export default useProjectStorage
