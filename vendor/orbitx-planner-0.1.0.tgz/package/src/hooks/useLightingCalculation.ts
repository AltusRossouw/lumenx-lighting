/**
 * OrbitX Lighting Planner - Calculation Hook
 *
 * React hook that manages the illuminance calculation. It uses a Web Worker for
 * background calculation when one can be created, and transparently falls back
 * to a synchronous, same-thread calculation (via `runCalculation`) otherwise —
 * e.g. when the bundler can't provide a worker or `new Worker` fails.
 *
 * The worker path and the sync path use the exact same math, so results match.
 */

import { useState, useEffect, useRef, useCallback } from 'react'
import { runCalculation } from '../lib/photometry/runCalculation'
import type {
  RoomConfig,
  LuminaireInstance,
  IESData,
  CalculationResults,
  CalculationWorkerInput,
  CalculationWorkerOutput
} from '../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

export interface CalculationState {
  results: CalculationResults | null
  isCalculating: boolean
  progress: number
  progressMessage: string
  error: string | null
}

export interface CalculationActions {
  calculate: (
    room: RoomConfig,
    luminaires: LuminaireInstance[],
    iesDataMap: Map<string, IESData> | Record<string, IESData>,
    options?: CalculationOptions
  ) => void
  cancel: () => void
  clear: () => void
}

export interface CalculationOptions {
  gridSpacing?: number
  calculateUGR?: boolean
  debounceMs?: number
}

/**
 * Build a Worker when the host bundler/browser allows it.
 *
 * The worker specifier is assembled at runtime so esbuild does NOT treat this as
 * a code-split `new Worker(new URL(...))` entry. (Vite's dev dependency
 * optimiser can't handle worker code-splitting, which used to block the whole
 * package from being pre-bundled.) If the Worker can't be created we return
 * null and the hook falls back to the synchronous calculation.
 */
function createPlannerWorker(): Worker | null {
  try {
    if (typeof Worker === 'undefined') {
      return null
    }
    const workerName = 'calculator.worker' + '.ts'
    const workerPath = '../lib/photometry/' + workerName
    return new Worker(new URL(workerPath, import.meta.url), { type: 'module' })
  } catch (e) {
    // The browser/bundler couldn't give us a worker — fall back to main thread.
    console.warn('[planner] Web Worker unavailable; using main-thread calculation.', e)
    return null
  }
}

interface PendingCalculation {
  room: RoomConfig
  luminaires: LuminaireInstance[]
  iesDataMap: Record<string, IESData>
  options: { gridSpacing: number; calculateUGR: boolean }
}

// =============================================================================
// Hook Implementation
// =============================================================================

export function useLightingCalculation(): CalculationState & CalculationActions {
  // State
  const [results, setResults] = useState<CalculationResults | null>(null)
  const [isCalculating, setIsCalculating] = useState(false)
  const [progress, setProgress] = useState(0)
  const [progressMessage, setProgressMessage] = useState('')
  const [error, setError] = useState<string | null>(null)

  // Refs
  const workerRef = useRef<Worker | null>(null)
  const debounceTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null)
  const pendingRef = useRef<PendingCalculation | null>(null)

  // Initialize worker
  useEffect(() => {
    workerRef.current = createPlannerWorker()
    const worker = workerRef.current

    if (worker) {
      // Handle messages from worker
      worker.onmessage = (event: MessageEvent<CalculationWorkerOutput>) => {
        const data = event.data
        switch (data.type) {
          case 'progress':
            setProgress(data.percent)
            if (data.message) setProgressMessage(data.message)
            break
          case 'complete':
            setResults(data.results)
            setIsCalculating(false)
            setProgress(100)
            setProgressMessage('Complete')
            setError(null)
            break
          case 'error':
            setError(data.message)
            setIsCalculating(false)
            setProgress(0)
            setProgressMessage('')
            break
        }
      }

      // If the worker fails at runtime, fall back to the main-thread path.
      worker.onerror = (event) => {
        console.warn('[planner] Calculation worker error; switching to main-thread.', event)
        workerRef.current = null
        worker.terminate()
        setError(null)
      }
    }

    // Cleanup
    return () => {
      // eslint-disable-next-line react-hooks/exhaustive-deps
      if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)
      if (workerRef.current) {
        workerRef.current.terminate()
        workerRef.current = null
      }
    }
  }, [])

  const runSync = useCallback((pending: PendingCalculation) => {
    setError(null)
    setIsCalculating(true)
    setProgress(0)
    setProgressMessage('Starting...')
    try {
      const res = runCalculation(
        pending.room,
        pending.luminaires,
        pending.iesDataMap,
        { gridSpacing: pending.options.gridSpacing, calculateUGR: pending.options.calculateUGR },
        (percent, message) => {
          setProgress(percent)
          if (message) setProgressMessage(message)
        }
      )
      setResults(res)
      setIsCalculating(false)
      setProgress(100)
      setProgressMessage('Complete')
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Calculation failed')
      setIsCalculating(false)
      setProgress(0)
      setProgressMessage('')
    }
  }, [])

  /**
   * Start a calculation.
   */
  const calculate = useCallback((
    room: RoomConfig,
    luminaires: LuminaireInstance[],
    iesDataMap: Map<string, IESData> | Record<string, IESData>,
    options: CalculationOptions = {}
  ) => {
    const {
      gridSpacing = 0.5,
      calculateUGR = true,
      debounceMs = 300
    } = options

    // Convert Map to Record for worker serialization
    const iesRecord: Record<string, IESData> = iesDataMap instanceof Map
      ? Object.fromEntries(iesDataMap)
      : iesDataMap

    pendingRef.current = {
      room,
      luminaires,
      iesDataMap: iesRecord,
      options: { gridSpacing, calculateUGR }
    }

    // Clear existing debounce timer
    if (debounceTimerRef.current) clearTimeout(debounceTimerRef.current)

    // Debounce the calculation
    debounceTimerRef.current = setTimeout(() => {
      const pending = pendingRef.current
      if (!pending) return

      const worker = workerRef.current
      if (!worker) {
        pendingRef.current = null
        runSync(pending)
        return
      }

      // Clear error
      setError(null)
      setIsCalculating(true)
      setProgress(0)
      setProgressMessage('Starting...')

      // Send to worker
      const message: CalculationWorkerInput = {
        type: 'calculate',
        room: pending.room,
        luminaires: pending.luminaires,
        iesDataMap: pending.iesDataMap,
        gridSpacing: pending.options.gridSpacing ?? 0.5,
        calculateUGR: pending.options.calculateUGR ?? true
      }
      worker.postMessage(message)
      pendingRef.current = null
    }, debounceMs)
  }, [runSync])

  /**
   * Cancel any pending or in-progress calculation.
   */
  const cancel = useCallback(() => {
    if (debounceTimerRef.current) {
      clearTimeout(debounceTimerRef.current)
      debounceTimerRef.current = null
    }

    if (workerRef.current) {
      workerRef.current.terminate()
      // Recreate worker
      workerRef.current = createPlannerWorker()
    }

    pendingRef.current = null
    setIsCalculating(false)
    setProgress(0)
    setProgressMessage('')
  }, [])

  /**
   * Clear results.
   */
  const clear = useCallback(() => {
    setResults(null)
    setError(null)
    setProgress(0)
    setProgressMessage('')
  }, [])

  return {
    results,
    isCalculating,
    progress,
    progressMessage,
    error,
    calculate,
    cancel,
    clear
  }
}

// =============================================================================
// Synchronous Fallback Calculator
// =============================================================================

/**
 * One-shot synchronous calculation (no worker, no progress UI). Useful for
 * places that want a simple blocking result.
 */
export function calculateSync(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>,
  gridSpacing: number = 0.5
): CalculationResults {
  return runCalculation(room, luminaires, iesDataMap, { gridSpacing })
}

// =============================================================================
// Auto-Calculate Hook
// =============================================================================

export function useAutoCalculation(
  room: RoomConfig | null,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>,
  options: CalculationOptions & { enabled?: boolean } = {}
) {
  const { enabled = true, debounceMs = 500, ...calcOptions } = options
  const calc = useLightingCalculation()

  const prevInputsRef = useRef<string>('')

  useEffect(() => {
    if (!enabled || !room || luminaires.length === 0 || iesDataMap.size === 0) {
      return
    }

    const inputHash = JSON.stringify({
      room,
      luminaires: luminaires.map(l => ({
        id: l.id,
        iesProfileId: l.iesProfileId,
        position: l.position,
        rotation: l.rotation,
        dimming: l.dimming
      })),
      iesIds: Array.from(iesDataMap.keys())
    })

    if (inputHash === prevInputsRef.current) {
      return
    }
    prevInputsRef.current = inputHash

    calc.calculate(room, luminaires, iesDataMap, {
      ...calcOptions,
      debounceMs
    })
  }, [room, luminaires, iesDataMap, enabled, debounceMs, calc, calcOptions])

  return calc
}

// =============================================================================
// Helper: Quick Calculation for Small Changes
// =============================================================================

export function isQuickCalculation(
  room: RoomConfig,
  luminaireCount: number,
  gridSpacing: number = 0.5
): boolean {
  const gridPoints = Math.floor(room.width / gridSpacing) * Math.floor(room.length / gridSpacing)
  const operations = gridPoints * luminaireCount
  return operations < 10000
}

export function estimateCalculationTime(
  room: RoomConfig,
  luminaireCount: number,
  gridSpacing: number = 0.5
): number {
  const gridPoints = Math.floor(room.width / gridSpacing) * Math.floor(room.length / gridSpacing)
  const operations = gridPoints * luminaireCount
  return Math.ceil(operations * 0.01)
}
