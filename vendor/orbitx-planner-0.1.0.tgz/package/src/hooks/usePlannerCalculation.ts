/**
 * OrbitX Lighting Planner - Store-Integrated Calculation Hook
 * 
 * Connects the calculation engine with the Zustand store for
 * automatic calculation triggers and result storage.
 */

'use client'

import { useCallback, useEffect, useRef } from 'react'
import { usePlannerStore } from '../stores/plannerStore'
import { useLightingCalculation, isQuickCalculation, estimateCalculationTime } from './useLightingCalculation'
import { useIESData } from './useIESData'

// =============================================================================
// Store-Integrated Calculation Hook
// =============================================================================

export interface UsePlannerCalculationOptions {
  /** Enable auto-calculation for quick changes */
  autoCalculate?: boolean
  /** Debounce time for auto-calculation (ms) */
  debounceMs?: number
  /** Grid spacing for calculations (m) */
  gridSpacing?: number
  /** Calculate UGR values */
  calculateUGR?: boolean
}

/**
 * Hook that connects the calculation engine with the planner store.
 * Handles:
 * - Loading IES data for placed luminaires
 * - Triggering calculations (auto or manual)
 * - Updating store with results and progress
 */
export function usePlannerCalculation(options: UsePlannerCalculationOptions = {}) {
  const {
    autoCalculate = true,
    debounceMs = 500,
    gridSpacing = 0.5,
    calculateUGR = true
  } = options
  
  // Store state
  const room = usePlannerStore(state => state.room)
  const luminaires = usePlannerStore(state => state.luminaires)
  const iesDataCache = usePlannerStore(state => state.iesDataCache)
  const setCalculating = usePlannerStore(state => state.setCalculating)
  const setResults = usePlannerStore(state => state.setResults)
  const cacheIESData = usePlannerStore(state => state.cacheIESData)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  
  // Calculation hook
  const calc = useLightingCalculation()
  
  // IES data hook
  const ies = useIESData()
  
  // Track input changes
  const inputHashRef = useRef<string>('')
  const lastCalcTimeRef = useRef<number>(0)
  
  /**
   * Load IES data for all luminaires that need it.
   */
  const ensureIESDataLoaded = useCallback(async () => {
    const missingIds = new Set<string>()
    
    for (const lum of luminaires) {
      if (!iesDataCache.has(lum.iesProfileId)) {
        missingIds.add(lum.iesProfileId)
      }
    }
    
    if (missingIds.size === 0) return true
    
    // Find profile URLs for missing IDs
    const toLoad: Array<{ id: string; url: string }> = []
    
    Array.from(missingIds).forEach(id => {
      const profile = iesProfiles.find(p => p.id === id)
      if (profile?.url) {
        toLoad.push({ id, url: profile.url })
      }
    })
    
    if (toLoad.length === 0) return true
    
    // Load missing IES data
    await ies.loadMultiple(toLoad)
    
    // Cache in store
    for (const { id } of toLoad) {
      const data = ies.getIESData(id)
      if (data) {
        cacheIESData(id, data)
      }
    }
    
    return true
  }, [luminaires, iesDataCache, iesProfiles, ies, cacheIESData])
  
  /**
   * Trigger a calculation manually.
   */
  const calculate = useCallback(async () => {
    if (luminaires.length === 0) {
      setResults(null)
      return
    }
    
    // Ensure IES data is loaded
    await ensureIESDataLoaded()
    
    // Build IES data map from store cache
    const iesMap = new Map(usePlannerStore.getState().iesDataCache)
    
    // Check if we have all needed IES data
    const hasAllData = luminaires.every(l => iesMap.has(l.iesProfileId))
    if (!hasAllData) {
      console.warn('Missing IES data for some luminaires')
    }
    
    // Start calculation
    setCalculating(true, 0, 'Starting calculation...')
    
    calc.calculate(room, luminaires, iesMap, {
      gridSpacing,
      calculateUGR,
      debounceMs: 0 // No debounce for manual trigger
    })
  }, [room, luminaires, gridSpacing, calculateUGR, ensureIESDataLoaded, calc, setCalculating, setResults])
  
  // Sync calculation state to store
  useEffect(() => {
    if (calc.isCalculating) {
      setCalculating(true, calc.progress, calc.progressMessage)
    } else if (calc.results) {
      setCalculating(false)
      setResults(calc.results)
      lastCalcTimeRef.current = Date.now()
    } else if (calc.error) {
      setCalculating(false)
      console.error('Calculation error:', calc.error)
    }
  }, [calc.isCalculating, calc.progress, calc.progressMessage, calc.results, calc.error, setCalculating, setResults])
  
  // Auto-calculation on input changes
  useEffect(() => {
    if (!autoCalculate) return
    if (luminaires.length === 0) return
    
    // Create input hash
    const inputHash = JSON.stringify({
      room: { w: room.width, l: room.length, h: room.height, wp: room.workPlaneHeight },
      lums: luminaires.map(l => ({
        id: l.id,
        ies: l.iesProfileId,
        x: l.position.x,
        y: l.position.y,
        z: l.position.z,
        d: l.dimming
      }))
    })
    
    // Skip if unchanged
    if (inputHash === inputHashRef.current) return
    inputHashRef.current = inputHash
    
    // Check if this is a quick calculation
    const isQuick = isQuickCalculation(room, luminaires.length, gridSpacing)
    
    if (isQuick) {
      // Auto-calculate with debounce
      const timer = setTimeout(() => {
        calculate()
      }, debounceMs)
      
      return () => clearTimeout(timer)
    }
    // For heavy calculations, user must trigger manually
  }, [room, luminaires, autoCalculate, gridSpacing, debounceMs, calculate])
  
  return {
    calculate,
    cancel: calc.cancel,
    clear: calc.clear,
    isCalculating: calc.isCalculating,
    progress: calc.progress,
    progressMessage: calc.progressMessage,
    error: calc.error,
    estimatedTime: estimateCalculationTime(room, luminaires.length, gridSpacing),
    isQuickCalculation: isQuickCalculation(room, luminaires.length, gridSpacing)
  }
}

// =============================================================================
// IES Profile Loader Hook (Store-Integrated)
// =============================================================================

/**
 * Hook to load IES profiles into the store on mount.
 */
export function usePlannerIESProfiles() {
  const setIESProfiles = usePlannerStore(state => state.setIESProfiles)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const ies = useIESData()
  
  // Load profiles on mount
  useEffect(() => {
    if (iesProfiles.length === 0 && !ies.profilesLoading) {
      ies.loadProfiles()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [iesProfiles.length, ies.profilesLoading])
  
  // Sync to store when loaded
  useEffect(() => {
    if (ies.profiles.length > 0) {
      setIESProfiles(ies.profiles)
    }
  }, [ies.profiles, setIESProfiles])
  
  return {
    profiles: ies.profiles,
    loading: ies.profilesLoading,
    error: ies.profilesError,
    reload: ies.loadProfiles
  }
}

export default usePlannerCalculation
