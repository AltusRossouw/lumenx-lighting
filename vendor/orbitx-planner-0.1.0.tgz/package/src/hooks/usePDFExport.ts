/**
 * OrbitX Lighting Planner Pro - PDF Export Hook
 * 
 * Generates professional branded PDF reports with:
 * - OrbitX branding (#0084ff, #0066cc)
 * - Technical specifications
 * - Calculation results and compliance status
 * - 2D floor plan capture
 * - EN 12464-1 compliance summary
 */

'use client'

import { useState, useCallback } from 'react'
import { usePlannerStore } from '../stores/plannerStore'
import { checkCompliance } from '../lib/photometry/Standards'
import { DIALUX_COLOR_SCALE } from '../lib/photometry/types'
import type { CalculationResults, RoomConfig, LuminaireInstance, IESProfile, ActivityRequirements } from '../lib/photometry/types'

// OrbitX Brand Colors
const ORBITX_BLUE = '#0084ff'
const ORBITX_BLUE_DARK = '#0066cc'
const ORBITX_BLUE_RGB = { r: 0, g: 132, b: 255 }
const ORBITX_BLUE_DARK_RGB = { r: 0, g: 102, b: 204 }

interface PDFExportOptions {
  includeCompliance?: boolean
  include2DView?: boolean
  include3DViews?: boolean
  includeDetailedMetrics?: boolean
  includeLuminaireList?: boolean
  projectName?: string
  preparedBy?: string
  clientName?: string
  notes?: string
}

interface PDFExportState {
  isExporting: boolean
  progress: number
  message: string
  error: string | null
}

interface UsePDFExportReturn extends PDFExportState {
  exportPDF: (options?: PDFExportOptions) => Promise<void>
  capture2DView: () => Promise<string | null>
}

export function usePDFExport(): UsePDFExportReturn {
  const [state, setState] = useState<PDFExportState>({
    isExporting: false,
    progress: 0,
    message: '',
    error: null
  })

  const room = usePlannerStore(s => s.room)
  const luminaires = usePlannerStore(s => s.luminaires)
  const results = usePlannerStore(s => s.results)
  const projectName = usePlannerStore(s => s.projectName)
  const activityType = usePlannerStore(s => s.activityType)
  const iesProfiles = usePlannerStore(s => s.iesProfiles)

  const setProgress = useCallback((progress: number, message: string) => {
    setState(s => ({ ...s, progress, message }))
  }, [])

  /**
   * Capture the 2D viewer as a base64 PNG image
   */
  const capture2DView = useCallback(async (): Promise<string | null> => {
    try {
      // Find the 2D canvas element
      const canvas = document.querySelector('canvas[data-viewer-2d]') as HTMLCanvasElement
      if (!canvas) {
        console.warn('2D canvas not found')
        return null
      }
      return canvas.toDataURL('image/png')
    } catch (error) {
      console.error('Failed to capture 2D view:', error)
      return null
    }
  }, [])

  /**
   * Generate and download PDF report
   */
  const exportPDF = useCallback(async (options: PDFExportOptions = {}) => {
    setState({ isExporting: true, progress: 0, message: 'Initializing...', error: null })

    try {
      // Dynamic import jsPDF
      setProgress(5, 'Loading PDF library...')
      const { jsPDF } = await import('jspdf')

      // Create PDF
      setProgress(10, 'Creating document...')
      const pdf = new jsPDF('p', 'mm', 'a4')
      const pageWidth = pdf.internal.pageSize.getWidth()
      const pageHeight = pdf.internal.pageSize.getHeight()
      const margin = 15
      const contentWidth = pageWidth - (margin * 2)

      // =========================================================================
      // Page 1: Cover Page with OrbitX Branding
      // =========================================================================
      
      // Header bar with gradient effect (solid color for PDF)
      pdf.setFillColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
      pdf.rect(0, 0, pageWidth, 50, 'F')
      
      // Accent line
      pdf.setFillColor(ORBITX_BLUE_DARK_RGB.r, ORBITX_BLUE_DARK_RGB.g, ORBITX_BLUE_DARK_RGB.b)
      pdf.rect(0, 50, pageWidth, 3, 'F')

      // Title
      pdf.setTextColor(255, 255, 255)
      pdf.setFontSize(28)
      pdf.setFont('helvetica', 'bold')
      pdf.text('OrbitX', margin, 25)
      
      pdf.setFontSize(14)
      pdf.setFont('helvetica', 'normal')
      pdf.text('Lighting Design Report', margin, 38)

      // Project info box
      let yPos = 70
      pdf.setTextColor(0, 0, 0)
      pdf.setFontSize(22)
      pdf.setFont('helvetica', 'bold')
      pdf.text(options.projectName || projectName || 'Lighting Project', margin, yPos)
      
      yPos += 15
      pdf.setFontSize(11)
      pdf.setFont('helvetica', 'normal')
      pdf.setTextColor(100, 100, 100)
      pdf.text(`Generated: ${new Date().toLocaleDateString('en-GB', { 
        day: '2-digit', 
        month: 'long', 
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })}`, margin, yPos)

      if (options.preparedBy) {
        yPos += 7
        pdf.text(`Prepared by: ${options.preparedBy}`, margin, yPos)
      }

      if (options.clientName) {
        yPos += 7
        pdf.text(`Client: ${options.clientName}`, margin, yPos)
      }

      // Room summary section
      yPos += 20
      pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
      pdf.setFontSize(14)
      pdf.setFont('helvetica', 'bold')
      pdf.text('Room Specifications', margin, yPos)
      
      yPos += 10
      pdf.setTextColor(0, 0, 0)
      pdf.setFontSize(10)
      pdf.setFont('helvetica', 'normal')
      
      const roomData = [
        ['Dimensions', `${room.width}m × ${room.length}m × ${room.height}m`],
        ['Floor Area', `${(room.width * room.length).toFixed(1)} m²`],
        ['Volume', `${(room.width * room.length * room.height).toFixed(1)} m³`],
        ['Work Plane Height', `${room.workPlaneHeight} m`],
        ['Ceiling Reflectance', `${(room.ceilingReflectance * 100).toFixed(0)}%`],
        ['Wall Reflectance', `${(room.wallReflectance * 100).toFixed(0)}%`],
        ['Floor Reflectance', `${(room.floorReflectance * 100).toFixed(0)}%`]
      ]

      for (const [label, value] of roomData) {
        pdf.setFont('helvetica', 'bold')
        pdf.text(`${label}:`, margin, yPos)
        pdf.setFont('helvetica', 'normal')
        pdf.text(value, margin + 45, yPos)
        yPos += 6
      }

      // Luminaire summary
      yPos += 15
      pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
      pdf.setFontSize(14)
      pdf.setFont('helvetica', 'bold')
      pdf.text('Lighting Configuration', margin, yPos)

      yPos += 10
      pdf.setTextColor(0, 0, 0)
      pdf.setFontSize(10)
      
      pdf.setFont('helvetica', 'bold')
      pdf.text('Total Luminaires:', margin, yPos)
      pdf.setFont('helvetica', 'normal')
      pdf.text(`${luminaires.length}`, margin + 45, yPos)

      // Get unique IES profiles used
      const usedProfileIds = Array.from(new Set(luminaires.map(l => l.iesProfileId)))
      const usedProfiles = usedProfileIds
        .map(id => iesProfiles.find(p => p.id === id))
        .filter((p): p is IESProfile => p !== undefined)

      if (usedProfiles.length > 0) {
        yPos += 10
        pdf.setFont('helvetica', 'bold')
        pdf.text('Products Used:', margin, yPos)
        yPos += 6
        
        for (const profile of usedProfiles) {
          const count = luminaires.filter(l => l.iesProfileId === profile.id).length
          pdf.setFont('helvetica', 'normal')
          pdf.text(`• ${profile.productName} - ${profile.variantLabel} (×${count})`, margin + 5, yPos)
          if (profile.lumens) {
            pdf.text(`${profile.lumens} lm`, margin + 120, yPos)
          }
          yPos += 5
        }
      }

      // =========================================================================
      // Page 2: Calculation Results
      // =========================================================================
      
      setProgress(30, 'Adding calculation results...')
      
      if (results) {
        pdf.addPage()
        
        // Header
        drawPageHeader(pdf, 'Calculation Results', pageWidth)
        
        yPos = 60
        
        // Results summary box
        pdf.setFillColor(245, 247, 250)
        pdf.roundedRect(margin, yPos - 5, contentWidth, 45, 3, 3, 'F')
        
        pdf.setTextColor(0, 0, 0)
        pdf.setFontSize(10)
        
        const col1 = margin + 5
        const col2 = margin + 55
        const col3 = margin + 105
        
        // Row 1
        drawMetricBox(pdf, 'E min', `${results.Emin.toFixed(0)} lux`, col1, yPos, ORBITX_BLUE_RGB)
        drawMetricBox(pdf, 'E avg', `${results.Eavg.toFixed(0)} lux`, col2, yPos, ORBITX_BLUE_RGB)
        drawMetricBox(pdf, 'E max', `${results.Emax.toFixed(0)} lux`, col3, yPos, ORBITX_BLUE_RGB)
        
        yPos += 20
        
        // Row 2
        drawMetricBox(pdf, 'Uniformity (Uo)', results.Uo.toFixed(2), col1, yPos, ORBITX_BLUE_RGB)
        drawMetricBox(pdf, 'Diversity (Ud)', results.Ud.toFixed(2), col2, yPos, ORBITX_BLUE_RGB)
        if (results.UGR !== undefined) {
          drawMetricBox(pdf, 'UGR', results.UGR.toFixed(0), col3, yPos, ORBITX_BLUE_RGB)
        }
        
        yPos += 30
        
        // Power metrics
        pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
        pdf.setFontSize(12)
        pdf.setFont('helvetica', 'bold')
        pdf.text('Power & Energy Metrics', margin, yPos)
        
        yPos += 10
        pdf.setTextColor(0, 0, 0)
        pdf.setFontSize(10)
        pdf.setFont('helvetica', 'normal')
        
        const powerData = [
          ['Total Power', `${results.totalPower.toFixed(0)} W`],
          ['Power Density', `${results.powerDensity.toFixed(2)} W/m²`],
          ['LENI', `${results.LENI.toFixed(1)} kWh/m²/year`],
          ['Total Luminous Flux', `${results.totalLumens.toLocaleString()} lm`],
          ['Maintenance Factor', `${(results.maintenanceFactor * 100).toFixed(0)}%`]
        ]
        
        for (const [label, value] of powerData) {
          pdf.setFont('helvetica', 'bold')
          pdf.text(`${label}:`, margin, yPos)
          pdf.setFont('helvetica', 'normal')
          pdf.text(value, margin + 50, yPos)
          yPos += 6
        }

        // Vertical & cylindrical illuminance (EN 12464-1 supplementary metrics).
        if (results.Evavg !== undefined || results.Ezavg !== undefined) {
          yPos += 8
          pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
          pdf.setFontSize(12)
          pdf.setFont('helvetica', 'bold')
          pdf.text('Supplementary Photometric Data', margin, yPos)

          yPos += 8
          pdf.setTextColor(0, 0, 0)
          pdf.setFontSize(10)
          pdf.setFont('helvetica', 'normal')

          const suppData: [string, string][] = []
          if (results.Evavg !== undefined) suppData.push(['Vertical Illuminance (Ev avg)', `${results.Evavg.toFixed(0)} lux`])
          if (results.Ezavg !== undefined) suppData.push(['Cylindrical Illuminance (Ez avg)', `${results.Ezavg.toFixed(0)} lux`])

          for (const [label, value] of suppData) {
            pdf.setFont('helvetica', 'bold')
            pdf.text(`${label}:`, margin, yPos)
            pdf.setFont('helvetica', 'normal')
            pdf.text(value, margin + 75, yPos)
            yPos += 6
          }
        }

        // Maintenance factor breakdown.
        if (room.maintenanceFactors) {
          yPos += 8
          pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
          pdf.setFontSize(12)
          pdf.setFont('helvetica', 'bold')
          pdf.text('Maintenance Factor Breakdown (CIE 97)', margin, yPos)

          yPos += 8
          pdf.setTextColor(0, 0, 0)
          pdf.setFontSize(10)

          const mfData: [string, string][] = [
            ['LLMF · Lamp Lumen Maintenance', `${(room.maintenanceFactors.llmf * 100).toFixed(0)}%`],
            ['LSF · Lamp Survival', `${(room.maintenanceFactors.lsf * 100).toFixed(0)}%`],
            ['LMF · Luminaire Maintenance', `${(room.maintenanceFactors.lmf * 100).toFixed(0)}%`],
            ['RSMF · Room Surface Maintenance', `${(room.maintenanceFactors.rsmf * 100).toFixed(0)}%`],
          ]

          for (const [label, value] of mfData) {
            pdf.setFont('helvetica', 'bold')
            pdf.text(`${label}:`, margin, yPos)
            pdf.setFont('helvetica', 'normal')
            pdf.text(value, margin + 75, yPos)
            yPos += 6
          }
        }

        // Compliance section
        if (options.includeCompliance !== false) {
          const compliance = checkCompliance(results, activityType)
          yPos += 15
          pdf.setTextColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
          pdf.setFontSize(12)
          pdf.setFont('helvetica', 'bold')
          pdf.text('EN 12464-1 Compliance', margin, yPos)
          
          yPos += 10
          
          // Activity type
          pdf.setTextColor(0, 0, 0)
          pdf.setFontSize(10)
          pdf.setFont('helvetica', 'bold')
          pdf.text('Activity Type:', margin, yPos)
          pdf.setFont('helvetica', 'normal')
          pdf.text(compliance.requirements.name, margin + 35, yPos)
          
          yPos += 10
          
          // Compliance table
          const checks = [
            {
              label: 'Illuminance (Eavg)',
              value: `${compliance.illuminanceValue.toFixed(0)} lux`,
              target: `≥ ${compliance.illuminanceTarget} lux`,
              pass: compliance.illuminancePass
            },
            {
              label: 'Uniformity (Uo)',
              value: compliance.uniformityValue.toFixed(2),
              target: `≥ ${compliance.uniformityTarget}`,
              pass: compliance.uniformityPass
            },
            {
              label: 'Glare (UGR)',
              value: compliance.ugrValue !== null ? compliance.ugrValue.toFixed(0) : 'N/A',
              target: `≤ ${compliance.ugrTarget}`,
              pass: compliance.ugrPass
            }
          ]
          
          // Table header
          pdf.setFillColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
          pdf.rect(margin, yPos, contentWidth, 7, 'F')
          pdf.setTextColor(255, 255, 255)
          pdf.setFont('helvetica', 'bold')
          pdf.text('Parameter', margin + 2, yPos + 5)
          pdf.text('Actual', margin + 55, yPos + 5)
          pdf.text('Required', margin + 95, yPos + 5)
          pdf.text('Status', margin + 145, yPos + 5)
          
          yPos += 7
          
          // Table rows
          pdf.setTextColor(0, 0, 0)
          for (const check of checks) {
            const bgColor = check.pass ? { r: 220, g: 252, b: 231 } : { r: 254, g: 226, b: 226 }
            pdf.setFillColor(bgColor.r, bgColor.g, bgColor.b)
            pdf.rect(margin, yPos, contentWidth, 7, 'F')
            
            pdf.setFont('helvetica', 'normal')
            pdf.text(check.label, margin + 2, yPos + 5)
            pdf.text(check.value, margin + 55, yPos + 5)
            pdf.text(check.target, margin + 95, yPos + 5)
            
            pdf.setFont('helvetica', 'bold')
            const statusColor = check.pass ? { r: 22, g: 163, b: 74 } : { r: 220, g: 38, b: 38 }
            pdf.setTextColor(statusColor.r, statusColor.g, statusColor.b)
            pdf.text(check.pass ? 'PASS' : 'FAIL', margin + 145, yPos + 5)
            pdf.setTextColor(0, 0, 0)
            
            yPos += 7
          }
          
          // Overall result
          yPos += 5
          const overallPass = compliance.overallPass
          pdf.setFillColor(
            overallPass ? 22 : 220,
            overallPass ? 163 : 38,
            overallPass ? 74 : 38
          )
          pdf.roundedRect(margin, yPos, 60, 10, 2, 2, 'F')
          pdf.setTextColor(255, 255, 255)
          pdf.setFontSize(11)
          pdf.setFont('helvetica', 'bold')
          pdf.text(overallPass ? 'COMPLIANT' : 'NON-COMPLIANT', margin + 5, yPos + 7)
          
          // Recommendations
          if (!overallPass && compliance.recommendations.length > 0) {
            yPos += 20
            pdf.setTextColor(220, 38, 38)
            pdf.setFontSize(10)
            pdf.setFont('helvetica', 'bold')
            pdf.text('Recommendations:', margin, yPos)
            
            yPos += 6
            pdf.setTextColor(0, 0, 0)
            pdf.setFont('helvetica', 'normal')
            for (const rec of compliance.recommendations) {
              pdf.text(`• ${rec}`, margin + 5, yPos)
              yPos += 5
            }
          }
        }
      }

      // =========================================================================
      // Page 3: 2D Floor Plan (if available)
      // =========================================================================
      
      if (options.include2DView !== false) {
        setProgress(50, 'Capturing 2D view...')
        const view2D = await capture2DView()
        
        if (view2D) {
          pdf.addPage()
          drawPageHeader(pdf, '2D Floor Plan View', pageWidth)
          
          // Add image
          const imgWidth = contentWidth
          const imgHeight = (imgWidth * 3) / 4
          pdf.addImage(view2D, 'PNG', margin, 55, imgWidth, Math.min(imgHeight, pageHeight - 85))
          
          // Quantitative false-color legend
          const legendY = 55 + Math.min(imgHeight, pageHeight - 85) + 12
          if (legendY < pageHeight - 25 && results) {
            pdf.setTextColor(80, 80, 80)
            pdf.setFontSize(8)
            pdf.setFont('helvetica', 'bold')
            pdf.text('Illuminance scale (lux)', margin, legendY - 3)
            drawColorLegend(pdf, margin, legendY, contentWidth, results.Emin, results.Emax)
          }
        }
      }

      // =========================================================================
      // Page 4: Luminaire Schedule (if requested)
      // =========================================================================
      
      if (options.includeLuminaireList !== false && luminaires.length > 0) {
        setProgress(70, 'Adding luminaire schedule...')
        pdf.addPage()
        drawPageHeader(pdf, 'Luminaire Schedule', pageWidth)
        
        yPos = 55
        
        // Table header
        pdf.setFillColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
        pdf.rect(margin, yPos, contentWidth, 8, 'F')
        pdf.setTextColor(255, 255, 255)
        pdf.setFontSize(9)
        pdf.setFont('helvetica', 'bold')
        pdf.text('#', margin + 2, yPos + 6)
        pdf.text('Model / Variant', margin + 12, yPos + 6)
        pdf.text('Position (x, y, z)', margin + 80, yPos + 6)
        pdf.text('Dimming', margin + 130, yPos + 6)
        pdf.text('Lumens', margin + 155, yPos + 6)
        
        yPos += 8
        
        // Table rows
        pdf.setTextColor(0, 0, 0)
        pdf.setFont('helvetica', 'normal')
        pdf.setFontSize(8)
        
        luminaires.forEach((lum, index) => {
          const profile = iesProfiles.find(p => p.id === lum.iesProfileId)
          const bgColor = index % 2 === 0 ? { r: 255, g: 255, b: 255 } : { r: 245, g: 247, b: 250 }
          pdf.setFillColor(bgColor.r, bgColor.g, bgColor.b)
          pdf.rect(margin, yPos, contentWidth, 6, 'F')
          
          pdf.text(`${index + 1}`, margin + 2, yPos + 4.5)
          const productText = profile ? (profile.variantLabel || profile.productName) : 'Unknown'
          pdf.text(productText.substring(0, 40), margin + 12, yPos + 4.5)
          pdf.text(
            `(${lum.position.x.toFixed(2)}, ${lum.position.y.toFixed(2)}, ${lum.position.z.toFixed(2)})`,
            margin + 80, yPos + 4.5
          )
          pdf.text(`${(lum.dimming * 100).toFixed(0)}%`, margin + 130, yPos + 4.5)
          
          if (profile?.lumens) {
            pdf.text(`${Math.round(profile.lumens * lum.dimming)}`, margin + 155, yPos + 4.5)
          }
          
          yPos += 6
          
          // Check if we need a new page
          if (yPos > pageHeight - 30) {
            pdf.addPage()
            drawPageHeader(pdf, 'Luminaire Schedule (continued)', pageWidth)
            yPos = 55
          }
        })
      }

      // =========================================================================
      // Notes page (if provided)
      // =========================================================================
      
      if (options.notes) {
        setProgress(85, 'Adding notes...')
        pdf.addPage()
        drawPageHeader(pdf, 'Notes', pageWidth)
        
        yPos = 55
        pdf.setTextColor(0, 0, 0)
        pdf.setFontSize(10)
        pdf.setFont('helvetica', 'normal')
        
        // Word wrap notes
        const lines = pdf.splitTextToSize(options.notes, contentWidth)
        pdf.text(lines, margin, yPos)
      }

      // =========================================================================
      // Footer on all pages
      // =========================================================================
      
      setProgress(90, 'Adding footers...')
      const totalPages = pdf.getNumberOfPages()
      for (let i = 1; i <= totalPages; i++) {
        pdf.setPage(i)
        
        // Footer line
        pdf.setDrawColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
        pdf.setLineWidth(0.5)
        pdf.line(margin, pageHeight - 15, pageWidth - margin, pageHeight - 15)
        
        // Footer text
        pdf.setTextColor(100, 100, 100)
        pdf.setFontSize(8)
        pdf.setFont('helvetica', 'normal')
        pdf.text('Generated by OrbitX Lighting Planner Pro', margin, pageHeight - 10)
        pdf.text(`Page ${i} of ${totalPages}`, pageWidth - margin - 20, pageHeight - 10)
      }

      // =========================================================================
      // Save PDF
      // =========================================================================
      
      setProgress(95, 'Saving PDF...')
      const filename = `${(options.projectName || projectName || 'lighting-report').replace(/\s+/g, '-').toLowerCase()}-${Date.now()}.pdf`
      pdf.save(filename)
      
      setProgress(100, 'Complete!')
      setState(s => ({ ...s, isExporting: false, progress: 100, message: 'Export complete!' }))
      
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Unknown error during PDF export'
      console.error('PDF export error:', error)
      setState(s => ({ ...s, isExporting: false, error: message }))
    }
  }, [room, luminaires, results, projectName, activityType, iesProfiles, setProgress, capture2DView])

  return {
    ...state,
    exportPDF,
    capture2DView
  }
}

// =============================================================================
// Helper Functions
// =============================================================================

function drawPageHeader(pdf: any, title: string, pageWidth: number) {
  const margin = 15
  
  // Header bar
  pdf.setFillColor(ORBITX_BLUE_RGB.r, ORBITX_BLUE_RGB.g, ORBITX_BLUE_RGB.b)
  pdf.rect(0, 0, pageWidth, 35, 'F')
  
  // Accent line
  pdf.setFillColor(ORBITX_BLUE_DARK_RGB.r, ORBITX_BLUE_DARK_RGB.g, ORBITX_BLUE_DARK_RGB.b)
  pdf.rect(0, 35, pageWidth, 2, 'F')
  
  // Title
  pdf.setTextColor(255, 255, 255)
  pdf.setFontSize(18)
  pdf.setFont('helvetica', 'bold')
  pdf.text(title, margin, 22)
  
  // OrbitX watermark
  pdf.setFontSize(10)
  pdf.setFont('helvetica', 'normal')
  pdf.text('OrbitX', pageWidth - margin - 15, 22)
}

function drawMetricBox(
  pdf: any, 
  label: string, 
  value: string, 
  x: number, 
  y: number, 
  color: { r: number, g: number, b: number }
) {
  pdf.setTextColor(color.r, color.g, color.b)
  pdf.setFontSize(8)
  pdf.setFont('helvetica', 'bold')
  pdf.text(label, x, y)
  
  pdf.setTextColor(0, 0, 0)
  pdf.setFontSize(14)
  pdf.setFont('helvetica', 'bold')
  pdf.text(value, x, y + 8)
}

/**
 * Draw a horizontal DIALux-style false-color bar anchored to real lux values.
 */
function drawColorLegend(pdf: any, x: number, y: number, width: number, min: number, max: number) {
  const n = DIALUX_COLOR_SCALE.length
  const swatchW = width / n
  for (let i = 0; i < n; i++) {
    const c = DIALUX_COLOR_SCALE[i].color
    pdf.setFillColor(c[0], c[1], c[2])
    pdf.rect(x + i * swatchW, y, swatchW, 4, 'F')
  }

  pdf.setTextColor(80, 80, 80)
  pdf.setFontSize(8)
  pdf.setFont('helvetica', 'normal')
  pdf.text(`${Math.round(min)} lux`, x, y - 1)
  pdf.text(`${Math.round(max)} lux`, x + width - 16, y - 1)
}

export default usePDFExport
