/**
 * OrbitX Lighting Planner - IES Data Hook
 * 
 * React hook for loading and managing IES photometric data.
 */

import { useState, useEffect, useCallback, useRef } from 'react'
import type { IESData, IESProfile } from '../lib/photometry/types'
import { fetchAndParseIES, validateIESData } from '../lib/photometry/IESParser'

// =============================================================================
// Types
// =============================================================================

export interface IESDataState {
  // Profile list (lightweight, for selection UI)
  profiles: IESProfile[]
  profilesLoading: boolean
  profilesError: string | null
  
  // Full IES data cache (heavy, loaded on demand)
  iesDataCache: Map<string, IESData>
  loadingIds: Set<string>
  errors: Map<string, string>
}

export interface IESDataActions {
  loadProfiles: () => Promise<void>
  loadIESData: (profileId: string, url: string) => Promise<IESData | null>
  loadMultiple: (profiles: Array<{ id: string; url: string }>) => Promise<void>
  clearCache: () => void
  getIESData: (profileId: string) => IESData | undefined
}

// =============================================================================
// Hook Implementation
// =============================================================================

/**
 * Hook for managing IES profile list and full IES data loading.
 */
export function useIESData(): IESDataState & IESDataActions {
  // Profile list state
  const [profiles, setProfiles] = useState<IESProfile[]>([])
  const [profilesLoading, setProfilesLoading] = useState(false)
  const [profilesError, setProfilesError] = useState<string | null>(null)
  
  // Full IES data cache
  const [iesDataCache, setIesDataCache] = useState<Map<string, IESData>>(new Map())
  const [loadingIds, setLoadingIds] = useState<Set<string>>(new Set())
  const [errors, setErrors] = useState<Map<string, string>>(new Map())
  
  // Track loading promises to prevent duplicate requests
  const loadingPromisesRef = useRef<Map<string, Promise<IESData | null>>>(new Map())
  
  /**
   * Load the list of available IES profiles from the API.
   */
  const loadProfiles = useCallback(async () => {
    setProfilesLoading(true)
    setProfilesError(null)
    
    try {
      const response = await fetch('/api/ies')
      
      if (!response.ok) {
        throw new Error(`Failed to load profiles: ${response.status}`)
      }
      
      const data = await response.json()
      const profileList: IESProfile[] = data.profiles || []
      
      // Enhance profiles with additional data
      const enhanced = profileList.map(p => ({
        ...p,
        watts: extractWattsFromLabel(p.variantLabel),
        efficacy: p.lumens && extractWattsFromLabel(p.variantLabel) 
          ? p.lumens / extractWattsFromLabel(p.variantLabel)!
          : null
      }))
      
      setProfiles(enhanced)
    } catch (err) {
      const message = err instanceof Error ? err.message : 'Failed to load IES profiles'
      setProfilesError(message)
      console.error('Error loading IES profiles:', err)
    } finally {
      setProfilesLoading(false)
    }
  }, [])
  
  /**
   * Load full IES data for a specific profile.
   */
  const loadIESData = useCallback(async (
    profileId: string,
    url: string
  ): Promise<IESData | null> => {
    // Return cached data if available
    const cached = iesDataCache.get(profileId)
    if (cached) {
      return cached
    }
    
    // Return existing promise if already loading
    const existingPromise = loadingPromisesRef.current.get(profileId)
    if (existingPromise) {
      return existingPromise
    }
    
    // Start loading
    setLoadingIds(prev => new Set(prev).add(profileId))
    setErrors(prev => {
      const next = new Map(prev)
      next.delete(profileId)
      return next
    })
    
    const loadPromise = (async () => {
      try {
        const iesData = await fetchAndParseIES(url)
        
        // Validate
        const validation = validateIESData(iesData)
        if (!validation.valid) {
          throw new Error(validation.errors.join(', '))
        }
        
        // Cache the data
        setIesDataCache(prev => new Map(prev).set(profileId, iesData))
        
        return iesData
      } catch (err) {
        const message = err instanceof Error ? err.message : 'Failed to load IES data'
        setErrors(prev => new Map(prev).set(profileId, message))
        console.error(`Error loading IES data for ${profileId}:`, err)
        return null
      } finally {
        setLoadingIds(prev => {
          const next = new Set(prev)
          next.delete(profileId)
          return next
        })
        loadingPromisesRef.current.delete(profileId)
      }
    })()
    
    loadingPromisesRef.current.set(profileId, loadPromise)
    return loadPromise
  }, [iesDataCache])
  
  /**
   * Load multiple IES profiles in parallel.
   */
  const loadMultiple = useCallback(async (
    profilesToLoad: Array<{ id: string; url: string }>
  ) => {
    await Promise.all(
      profilesToLoad.map(p => loadIESData(p.id, p.url))
    )
  }, [loadIESData])
  
  /**
   * Clear the IES data cache.
   */
  const clearCache = useCallback(() => {
    setIesDataCache(new Map())
    setErrors(new Map())
  }, [])
  
  /**
   * Get IES data from cache (synchronous).
   */
  const getIESData = useCallback((profileId: string): IESData | undefined => {
    return iesDataCache.get(profileId)
  }, [iesDataCache])
  
  return {
    profiles,
    profilesLoading,
    profilesError,
    iesDataCache,
    loadingIds,
    errors,
    loadProfiles,
    loadIESData,
    loadMultiple,
    clearCache,
    getIESData
  }
}

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Extract wattage from a variant label like "Neptune 1200mm 40W".
 */
function extractWattsFromLabel(label: string): number | null {
  const match = label.match(/(\d+)\s*W\b/i)
  return match ? parseInt(match[1], 10) : null
}

/**
 * Group profiles by product name.
 */
export function groupProfilesByProduct(
  profiles: IESProfile[]
): Map<string, IESProfile[]> {
  const grouped = new Map<string, IESProfile[]>()
  
  for (const profile of profiles) {
    const existing = grouped.get(profile.productName) || []
    existing.push(profile)
    grouped.set(profile.productName, existing)
  }
  
  // Sort within each group
  Array.from(grouped.values()).forEach(list => {
    list.sort((a, b) => {
      // Sort by wattage if available
      const wattA = extractWattsFromLabel(a.variantLabel)
      const wattB = extractWattsFromLabel(b.variantLabel)
      if (wattA && wattB) return wattA - wattB
      // Fall back to label comparison
      return a.variantLabel.localeCompare(b.variantLabel)
    })
  })
  
  return grouped
}

/**
 * Find a profile by partial label match.
 */
export function findProfileByLabel(
  profiles: IESProfile[],
  searchLabel: string
): IESProfile | undefined {
  const lower = searchLabel.toLowerCase()
  
  // Try exact match first
  const exact = profiles.find(p => p.variantLabel.toLowerCase() === lower)
  if (exact) return exact
  
  // Try contains match
  return profiles.find(p => p.variantLabel.toLowerCase().includes(lower))
}

/**
 * Get summary stats for a profile.
 */
export function getProfileSummary(profile: IESProfile): string {
  const parts: string[] = []
  
  if (profile.lumens) {
    parts.push(`${Math.round(profile.lumens).toLocaleString()} lm`)
  }
  
  const watts = extractWattsFromLabel(profile.variantLabel)
  if (watts) {
    parts.push(`${watts}W`)
  }
  
  if (profile.efficacy) {
    parts.push(`${Math.round(profile.efficacy)} lm/W`)
  }
  
  if (profile.beamAngle) {
    parts.push(`${Math.round(profile.beamAngle)}°`)
  }
  
  return parts.join(' · ')
}
