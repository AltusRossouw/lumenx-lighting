/**
 * OrbitX Lighting Planner - Zustand Store
 * 
 * Central state management for the lighting planner application.
 * Handles room configuration, luminaires, display options, and calculation results.
 */

import { create } from 'zustand'
import { subscribeWithSelector, persist } from 'zustand/middleware'
import type {
  RoomConfig,
  LuminaireInstance,
  IESProfile,
  IESData,
  CalculationResults,
  DisplayOptions,
  ViewMode,
  PlannerTab,
  Project,
  DEFAULT_ROOM_CONFIG,
  DEFAULT_DISPLAY_OPTIONS,
  DEFAULT_LUMINAIRE
} from '../lib/photometry/types'

// Re-export defaults for convenience
export {
  DEFAULT_ROOM_CONFIG,
  DEFAULT_DISPLAY_OPTIONS,
  DEFAULT_LUMINAIRE
} from '../lib/photometry/types'

// =============================================================================
// Utility Functions
// =============================================================================

/**
 * Generate a unique ID without external dependencies.
 * Uses crypto.randomUUID() if available, otherwise falls back to timestamp + random.
 */
function generateId(): string {
  if (typeof crypto !== 'undefined' && crypto.randomUUID) {
    return crypto.randomUUID()
  }
  // Fallback for environments without crypto.randomUUID
  return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 11)}`
}

// =============================================================================
// Store State Interface
// =============================================================================

export interface PlannerState {
  // Project metadata
  projectId: string | null
  projectName: string
  isDirty: boolean
  
  // Room configuration
  room: RoomConfig
  
  // Imported CAD Geometry
  cadEntities: {
    type: string;
    layer: string;
    vertices: { x: number, y: number }[];
  }[]

  // Luminaires
  luminaires: LuminaireInstance[]
  selectedLuminaireId: string | null
  
  // IES Data (loaded from network)
  iesProfiles: IESProfile[]
  iesDataCache: Map<string, IESData>
  
  // Selected activity type for compliance
  activityType: string
  
  // Calculation state
  isCalculating: boolean
  calculationProgress: number
  calculationMessage: string
  results: CalculationResults | null
  
  // UI state
  viewMode: ViewMode
  activeTab: PlannerTab
  displayOptions: DisplayOptions
  
  // 2D canvas interaction state
  isPanning: boolean
  isPlacing: boolean
  placingIesProfileId: string | null
  panOffset: { x: number; y: number }
  zoom: number
}

export interface PlannerActions {
  // Project actions
  newProject: () => void
  loadProject: (project: Project) => void
  setProjectName: (name: string) => void
  markClean: () => void
  
  // Room actions
  setRoom: (room: Partial<RoomConfig>) => void
  setRoomDimensions: (width: number, length: number, height: number) => void
  setRoomBounds: (bounds: { min: { x: number; y: number }, max: { x: number; y: number } }) => void // Add this for DXF import
  setCadEntities: (entities: { type: string, layer: string, vertices: { x: number, y: number }[] }[]) => void
  setWorkPlaneHeight: (height: number) => void
  setReflectances: (ceiling: number, wall: number, floor: number) => void
  
  // Luminaire actions

  addLuminaire: (iesProfileId: string, position?: { x: number; y: number; z: number }) => string
  removeLuminaire: (id: string) => void
  updateLuminaire: (id: string, updates: Partial<LuminaireInstance>) => void
  selectLuminaire: (id: string | null) => void
  duplicateLuminaire: (id: string) => string | null
  clearAllLuminaires: () => void
  
  // Luminaire array operations
  createLuminaireGrid: (
    iesProfileId: string,
    rows: number,
    cols: number,
    spacingX: number,
    spacingZ: number,
    mountingHeight: number
  ) => void

  // Apply an optimized recommendation (places fixtures with the target dimming).
  applyRecommendedLayout: (
    iesProfileId: string,
    rec: { rows: number; cols: number; spacing: { x: number; z: number }; dimming: number; mountingHeight: number }
  ) => void
  
  // IES data actions
  setIESProfiles: (profiles: IESProfile[]) => void
  cacheIESData: (profileId: string, data: IESData) => void
  getIESData: (profileId: string) => IESData | undefined
  
  // Activity type
  setActivityType: (type: string) => void
  
  // Calculation actions
  setCalculating: (isCalculating: boolean, progress?: number, message?: string) => void
  setResults: (results: CalculationResults | null) => void
  
  // UI actions
  setViewMode: (mode: ViewMode) => void
  setActiveTab: (tab: PlannerTab) => void
  setDisplayOptions: (options: Partial<DisplayOptions>) => void
  toggleDisplayOption: (key: keyof DisplayOptions) => void
  
  // 2D canvas actions
  setZoom: (zoom: number) => void
  setPanOffset: (offset: { x: number; y: number }) => void
  startPlacing: (iesProfileId: string) => void
  stopPlacing: () => void
  setIsPanning: (isPanning: boolean) => void
  
  // Export helpers
  getProjectData: () => Project
}

// =============================================================================
// Default Values
// =============================================================================

const defaultRoom: RoomConfig = {
  width: 8,
  length: 10,
  height: 3.5,
  workPlaneHeight: 0.85,
  ceilingReflectance: 0.7,
  wallReflectance: 0.5,
  floorReflectance: 0.2,
  maintenanceFactor: 0.8,
  includeReflections: true,
  name: 'Untitled Room'
}

const defaultDisplayOptions: DisplayOptions = {
  showHeatmap: true,
  showIsolines: false,
  showValues: false,
  showFixtures: true,
  showGrid: true,
  showDimensions: true,
  heatmapOpacity: 0.7,
  heatmapColorScale: 'dialux',
  isolineLevels: [100, 200, 300, 500],
  showIsolineLabels: true,
  valueGridDensity: 2
}

// =============================================================================
// Store Implementation
// =============================================================================

export const usePlannerStore = create<PlannerState & PlannerActions>()(
  subscribeWithSelector(
    // persist(
      (set, get) => ({
        // Initial state
        projectId: null,
        projectName: 'Untitled Project',
        isDirty: false,
        
        room: defaultRoom,
        cadEntities: [],
        
        luminaires: [],
        selectedLuminaireId: null,
        
        iesProfiles: [],
        iesDataCache: new Map(),
        
        activityType: 'office-general',
        
        isCalculating: false,
        calculationProgress: 0,
        calculationMessage: '',
        results: null,
        
        viewMode: '3d',
        activeTab: 'room',
        displayOptions: defaultDisplayOptions,
        
        isPanning: false,
        isPlacing: false,
        placingIesProfileId: null,
        panOffset: { x: 0, y: 0 },
        zoom: 1,
        
        // Project actions
        newProject: () => set({
          projectId: null,
          projectName: 'Untitled Project',
          isDirty: false,
          room: defaultRoom,
          luminaires: [],
          selectedLuminaireId: null,
          results: null,
          activityType: 'office-general'
        }),
        
        loadProject: (project) => set({
          projectId: project.id,
          projectName: project.name,
          isDirty: false,
          room: project.room,
          luminaires: project.luminaires,
          selectedLuminaireId: null,
          activityType: project.activityType,
          results: project.lastResults ?? null
        }),
        
        setProjectName: (name) => set({ projectName: name, isDirty: true }),
        
        markClean: () => set({ isDirty: false }),
        
        // Room actions
        setRoom: (roomUpdates) => set((state) => ({
          room: { ...state.room, ...roomUpdates },
          isDirty: true,
          results: null // Invalidate results when room changes
        })),
        
        setRoomDimensions: (width, length, height) => set((state) => ({
          room: { ...state.room, width, length, height },
          isDirty: true,
          results: null
        })),

        setRoomBounds: (bounds) => set((state) => ({
          room: {
            ...state.room,
            width: bounds.max.x - bounds.min.x,
            length: bounds.max.y - bounds.min.y, // Assuming 2D DXF where Y is room length (Z in 3D)
            // Note: DXF Z is usually height, but 2D floor plans use X,Y.
            // Our 3D model: X=Width, Y=Height, Z=Length.
            // DXF Parser result: bounds.width, bounds.height
          },
          isDirty: true,
          results: null
        })),

        setCadEntities: (entities) => set({ cadEntities: entities }),
        
        setWorkPlaneHeight: (workPlaneHeight) => set((state) => ({
          room: { ...state.room, workPlaneHeight },
          isDirty: true,
          results: null
        })),
        
        setReflectances: (ceilingReflectance, wallReflectance, floorReflectance) => set((state) => ({
          room: { ...state.room, ceilingReflectance, wallReflectance, floorReflectance },
          isDirty: true,
          results: null
        })),
        
        // Luminaire actions
        addLuminaire: (iesProfileId, position) => {
          const id = generateId()
          const state = get()
          
          const newLuminaire: LuminaireInstance = {
            id,
            iesProfileId,
            position: position ?? { x: 0, y: state.room.height - 0.1, z: 0 },
            rotation: { tilt: 0, orientation: 0, roll: 0 },
            dimming: 1.0
          }
          
          set((state) => ({
            luminaires: [...state.luminaires, newLuminaire],
            selectedLuminaireId: id,
            isDirty: true,
            results: null
          }))
          
          return id
        },
        
        removeLuminaire: (id) => set((state) => ({
          luminaires: state.luminaires.filter(l => l.id !== id),
          selectedLuminaireId: state.selectedLuminaireId === id ? null : state.selectedLuminaireId,
          isDirty: true,
          results: null
        })),
        
        updateLuminaire: (id, updates) => set((state) => ({
          luminaires: state.luminaires.map(l => 
            l.id === id ? { ...l, ...updates } : l
          ),
          isDirty: true,
          results: null
        })),
        
        selectLuminaire: (id) => set({ selectedLuminaireId: id }),
        
        duplicateLuminaire: (id) => {
          const state = get()
          const source = state.luminaires.find(l => l.id === id)
          if (!source) return null
          
          const newId = generateId()
          const newLuminaire: LuminaireInstance = {
            ...source,
            id: newId,
            position: {
              ...source.position,
              x: source.position.x + 1, // Offset slightly
              z: source.position.z + 1
            },
            label: source.label ? `${source.label} (copy)` : undefined
          }
          
          set((state) => ({
            luminaires: [...state.luminaires, newLuminaire],
            selectedLuminaireId: newId,
            isDirty: true,
            results: null
          }))
          
          return newId
        },
        
        clearAllLuminaires: () => set({
          luminaires: [],
          selectedLuminaireId: null,
          isDirty: true,
          results: null
        }),
        
        createLuminaireGrid: (iesProfileId, rows, cols, spacingX, spacingZ, mountingHeight) => {
          const state = get()
          const { width, length } = state.room
          
          // Calculate starting position to center the grid
          const totalWidth = (cols - 1) * spacingX
          const totalLength = (rows - 1) * spacingZ
          const startX = -totalWidth / 2
          const startZ = -totalLength / 2
          
          const newLuminaires: LuminaireInstance[] = []
          
          for (let row = 0; row < rows; row++) {
            for (let col = 0; col < cols; col++) {
              newLuminaires.push({
                id: generateId(),
                iesProfileId,
                position: {
                  x: startX + col * spacingX,
                  y: mountingHeight,
                  z: startZ + row * spacingZ
                },
                rotation: { tilt: 0, orientation: 0, roll: 0 },
                dimming: 1.0,
                label: `Grid ${row + 1}-${col + 1}`
              })
            }
          }
          
          set((state) => ({
            luminaires: [...state.luminaires, ...newLuminaires],
            isDirty: true,
            results: null
          }))
        },

        applyRecommendedLayout: (iesProfileId, rec) => {
          const newLuminaires: LuminaireInstance[] = []

          for (let r = 0; r < rec.rows; r++) {
            for (let c = 0; c < rec.cols; c++) {
              newLuminaires.push({
                id: generateId(),
                iesProfileId,
                position: {
                  x: (c - (rec.cols - 1) / 2) * rec.spacing.x,
                  y: rec.mountingHeight,
                  z: (r - (rec.rows - 1) / 2) * rec.spacing.z,
                },
                rotation: { tilt: 0, orientation: 0, roll: 0 },
                dimming: rec.dimming,
              })
            }
          }

          set({
            luminaires: newLuminaires,
            selectedLuminaireId: null,
            isDirty: true,
            results: null
          })
        },
        
        // IES data actions
        setIESProfiles: (profiles) => set({ iesProfiles: profiles }),
        
        cacheIESData: (profileId, data) => set((state) => {
          const newCache = new Map(state.iesDataCache)
          newCache.set(profileId, data)
          return { iesDataCache: newCache }
        }),
        
        getIESData: (profileId) => get().iesDataCache.get(profileId),
        
        // Activity type
        setActivityType: (activityType) => set({ activityType, isDirty: true }),
        
        // Calculation actions
        setCalculating: (isCalculating, progress = 0, message = '') => set({
          isCalculating,
          calculationProgress: progress,
          calculationMessage: message
        }),
        
        setResults: (results) => set({ results, isDirty: true }),
        
        // UI actions
        setViewMode: (viewMode) => set({ viewMode }),
        
        setActiveTab: (activeTab) => set({ activeTab }),
        
        setDisplayOptions: (options) => set((state) => ({
          displayOptions: { ...state.displayOptions, ...options }
        })),
        
        toggleDisplayOption: (key) => set((state) => {
          const current = state.displayOptions[key]
          if (typeof current === 'boolean') {
            return {
              displayOptions: {
                ...state.displayOptions,
                [key]: !current
              }
            }
          }
          return {}
        }),
        
        // 2D canvas actions
        setZoom: (zoom) => set({ zoom: Math.max(0.1, Math.min(5, zoom)) }),
        
        setPanOffset: (panOffset) => set({ panOffset }),
        
        startPlacing: (iesProfileId) => set({
          isPlacing: true,
          placingIesProfileId: iesProfileId
        }),
        
        stopPlacing: () => set({
          isPlacing: false,
          placingIesProfileId: null
        }),
        
        setIsPanning: (isPanning) => set({ isPanning }),
        
        // Export helpers
        getProjectData: () => {
          const state = get()
          return {
            id: state.projectId ?? generateId(),
            name: state.projectName,
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
            room: state.room,
            luminaires: state.luminaires,
            activityType: state.activityType,
            iesProfileIds: Array.from(new Set(state.luminaires.map(l => l.iesProfileId))),
            lastResults: state.results ?? undefined
          }
        }
      })
    // , {
    //   name: 'orbitx-planner-state',
    //   partialize: (state) => ({
    //     room: state.room,
    //     displayOptions: state.displayOptions,
    //     activityType: state.activityType
    //   })
    // })
  )
)

// =============================================================================
// Selectors for optimized re-renders
// =============================================================================

export const selectRoom = (state: PlannerState) => state.room
export const selectLuminaires = (state: PlannerState) => state.luminaires
export const selectSelectedLuminaire = (state: PlannerState) => 
  state.luminaires.find(l => l.id === state.selectedLuminaireId)
export const selectResults = (state: PlannerState) => state.results
export const selectDisplayOptions = (state: PlannerState) => state.displayOptions
export const selectIsCalculating = (state: PlannerState) => state.isCalculating
export const selectViewMode = (state: PlannerState) => state.viewMode
export const selectActiveTab = (state: PlannerState) => state.activeTab

// =============================================================================
// Computed values helpers
// =============================================================================

export const selectTotalPower = (state: PlannerState) => {
  let total = 0
  for (const lum of state.luminaires) {
    const ies = state.iesDataCache.get(lum.iesProfileId)
    if (ies) {
      total += ies.inputWatts * lum.dimming
    }
  }
  return total
}

export const selectTotalLumens = (state: PlannerState) => {
  let total = 0
  for (const lum of state.luminaires) {
    const ies = state.iesDataCache.get(lum.iesProfileId)
    if (ies) {
      total += ies.totalLumens * lum.dimming
    }
  }
  return total
}
