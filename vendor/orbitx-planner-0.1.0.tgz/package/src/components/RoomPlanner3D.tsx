"use client"

import { Canvas, useFrame } from '@react-three/fiber'
import { OrbitControls, PerspectiveCamera } from '@react-three/drei'
import { Suspense, useEffect, useMemo, useRef, useState, useImperativeHandle, forwardRef } from 'react'
import * as THREE from 'three'
import NavigationCube from './NavigationCube'
import { IESProfile } from '../types/ies'
import { IESLoader } from 'three/examples/jsm/loaders/IESLoader.js'

const clamp = (value: number, min: number, max: number) => Math.min(Math.max(value, min), max)

interface RoomPlanner3DProps {
  width: number
  length: number
  height: number
  lights: number
  rows?: number
  columns?: number
  iesProfile?: IESProfile | null
  showHeatmap?: boolean
  showNavigationCube?: boolean
  onReady?: () => void
  // New: custom positions (takes priority over grid calculation)
  customPositions?: { x: number; y: number; z: number; orientation?: number }[]
}

export interface RoomPlanner3DHandle {
  captureView: (view: 'top' | 'left' | 'isometric') => Promise<string>
}

const RoomMesh = ({ width, length, height }: { width: number; length: number; height: number }) => {
  // Wall panels with cleaner appearance
  const wallMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#e5e7eb',
    transparent: true,
    opacity: 0.15,
    side: THREE.DoubleSide,
    roughness: 0.9,
    metalness: 0.05
  }), [])

  // Floor with subtle grid pattern
  const floorMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#f9fafb',
    transparent: true,
    opacity: 0.8,
    roughness: 0.8
  }), [])
  const floorGeometry = useMemo(() => new THREE.PlaneGeometry(width, length), [width, length])

  // Ceiling
  const ceilingMaterial = useMemo(() => new THREE.MeshStandardMaterial({
    color: '#ffffff',
    transparent: true,
    opacity: 0.1,
    side: THREE.DoubleSide,
    roughness: 0.95
  }), [])
  const ceilingGeometry = useMemo(() => new THREE.PlaneGeometry(width, length), [width, length])

  // Wall edge lines
  const edgeMaterial = useMemo(() => new THREE.LineBasicMaterial({ color: '#9ca3af', linewidth: 2 }), [])

  useEffect(() => {
    return () => {
      wallMaterial.dispose()
      edgeMaterial.dispose()
      floorGeometry.dispose()
      floorMaterial.dispose()
      ceilingGeometry.dispose()
      ceilingMaterial.dispose()
    }
  }, [edgeMaterial, floorGeometry, floorMaterial, wallMaterial, ceilingGeometry, ceilingMaterial])

  return (
    <group>
      {/* Floor */}
      <mesh
        rotation={[-Math.PI / 2, 0, 0]}
        position={[0, -height / 2, 0]}
        geometry={floorGeometry}
        material={floorMaterial}
        receiveShadow
      />
      
      {/* Ceiling */}
      <mesh
        rotation={[Math.PI / 2, 0, 0]}
        position={[0, height / 2, 0]}
        geometry={ceilingGeometry}
        material={ceilingMaterial}
      />

      {/* Wall outlines - back */}
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              -width / 2, -height / 2, -length / 2,
              width / 2, -height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              width / 2, -height / 2, -length / 2,
              width / 2, height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              width / 2, height / 2, -length / 2,
              -width / 2, height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              -width / 2, height / 2, -length / 2,
              -width / 2, -height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>

      {/* Vertical edges */}
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              -width / 2, -height / 2, length / 2,
              -width / 2, -height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>
      <line>
        <bufferGeometry attach="geometry">
          <bufferAttribute
            attach="attributes-position"
            args={[new Float32Array([
              width / 2, -height / 2, length / 2,
              width / 2, -height / 2, -length / 2,
            ]), 3]}
          />
        </bufferGeometry>
        <primitive object={edgeMaterial} attach="material" />
      </line>
    </group>
  )
}

const LightFixture = ({
  position,
  roomHeight,
  spread,
  iesTexture,
  lumens,
  beamAngle,
  orientation = 0,
}: {
  position: [number, number, number]
  roomHeight: number
  spread: number
  iesTexture: THREE.DataTexture | null
  lumens?: number | null
  beamAngle?: number | null
  orientation?: number
}) => {
  const spotRef = useRef<THREE.SpotLight>(null)
  const target = useMemo(() => new THREE.Object3D(), [])
  // Yaw the fixture so its C0 reference axis matches the photometric engine
  // (rotation.y = orientation, in radians).
  const orientationRad = THREE.MathUtils.degToRad(orientation)
  const normalizedIntensity = useMemo(() => {
    if (!lumens || lumens <= 0) return 2
    const baseLumens = 4000
    return clamp(lumens / baseLumens, 0.6, 6)
  }, [lumens])
  const glowIntensity = useMemo(() => clamp((lumens ?? 4000) / 4000, 0.4, 2), [lumens])

  useEffect(() => {
    target.position.set(position[0], position[1] - roomHeight + 0.5, position[2])
    target.updateMatrixWorld()
  }, [position, roomHeight, target])

  useEffect(() => {
    if (spotRef.current) {
      ;(spotRef.current as unknown as { iesTexture?: THREE.DataTexture | null }).iesTexture = iesTexture
    }
  }, [iesTexture])

  const spotlightAngle = useMemo(() => {
    if (!beamAngle || beamAngle <= 0) {
      return Math.PI / 3
    }
    const clamped = clamp(beamAngle, 8, 170)
    return THREE.MathUtils.degToRad(clamped / 2)
  }, [beamAngle])

  return (
    <>
      <group position={position} rotation={[0, orientationRad, 0]}>
        {/* Fixture housing */}
        <mesh>
          <cylinderGeometry args={[0.25, 0.35, 0.15, 16]} />
          <meshStandardMaterial color="#e5e7eb" metalness={0.6} roughness={0.4} />
        </mesh>
        {/* Light glow */}
        <mesh>
          <sphereGeometry args={[0.2, 16, 16]} />
          <meshStandardMaterial emissive="#fbbf24" emissiveIntensity={glowIntensity} color="#facc15" transparent opacity={0.8} />
        </mesh>
        <spotLight
          ref={spotRef}
          color="white"
          intensity={normalizedIntensity}
          distance={spread}
          angle={spotlightAngle}
          penumbra={0.5}
          castShadow
          shadow-mapSize-width={1024}
          shadow-mapSize-height={1024}
          shadow-bias={-0.0001}
          target={target}
        />
        <pointLight intensity={glowIntensity} distance={5} decay={2} color="#fbbf24" />
      </group>
      <primitive object={target} />
    </>
  )
}

const LightsGrid = ({
  positions,
  height,
  width,
  length,
  iesTexture,
  lumens,
  beamAngle,
}: {
  positions: { position: [number, number, number]; orientation: number }[]
  height: number
  width: number
  length: number
  iesTexture: THREE.DataTexture | null
  lumens?: number | null
  beamAngle?: number | null
}) => {
  return (
    <>
      {positions.map((p, idx) => (
        <LightFixture
          key={idx}
          position={p.position}
          orientation={p.orientation}
          roomHeight={height}
          spread={Math.max(width, length) * clamp((lumens ?? 4000) / 4000, 1, 3)}
          iesTexture={iesTexture}
          lumens={lumens}
          beamAngle={beamAngle}
        />
      ))}
    </>
  )
}

const gradientStops: Array<{ stop: number; color: [number, number, number] }> = [
  { stop: 0, color: [37, 99, 235] },
  { stop: 0.25, color: [34, 211, 238] },
  { stop: 0.5, color: [250, 204, 21] },
  { stop: 0.75, color: [249, 115, 22] },
  { stop: 1, color: [239, 68, 68] },
]

const interpolateGradient = (value: number): [number, number, number] => {
  const clamped = clamp(value, 0, 1)
  for (let i = 0; i < gradientStops.length - 1; i++) {
    const current = gradientStops[i]
    const next = gradientStops[i + 1]
    if (clamped >= current.stop && clamped <= next.stop) {
      const range = next.stop - current.stop || 1
      const t = (clamped - current.stop) / range
      return [
        Math.round(THREE.MathUtils.lerp(current.color[0], next.color[0], t)),
        Math.round(THREE.MathUtils.lerp(current.color[1], next.color[1], t)),
        Math.round(THREE.MathUtils.lerp(current.color[2], next.color[2], t)),
      ]
    }
  }
  return gradientStops[gradientStops.length - 1].color
}

const HeatmapPlane = ({
  width,
  length,
  height,
  positions,
  lumens,
}: {
  width: number
  length: number
  height: number
  positions: { position: [number, number, number]; orientation: number }[]
  lumens?: number | null
}) => {
  const resolution = 48
  const lumensPerFixture = lumens ?? 4000
  const meshRef = useRef<THREE.Mesh>(null)

  const texture = useMemo(() => {
    if (positions.length === 0) return null
    const canvas = document.createElement('canvas')
    canvas.width = resolution
    canvas.height = resolution
    const ctx = canvas.getContext('2d')
    if (!ctx) return null

    const intensities: number[] = []
    for (let x = 0; x < resolution; x++) {
      for (let z = 0; z < resolution; z++) {
        const px = (x + 0.5) * (width / resolution) - width / 2
        const pz = (z + 0.5) * (length / resolution) - length / 2
        let accum = 0
        positions.forEach((p) => {
          const [lx, ly, lz] = p.position
          const dx = lx - px
          const dz = lz - pz
          const dy = ly + height / 2
          const distanceSq = dx * dx + dz * dz + dy * dy
          const falloff = 1 / (distanceSq + 1)
          accum += lumensPerFixture * falloff
        })
        intensities.push(accum)
      }
    }

    const max = intensities.reduce((m, val) => Math.max(m, val), 0.0001)
    intensities.forEach((value, index) => {
      const normalized = clamp(value / max, 0, 1)
      const [r, g, b] = interpolateGradient(normalized)
      ctx.fillStyle = `rgba(${r}, ${g}, ${b}, ${0.35 + normalized * 0.4})`
      const x = index % resolution
      const z = Math.floor(index / resolution)
      ctx.fillRect(x, resolution - 1 - z, 1, 1)
    })

    const canvasTexture = new THREE.CanvasTexture(canvas)
    canvasTexture.anisotropy = 4
    canvasTexture.wrapS = THREE.ClampToEdgeWrapping
    canvasTexture.wrapT = THREE.ClampToEdgeWrapping
    canvasTexture.needsUpdate = true
    console.log('Heatmap texture created:', { width, length, height, positionsCount: positions.length })
    return canvasTexture
  }, [height, length, lumensPerFixture, positions, width])

  useEffect(() => {
    if (meshRef.current && texture) {
      const material = meshRef.current.material as THREE.MeshBasicMaterial
      if (material.map !== texture) {
        material.map = texture
        material.needsUpdate = true
      }
    }
  }, [texture])

  useEffect(() => {
    return () => {
      texture?.dispose()
    }
  }, [texture])

  if (!texture) {
    return null
  }

  return (
    <mesh ref={meshRef} rotation={[-Math.PI / 2, 0, 0]} position={[0, -height / 2 + 0.02, 0]} renderOrder={999}>
      <planeGeometry args={[width, length]} />
      <meshBasicMaterial
        map={texture}
        transparent
        opacity={1.0}
        depthWrite={false}
        depthTest={false}
        side={THREE.DoubleSide}
        toneMapped={false}
      />
    </mesh>
  )
}

// Component to track camera rotation and update cube
const CameraRotationTracker = ({ 
  onRotationChange, 
  manualRotation, 
  controls, 
  camera,
  width,
  height,
  length 
}: { 
  onRotationChange: (x: number, y: number) => void
  manualRotation: { x: number; y: number } | null
  controls: any
  camera: THREE.PerspectiveCamera | null
  width: number
  height: number
  length: number
}) => {
  const lastManualRotation = useRef<{ x: number; y: number } | null>(null)
  
  useFrame(() => {
    // If manually rotating cube, update camera to match
    if (manualRotation && camera && controls) {
      // Only update if rotation actually changed
      if (!lastManualRotation.current || 
          lastManualRotation.current.x !== manualRotation.x || 
          lastManualRotation.current.y !== manualRotation.y) {
        const dist = Math.max(width, length) * 1.2
        const rotXRad = THREE.MathUtils.degToRad(-manualRotation.x)
        const rotYRad = THREE.MathUtils.degToRad(manualRotation.y)
        
        // Calculate camera position from rotation angles
        const x = dist * Math.sin(rotYRad) * Math.cos(rotXRad)
        const y = dist * Math.sin(rotXRad)
        const z = dist * Math.cos(rotYRad) * Math.cos(rotXRad)
        
        camera.position.set(x, y, z)
        if (controls.target) {
          controls.target.set(0, 0, 0)
        }
        camera.lookAt(0, 0, 0)
        if (controls.update) controls.update()
        
        lastManualRotation.current = { ...manualRotation }
      }
    } else {
      lastManualRotation.current = null
    }
    
    // Always sync cube with camera rotation
    if (camera) {
      const euler = new THREE.Euler().setFromQuaternion(camera.quaternion, 'YXZ')
      const rotX = THREE.MathUtils.radToDeg(euler.x)
      const rotY = THREE.MathUtils.radToDeg(euler.y)
      onRotationChange(rotX, rotY)
    }
  })
  return null
}

// Component to notify parent when scene is ready
const ReadyNotifier = ({ 
  onReady, 
  notifiedRef 
}: { 
  onReady?: () => void
  notifiedRef: React.MutableRefObject<boolean>
}) => {
  useFrame(() => {
    if (!notifiedRef.current && onReady) {
      notifiedRef.current = true
      console.log('ReadyNotifier: Scene is ready, notifying parent')
      // Use setTimeout to ensure it's called outside the render loop
      setTimeout(() => onReady(), 0)
    }
  })
  return null
}

const RoomPlanner3D = forwardRef<RoomPlanner3DHandle, RoomPlanner3DProps>(({ width, length, height, lights, rows: propRows, columns: propColumns, iesProfile, showHeatmap = true, showNavigationCube = true, onReady, customPositions }, ref) => {
  const [iesTexture, setIesTexture] = useState<THREE.DataTexture | null>(null)
  const [cubeRotX, setCubeRotX] = useState(-25)
  const [cubeRotY, setCubeRotY] = useState(35)
  const manualRotationRef = useRef<{ x: number; y: number } | null>(null)
  const manualRotationTimeoutRef = useRef<NodeJS.Timeout | null>(null)
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null)
  const controlsRef = useRef<any>(null)
  const canvasContainerRef = useRef<HTMLDivElement>(null)
  const readyNotifiedRef = useRef(false)

  useEffect(() => {
    console.log('RoomPlanner3D showNavigationCube:', showNavigationCube)
    console.log('RoomPlanner3D component mounted with onReady:', !!onReady)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  useImperativeHandle(ref, () => ({
    captureView: async (view: 'top' | 'left' | 'isometric') => {
      console.log(`captureView called with view: ${view}`)
      return new Promise<string>((resolve) => {
        const cam = cameraRef.current
        const controls = controlsRef.current
        console.log('Camera ref:', cam)
        console.log('Controls ref:', controls)
        
        if (!cam || !controls) {
          console.error('Camera or controls not available')
          resolve('')
          return
        }

        // Store current position
        const originalPos = cam.position.clone()
        const originalTarget = controls.target ? controls.target.clone() : new THREE.Vector3(0, 0, 0)
        console.log('Original position stored:', originalPos)

        // Set view position
        const baseDist = Math.max(width, length) * 1.5
        const heightDist = Math.max(width, length, height) * 1.8
        const sideElevation = height * 0.3
        const isoHeight = Math.max(width, length) * 1.2 // Higher elevation for isometric
        
        let targetPos: THREE.Vector3
        if (view === 'top') {
          targetPos = new THREE.Vector3(0, heightDist, 0)
        } else if (view === 'left') {
          targetPos = new THREE.Vector3(-baseDist, sideElevation, 0)
        } else {
          targetPos = new THREE.Vector3(baseDist, isoHeight, baseDist)
        }

        console.log('Moving camera to:', targetPos)
        cam.position.copy(targetPos)
        controls.target.set(0, 0, 0)
        cam.lookAt(0, 0, 0)
        if (controls.update) controls.update()

        // Wait for render, then capture
        setTimeout(() => {
          console.log('Attempting to capture canvas...')
          const canvas = canvasContainerRef.current?.querySelector('canvas')
          console.log('Canvas element:', canvas)
          
          if (canvas) {
            try {
              const dataUrl = canvas.toDataURL('image/png')
              console.log('Canvas captured, data URL length:', dataUrl.length)
              // Restore original position
              cam.position.copy(originalPos)
              if (controls.target) controls.target.copy(originalTarget)
              if (controls.update) controls.update()
              console.log('Camera position restored')
              resolve(dataUrl)
            } catch (err) {
              console.error('Error capturing canvas:', err)
              resolve('')
            }
          } else {
            console.error('Canvas element not found!')
            resolve('')
          }
        }, 500)
      })
    }
  }))
  const lightPositions = useMemo(() => {
    // Use custom positions if provided
    if (customPositions && customPositions.length > 0) {
      return customPositions.map(pos => ({
        position: [pos.x, pos.y, pos.z] as [number, number, number],
        orientation: pos.orientation ?? 0
      }))
    }
    
    // Otherwise use grid calculation
    // Use provided rows/columns if available, otherwise calculate from lights
    const rows = propRows ?? Math.ceil(Math.sqrt(lights))
    const cols = propColumns ?? Math.ceil(lights / rows)
    const spacingX = width / (cols + 1)
    const spacingZ = length / (rows + 1)
    const y = height / 2 - 0.5

    const points: { position: [number, number, number]; orientation: number }[] = []
    for (let r = 1; r <= rows; r++) {
      for (let c = 1; c <= cols; c++) {
        if (points.length >= lights) break
        points.push({ position: [c * spacingX - width / 2, y, r * spacingZ - length / 2], orientation: 0 })
      }
    }
    return points
  }, [height, length, lights, width, propRows, propColumns, customPositions])

  useEffect(() => {
    let active = true
    if (!iesProfile?.url) {
      setIesTexture(null)
      return
    }

    const loader = new IESLoader()
    loader.load(
      iesProfile.url,
      (texture) => {
        if (active) {
          setIesTexture(texture)
        }
      },
      undefined,
      (error) => {
        console.error('Unable to load IES file', error)
        if (active) {
          setIesTexture(null)
        }
      }
    )

    return () => {
      active = false
    }
  }, [iesProfile])

  return (
    <div ref={canvasContainerRef} style={{ height: '100%', width: '100%' }} className="bg-gradient-to-br from-gray-100 via-gray-50 to-white overflow-hidden">
      <Canvas shadows gl={{ preserveDrawingBuffer: true }}>
        <color attach="background" args={['#f9fafb']} />
        <Suspense fallback={null}>
          <ReadyNotifier onReady={onReady} notifiedRef={readyNotifiedRef} />
          <CameraRotationTracker 
            onRotationChange={(x, y) => {
              setCubeRotX(x)
              setCubeRotY(y)
            }}
            manualRotation={manualRotationRef.current}
            controls={controlsRef.current}
            camera={cameraRef.current}
            width={width}
            height={height}
            length={length}
          />
          <ambientLight intensity={0.6} />
          <directionalLight position={[10, 15, 10]} intensity={0.5} castShadow />
          <directionalLight position={[-10, 10, -10]} intensity={0.3} />
          <PerspectiveCamera ref={cameraRef as any} makeDefault position={[width * 0.8, height * 8, length * 0.8]} fov={50} />
          <gridHelper args={[Math.max(width, length) * 1.2, 20, '#d1d5db', '#e5e7eb']} position={[0, -height / 2, 0]} />
          <OrbitControls ref={controlsRef as any} enablePan enableZoom enableRotate />
          <RoomMesh width={width} length={length} height={height} />
          {showHeatmap && (
            <HeatmapPlane
              width={width}
              length={length}
              height={height}
              positions={lightPositions}
              lumens={iesProfile?.lumens}
            />
          )}
          <LightsGrid
            positions={lightPositions}
            width={width}
            length={length}
            height={height}
            iesTexture={iesTexture}
            lumens={iesProfile?.lumens}
            beamAngle={iesProfile?.beamAngle}
          />
        </Suspense>
      </Canvas>
      {/* Navigation cube overlay */}
      {showNavigationCube && (
        <div className="absolute right-4 bottom-4 z-40 pointer-events-none">
          <NavigationCube
          size={100}
          rotateX={cubeRotX}
          rotateY={cubeRotY}
          onManualRotate={(rotX, rotY) => {
            setCubeRotX(rotX)
            setCubeRotY(rotY)
            manualRotationRef.current = { x: rotX, y: rotY }
            
            // Clear any existing timeout
            if (manualRotationTimeoutRef.current) {
              clearTimeout(manualRotationTimeoutRef.current)
            }
            
            // Set timeout to clear manual rotation after dragging stops
            manualRotationTimeoutRef.current = setTimeout(() => {
              manualRotationRef.current = null
            }, 150)
          }}
          onViewSelect={(view) => {
            // Compute preset camera positions relative to room size
            // Use larger multiplier to ensure full room fits in frame
            const baseDist = Math.max(width, length) * 1.5
            const heightDist = Math.max(width, length, height) * 1.8
            const sideElevation = height * 0.3
            const isoElevation = Math.max(width, length) * 1.0 // Higher angle for isometric views
            const center = [0, 0, 0] as [number, number, number]
            let targetPos: [number, number, number] = [baseDist, sideElevation, baseDist]
            if (view === 'front') targetPos = [0, sideElevation, baseDist]
            if (view === 'back') targetPos = [0, sideElevation, -baseDist]
            if (view === 'left') targetPos = [-baseDist, sideElevation, 0]
            if (view === 'right') targetPos = [baseDist, sideElevation, 0]
            if (view === 'top') targetPos = [0, heightDist, 0]
            if (view === 'bottom') targetPos = [0, -heightDist, 0]
            if (view === 'iso1') targetPos = [baseDist, isoElevation, baseDist] // Front-Right-Top
            if (view === 'iso2') targetPos = [baseDist, isoElevation, -baseDist] // Back-Right-Top
            if (view === 'iso3') targetPos = [-baseDist, isoElevation, baseDist] // Front-Left-Top
            if (view === 'iso4') targetPos = [-baseDist, isoElevation, -baseDist] // Back-Left-Top

            // animate camera
            const cam = cameraRef.current
            const controls = controlsRef.current
            if (!cam || !controls) return

            const camNN = cam as THREE.PerspectiveCamera
            const controlsNN = controls as any
            const fromPos = camNN.position.clone()
            const toPos = new THREE.Vector3(targetPos[0], targetPos[1], targetPos[2])
            const fromTarget = controlsNN?.target?.clone ? controlsNN.target.clone() : new THREE.Vector3(0, 0, 0)
            const toTarget = new THREE.Vector3(center[0], center[1], center[2])

            const duration = 600
            let start: number | null = null

            function step(ts: number) {
              if (!start) start = ts
              const t = Math.min(1, (ts - start) / duration)
              camNN.position.lerpVectors(fromPos, toPos, t)
              if (controlsNN.target && controlsNN.target.lerpVectors) {
                controlsNN.target.lerpVectors(fromTarget, toTarget, t)
              } else if (controlsNN.target) {
                controlsNN.target = toTarget
              }
              if ((camNN as any).updateProjectionMatrix) (camNN as any).updateProjectionMatrix()
              if (controlsNN.update) controlsNN.update()
              if (t < 1) requestAnimationFrame(step)
            }

            requestAnimationFrame(step)
          }} />
      </div>
      )}
    </div>
  )
})

RoomPlanner3D.displayName = 'RoomPlanner3D'

export default RoomPlanner3D
