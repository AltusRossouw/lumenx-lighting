/**
 * OrbitX Lighting Planner - 2D Plan Viewer
 * 
 * Canvas-based 2D top-down view of the room with:
 * - Room outline with dimensions
 * - Luminaire positions (draggable)
 * - Heatmap overlay
 * - Isolines overlay
 * - Value grid overlay
 * - Pan and zoom controls
 * - Click-to-place luminaires
 */

'use client'

import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { IsolinesCanvas, generateIsolines } from './Isolines'
import { ValueGridCanvas } from './ValueGrid'
import type { 
  CalculationGrid, 
  LuminaireInstance, 
  RoomConfig,
  IESData,
  ColorStop 
} from '../../lib/photometry/types'
import { DIALUX_COLOR_SCALE, THERMAL_COLOR_SCALE } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface Viewer2DProps {
  className?: string
  onLuminaireSelect?: (id: string | null) => void
  onLuminaireMove?: (id: string, x: number, z: number) => void
  onPlaceLuminaire?: (x: number, z: number) => void
}

interface CanvasTransform {
  scale: number
  offsetX: number
  offsetY: number
}

// =============================================================================
// Constants
// =============================================================================

const GRID_COLOR = '#e5e7eb'
const ROOM_STROKE_COLOR = '#374151'
const ROOM_FILL_COLOR = '#f9fafb'
const DIMENSION_COLOR = '#6b7280'
const LUMINAIRE_COLOR = '#0084ff'
const LUMINAIRE_SELECTED_COLOR = '#f59e0b'
const MIN_ZOOM = 0.2
const MAX_ZOOM = 5

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Get color scale based on option.
 */
function getColorScale(scale: 'dialux' | 'thermal' | 'grayscale'): ColorStop[] {
  switch (scale) {
    case 'thermal':
      return THERMAL_COLOR_SCALE
    case 'grayscale':
      return [
        { position: 0, color: [50, 50, 50] },
        { position: 0.5, color: [150, 150, 150] },
        { position: 1, color: [255, 255, 255] }
      ]
    default:
      return DIALUX_COLOR_SCALE
  }
}

/**
 * Interpolate color from scale.
 */
function interpolateColor(value: number, min: number, max: number, scale: ColorStop[]): [number, number, number] {
  if (max <= min) return scale[Math.floor(scale.length / 2)].color as [number, number, number]
  
  const t = Math.max(0, Math.min(1, (value - min) / (max - min)))
  
  let lower = scale[0]
  let upper = scale[scale.length - 1]
  
  for (let i = 0; i < scale.length - 1; i++) {
    if (t >= scale[i].position && t <= scale[i + 1].position) {
      lower = scale[i]
      upper = scale[i + 1]
      break
    }
  }
  
  const range = upper.position - lower.position
  const localT = range > 0 ? (t - lower.position) / range : 0
  
  return [
    Math.round(lower.color[0] + (upper.color[0] - lower.color[0]) * localT),
    Math.round(lower.color[1] + (upper.color[1] - lower.color[1]) * localT),
    Math.round(lower.color[2] + (upper.color[2] - lower.color[2]) * localT)
  ]
}

// =============================================================================
// Main Component
// =============================================================================

export function Viewer2D({
  className = '',
  onLuminaireSelect,
  onLuminaireMove,
  onPlaceLuminaire
}: Viewer2DProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  const containerRef = useRef<HTMLDivElement>(null)
  
  // Store state
  const room = usePlannerStore(state => state.room)
  const cadEntities = usePlannerStore(state => state.cadEntities)
  const luminaires = usePlannerStore(state => state.luminaires)
  const selectedLuminaireId = usePlannerStore(state => state.selectedLuminaireId)
  const results = usePlannerStore(state => state.results)
  const displayOptions = usePlannerStore(state => state.displayOptions)
  const isPlacing = usePlannerStore(state => state.isPlacing)
  const iesDataCache = usePlannerStore(state => state.iesDataCache)
  
  const zoom = usePlannerStore(state => state.zoom)
  const panOffset = usePlannerStore(state => state.panOffset)
  const setZoom = usePlannerStore(state => state.setZoom)
  const setPanOffset = usePlannerStore(state => state.setPanOffset)
  const selectLuminaire = usePlannerStore(state => state.selectLuminaire)
  const updateLuminaire = usePlannerStore(state => state.updateLuminaire)
  const addLuminaire = usePlannerStore(state => state.addLuminaire)
  const placingIesProfileId = usePlannerStore(state => state.placingIesProfileId)
  const stopPlacing = usePlannerStore(state => state.stopPlacing)
  
  // Local state
  const [canvasSize, setCanvasSize] = useState({ width: 800, height: 600 })
  const [isDragging, setIsDragging] = useState(false)
  const [isPanning, setIsPanning] = useState(false)
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 })
  const [draggedLuminaireId, setDraggedLuminaireId] = useState<string | null>(null)
  const [mousePos, setMousePos] = useState<{ x: number; z: number } | null>(null)
  
  // Center the view when component mounts
  useEffect(() => {
    setZoom(1)
    setPanOffset({ x: 0, y: 0 })
  }, [setZoom, setPanOffset])
  
  // Calculate transform for room -> canvas coordinates
  // Note: canvasSize is in device pixels (multiplied by devicePixelRatio)
  // We need to use CSS pixels for the transform since ctx.setTransform handles DPR scaling
  const transform = useMemo((): CanvasTransform => {
    const { width, length } = room
    const dpr = typeof window !== 'undefined' ? window.devicePixelRatio : 1
    const cssWidth = canvasSize.width / dpr
    const cssHeight = canvasSize.height / dpr
    const padding = 60
    
    const scaleX = (cssWidth - padding * 2) / width
    const scaleZ = (cssHeight - padding * 2) / length
    const scale = Math.min(scaleX, scaleZ) * zoom
    
    return {
      scale,
      offsetX: cssWidth / 2 + panOffset.x,
      offsetY: cssHeight / 2 + panOffset.y
    }
  }, [room, canvasSize, zoom, panOffset])
  
  // Room to canvas coordinate conversion
  const roomToCanvas = useCallback((x: number, z: number) => {
    return {
      x: transform.offsetX + x * transform.scale,
      y: transform.offsetY + z * transform.scale
    }
  }, [transform])
  
  // Canvas to room coordinate conversion
  const canvasToRoom = useCallback((canvasX: number, canvasY: number) => {
    return {
      x: (canvasX - transform.offsetX) / transform.scale,
      z: (canvasY - transform.offsetY) / transform.scale
    }
  }, [transform])
  
  // Handle resize
  useEffect(() => {
    const container = containerRef.current
    if (!container) return
    
    const resizeObserver = new ResizeObserver((entries) => {
      for (const entry of entries) {
        const { width, height } = entry.contentRect
        setCanvasSize({ 
          width: Math.floor(width * window.devicePixelRatio),
          height: Math.floor(height * window.devicePixelRatio)
        })
      }
    })
    
    resizeObserver.observe(container)
    return () => resizeObserver.disconnect()
  }, [])
  
  // Main render effect
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    const { width, length } = room
    const { scale, offsetX, offsetY } = transform
    
    // Scale for retina displays
    const dpr = window.devicePixelRatio
    const cssWidth = canvasSize.width / dpr
    const cssHeight = canvasSize.height / dpr
    const cssCanvasSize = { width: cssWidth, height: cssHeight }
    
    // Clear canvas (use full buffer size)
    ctx.clearRect(0, 0, canvasSize.width, canvasSize.height)
    
    // Set transform for DPR scaling
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0)
    
    // Draw background grid (use CSS size since we're drawing in CSS coords after setTransform)
    if (displayOptions.showGrid) {
      drawGrid(ctx, room, transform, cssCanvasSize)
    }
    
    // Draw heatmap (if results available)
    if (displayOptions.showHeatmap && results?.grid) {
      drawHeatmap(ctx, results.grid, transform, displayOptions.heatmapOpacity, displayOptions.heatmapColorScale)
    }
    
    // Draw room outline
    drawRoomOutline(ctx, room, transform)
    
    // Draw CAD entities if available
    if (cadEntities && cadEntities.length > 0) {
        drawCadEntities(ctx, cadEntities, transform)
    }
    
    // Draw dimensions
    if (displayOptions.showDimensions) {
      drawDimensions(ctx, room, transform)
    }
    
    // Draw luminaires
    if (displayOptions.showFixtures) {
      drawLuminaires(ctx, luminaires, selectedLuminaireId, iesDataCache, transform)
    }
    
    // Draw placement cursor
    if (isPlacing && mousePos) {
      drawPlacementCursor(ctx, mousePos, transform)
    }
    
  }, [
    room, cadEntities, luminaires, selectedLuminaireId, results, displayOptions, 
    transform, canvasSize, isPlacing, mousePos, iesDataCache
  ])
  
  // Mouse event handlers
  const handleMouseDown = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return
    
    const canvasX = (e.clientX - rect.left) * window.devicePixelRatio
    const canvasY = (e.clientY - rect.top) * window.devicePixelRatio
    const roomCoords = canvasToRoom(canvasX, canvasY)
    
    // Check if clicking on a luminaire
    const clickRadius = 20 / transform.scale
    const clicked = luminaires.find(lum => {
      const dx = lum.position.x - roomCoords.x
      const dz = lum.position.z - roomCoords.z
      return Math.sqrt(dx * dx + dz * dz) < clickRadius
    })
    
    if (clicked) {
      setDraggedLuminaireId(clicked.id)
      setIsDragging(true)
      selectLuminaire(clicked.id)
      onLuminaireSelect?.(clicked.id)
    } else if (isPlacing && placingIesProfileId) {
      // Place new luminaire
      const newId = addLuminaire(placingIesProfileId, {
        x: roomCoords.x,
        y: room.height - 0.1,
        z: roomCoords.z
      })
      onPlaceLuminaire?.(roomCoords.x, roomCoords.z)
      // Keep placing mode active for multiple placements
    } else if (e.button === 0 && !clicked) {
      // Start panning with left click on empty area
      setIsPanning(true)
      setDragStart({ x: e.clientX - panOffset.x, y: e.clientY - panOffset.y })
    } else if (!clicked) {
      // Deselect
      selectLuminaire(null)
      onLuminaireSelect?.(null)
    }
  }, [canvasToRoom, transform.scale, luminaires, isPlacing, placingIesProfileId, addLuminaire, room.height, selectLuminaire, onLuminaireSelect, onPlaceLuminaire, panOffset])
  
  const handleMouseMove = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    const rect = canvasRef.current?.getBoundingClientRect()
    if (!rect) return
    
    const canvasX = (e.clientX - rect.left) * window.devicePixelRatio
    const canvasY = (e.clientY - rect.top) * window.devicePixelRatio
    const roomCoords = canvasToRoom(canvasX, canvasY)
    
    setMousePos(roomCoords)
    
    if (isDragging && draggedLuminaireId) {
      // Clamp to room bounds
      const clampedX = Math.max(-room.width/2, Math.min(room.width/2, roomCoords.x))
      const clampedZ = Math.max(-room.length/2, Math.min(room.length/2, roomCoords.z))
      
      updateLuminaire(draggedLuminaireId, {
        position: {
          ...luminaires.find(l => l.id === draggedLuminaireId)!.position,
          x: clampedX,
          z: clampedZ
        }
      })
      onLuminaireMove?.(draggedLuminaireId, clampedX, clampedZ)
    } else if (isPanning) {
      setPanOffset({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      })
    }
  }, [canvasToRoom, isDragging, draggedLuminaireId, isPanning, dragStart, room, updateLuminaire, luminaires, onLuminaireMove, setPanOffset])
  
  const handleMouseUp = useCallback(() => {
    setIsDragging(false)
    setDraggedLuminaireId(null)
    setIsPanning(false)
  }, [])
  
  const handleWheel = useCallback((e: React.WheelEvent<HTMLCanvasElement>) => {
    e.preventDefault()
    const delta = -e.deltaY * 0.001
    setZoom(zoom * (1 + delta))
  }, [zoom, setZoom])
  
  const handleDoubleClick = useCallback((e: React.MouseEvent<HTMLCanvasElement>) => {
    // Reset view on double click
    setZoom(1)
    setPanOffset({ x: 0, y: 0 })
  }, [setZoom, setPanOffset])
  
  return (
    <div 
      ref={containerRef} 
      className={`relative w-full h-full overflow-hidden bg-white ${className}`}
    >
      <canvas
        ref={canvasRef}
        data-viewer-2d="true"
        width={canvasSize.width}
        height={canvasSize.height}
        style={{
          width: canvasSize.width / window.devicePixelRatio,
          height: canvasSize.height / window.devicePixelRatio,
          cursor: isPlacing ? 'crosshair' : isDragging ? 'grabbing' : isPanning ? 'grab' : 'default'
        }}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        onWheel={handleWheel}
        onDoubleClick={handleDoubleClick}
      />
      
      {/* Overlay layers for isolines and values (rendered separately for performance) */}
      {displayOptions.showIsolines && results?.grid && (
        <div className="absolute inset-0 pointer-events-none">
          <IsolinesCanvas
            grid={results.grid}
            levels={displayOptions.isolineLevels}
            showLabels={displayOptions.showIsolineLabels}
            width={canvasSize.width / window.devicePixelRatio}
            height={canvasSize.height / window.devicePixelRatio}
            panOffset={panOffset}
            zoom={zoom}
            roomWidth={room.width}
            roomLength={room.length}
          />
        </div>
      )}
      
      {displayOptions.showValues && results?.grid && (
        <div className="absolute inset-0 pointer-events-none">
          <ValueGridCanvas
            grid={results.grid}
            density={displayOptions.valueGridDensity}
            width={canvasSize.width / window.devicePixelRatio}
            height={canvasSize.height / window.devicePixelRatio}
            panOffset={panOffset}
            zoom={zoom}
            roomWidth={room.width}
            roomLength={room.length}
          />
        </div>
      )}
      
      {/* Mouse position indicator */}
      {mousePos && (
        <div className="absolute bottom-2 left-2 bg-black/70 text-white text-xs px-2 py-1 rounded font-mono">
          X: {mousePos.x.toFixed(2)}m | Z: {mousePos.z.toFixed(2)}m
        </div>
      )}
      
      {/* Zoom indicator */}
      <div className="absolute bottom-2 right-2 bg-black/70 text-white text-xs px-2 py-1 rounded font-mono">
        {Math.round(zoom * 100)}%
      </div>
      
      {/* Placing mode indicator */}
      {isPlacing && (
        <div className="absolute top-2 left-1/2 -translate-x-1/2 bg-blue-600 text-white text-sm px-3 py-1 rounded-full shadow-lg">
          Click to place luminaire (ESC to cancel)
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Drawing Functions
// =============================================================================

function drawGrid(
  ctx: CanvasRenderingContext2D,
  room: RoomConfig,
  transform: CanvasTransform,
  canvasSize: { width: number; height: number }
) {
  const { scale, offsetX, offsetY } = transform
  const gridSize = 1 // 1 meter grid
  
  ctx.strokeStyle = GRID_COLOR
  ctx.lineWidth = 1
  
  // Calculate visible grid range
  const startX = Math.floor(-room.width / 2 / gridSize) * gridSize
  const endX = Math.ceil(room.width / 2 / gridSize) * gridSize
  const startZ = Math.floor(-room.length / 2 / gridSize) * gridSize
  const endZ = Math.ceil(room.length / 2 / gridSize) * gridSize
  
  // Vertical lines
  for (let x = startX; x <= endX; x += gridSize) {
    const canvasX = offsetX + x * scale
    ctx.beginPath()
    ctx.moveTo(canvasX, 0)
    ctx.lineTo(canvasX, canvasSize.height)
    ctx.stroke()
  }
  
  // Horizontal lines
  for (let z = startZ; z <= endZ; z += gridSize) {
    const canvasY = offsetY + z * scale
    ctx.beginPath()
    ctx.moveTo(0, canvasY)
    ctx.lineTo(canvasSize.width, canvasY)
    ctx.stroke()
  }
}

function drawRoomOutline(
  ctx: CanvasRenderingContext2D,
  room: RoomConfig,
  transform: CanvasTransform
) {
  const { width, length } = room
  const { scale, offsetX, offsetY } = transform
  
  const x1 = offsetX - (width / 2) * scale
  const y1 = offsetY - (length / 2) * scale
  const w = width * scale
  const h = length * scale
  
  // Fill
  ctx.fillStyle = ROOM_FILL_COLOR
  ctx.fillRect(x1, y1, w, h)
  
  // Stroke
  ctx.strokeStyle = ROOM_STROKE_COLOR
  ctx.lineWidth = 2
  ctx.strokeRect(x1, y1, w, h)
}

function drawCadEntities(
    ctx: CanvasRenderingContext2D,
    entities: { type: string, layer: string, vertices: { x: number, y: number }[] }[],
    transform: CanvasTransform
) {
    const { scale, offsetX, offsetY } = transform

    ctx.save()
    ctx.strokeStyle = '#6b7280' // Gray for CAD lines
    ctx.lineWidth = 1
    
    // We might want to color by layer in the future
    // const layerColors = new Map<string, string>()

    for (const entity of entities) {
        if (entity.vertices.length < 2) continue

        ctx.beginPath()
        
        const start = entity.vertices[0]
        ctx.moveTo(offsetX + start.x * scale, offsetY + start.y * scale) // Note: DXF Y is usually up, which maps to our Z?
        // Wait, earlier we mapped DXF Y to Room Length (Z).
        // Let's assume standard 2D plan: X is Width, Y is Length.
        // Our 3D coordinate system: X=Width, Z=Length.
        // So DXF X -> Canvas X, DXF Y -> Canvas Z (which is drawn as Y on 2D canvas).
        // BUT DXF coordinates might be far from origin. We set room bounds based on min/max.
        // We need to center the CAD drawing?
        // Actually, setRoomBounds sets the room size, but doesn't recenter the coordinates of the entities.
        // The entities are in world coordinates.
        // The room is centered at (0,0) in our model.
        // We probably need to normalize the CAD entities to be centered around (0,0).
        // OR we just draw them as is, but pan/zoom will handle it?
        // The problem is if CAD origin is at (1000, 1000), our room is at (0,0), they won't align.
        
        // For now, let's just draw them. If they are offset, they will appear offset.
        // Correct fix would be to normalize coordinates during import.
        
        for (let i = 1; i < entity.vertices.length; i++) {
            const v = entity.vertices[i]
            ctx.lineTo(offsetX + v.x * scale, offsetY + v.y * scale)
        }

        // Close loop if it's a closed polyline (simplified check)
        if (entity.type === 'LWPOLYLINE' || entity.type === 'POLYLINE') {
            // Check if last point equals first point? 
            // Or just rely on visual closure if points match.
        }

        ctx.stroke()
    }

    ctx.restore()
}

function drawDimensions(
  ctx: CanvasRenderingContext2D,
  room: RoomConfig,
  transform: CanvasTransform
) {
  const { width, length } = room
  const { scale, offsetX, offsetY } = transform
  
  ctx.fillStyle = DIMENSION_COLOR
  ctx.font = '12px sans-serif'
  ctx.textAlign = 'center'
  ctx.textBaseline = 'middle'
  
  const padding = 25
  
  // Width label (top)
  ctx.fillText(
    `${width.toFixed(1)}m`,
    offsetX,
    offsetY - (length / 2) * scale - padding
  )
  
  // Length label (right)
  ctx.save()
  ctx.translate(offsetX + (width / 2) * scale + padding, offsetY)
  ctx.rotate(Math.PI / 2)
  ctx.fillText(`${length.toFixed(1)}m`, 0, 0)
  ctx.restore()
}

function drawHeatmap(
  ctx: CanvasRenderingContext2D,
  grid: CalculationGrid,
  transform: CanvasTransform,
  opacity: number,
  colorScaleType: 'dialux' | 'thermal' | 'grayscale'
) {
  const { points, gridWidth, gridHeight, roomWidth, roomLength } = grid
  const { scale, offsetX, offsetY } = transform
  
  if (points.length === 0) return
  
  // Get min/max for color mapping
  let min = Infinity
  let max = -Infinity
  for (const p of points) {
    if (p.illuminance < min) min = p.illuminance
    if (p.illuminance > max) max = p.illuminance
  }
  
  const colorScale = getColorScale(colorScaleType)
  
  // Cell size
  const cellWidth = (roomWidth / gridWidth) * scale
  const cellHeight = (roomLength / gridHeight) * scale
  
  ctx.globalAlpha = opacity
  
  for (let zi = 0; zi < gridHeight; zi++) {
    for (let xi = 0; xi < gridWidth; xi++) {
      const index = zi * gridWidth + xi
      const point = points[index]
      if (!point) continue
      
      const [r, g, b] = interpolateColor(point.illuminance, min, max, colorScale)
      
      const canvasX = offsetX + point.x * scale - cellWidth / 2
      const canvasY = offsetY + point.z * scale - cellHeight / 2
      
      ctx.fillStyle = `rgb(${r},${g},${b})`
      ctx.fillRect(canvasX, canvasY, cellWidth + 1, cellHeight + 1)
    }
  }
  
  ctx.globalAlpha = 1
}

function drawLuminaires(
  ctx: CanvasRenderingContext2D,
  luminaires: LuminaireInstance[],
  selectedId: string | null,
  iesCache: Map<string, IESData>,
  transform: CanvasTransform
) {
  const { scale, offsetX, offsetY } = transform
  const size = Math.max(16, 24 * Math.sqrt(scale))
  
  for (const lum of luminaires) {
    const canvasX = offsetX + lum.position.x * scale
    const canvasY = offsetY + lum.position.z * scale
    const isSelected = lum.id === selectedId
    
    // Get IES data for beam angle visualization
    const ies = iesCache.get(lum.iesProfileId)
    
    // Draw beam spread circle (simplified)
    if (ies && ies.beamAngle > 0) {
      const beamRadius = Math.tan((ies.beamAngle * Math.PI) / 180 / 2) * lum.position.y * scale
      ctx.beginPath()
      ctx.arc(canvasX, canvasY, beamRadius, 0, Math.PI * 2)
      ctx.fillStyle = isSelected ? 'rgba(245, 158, 11, 0.1)' : 'rgba(0, 132, 255, 0.1)'
      ctx.fill()
      ctx.strokeStyle = isSelected ? 'rgba(245, 158, 11, 0.3)' : 'rgba(0, 132, 255, 0.3)'
      ctx.lineWidth = 1
      ctx.stroke()
    }
    
    // Draw luminaire symbol (square with cross)
    ctx.save()
    ctx.translate(canvasX, canvasY)
    ctx.rotate((lum.rotation.orientation * Math.PI) / 180)
    
    // Outer square
    ctx.fillStyle = isSelected ? LUMINAIRE_SELECTED_COLOR : LUMINAIRE_COLOR
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 2
    ctx.fillRect(-size/2, -size/2, size, size)
    ctx.strokeRect(-size/2, -size/2, size, size)
    
    // Cross
    ctx.strokeStyle = '#ffffff'
    ctx.lineWidth = 2
    ctx.beginPath()
    ctx.moveTo(-size/3, 0)
    ctx.lineTo(size/3, 0)
    ctx.moveTo(0, -size/3)
    ctx.lineTo(0, size/3)
    ctx.stroke()
    
    // Direction indicator (triangle)
    ctx.fillStyle = '#ffffff'
    ctx.beginPath()
    ctx.moveTo(0, -size/2 - 6)
    ctx.lineTo(-5, -size/2)
    ctx.lineTo(5, -size/2)
    ctx.closePath()
    ctx.fill()
    
    ctx.restore()
    
    // Label
    if (lum.label) {
      ctx.fillStyle = ROOM_STROKE_COLOR
      ctx.font = '10px sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText(lum.label, canvasX, canvasY + size/2 + 12)
    }
  }
}

function drawPlacementCursor(
  ctx: CanvasRenderingContext2D,
  pos: { x: number; z: number },
  transform: CanvasTransform
) {
  const { scale, offsetX, offsetY } = transform
  const canvasX = offsetX + pos.x * scale
  const canvasY = offsetY + pos.z * scale
  const size = 24
  
  ctx.save()
  ctx.globalAlpha = 0.6
  
  // Dashed crosshair
  ctx.strokeStyle = LUMINAIRE_COLOR
  ctx.lineWidth = 2
  ctx.setLineDash([5, 5])
  
  ctx.beginPath()
  ctx.moveTo(canvasX - size, canvasY)
  ctx.lineTo(canvasX + size, canvasY)
  ctx.moveTo(canvasX, canvasY - size)
  ctx.lineTo(canvasX, canvasY + size)
  ctx.stroke()
  
  // Circle
  ctx.setLineDash([])
  ctx.beginPath()
  ctx.arc(canvasX, canvasY, size/2, 0, Math.PI * 2)
  ctx.stroke()
  
  ctx.restore()
}

// =============================================================================
// Keyboard Handler Hook
// =============================================================================

export function useViewer2DKeyboard() {
  const stopPlacing = usePlannerStore(state => state.stopPlacing)
  const removeLuminaire = usePlannerStore(state => state.removeLuminaire)
  const selectedLuminaireId = usePlannerStore(state => state.selectedLuminaireId)
  
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        stopPlacing()
      } else if ((e.key === 'Delete' || e.key === 'Backspace') && selectedLuminaireId) {
        removeLuminaire(selectedLuminaireId)
      }
    }
    
    window.addEventListener('keydown', handleKeyDown)
    return () => window.removeEventListener('keydown', handleKeyDown)
  }, [stopPlacing, removeLuminaire, selectedLuminaireId])
}

// =============================================================================
// Export
// =============================================================================

export default Viewer2D
