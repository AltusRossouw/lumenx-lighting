/**
 * OrbitX Lighting Planner - False-Color Legend
 *
 * A quantitative legend that anchors the heatmap color scale to real lux
 * values (Emin → Emax), so the false-color rendering is interpretable rather
 * than merely decorative.
 */

'use client'

import React from 'react'
import { DIALUX_COLOR_SCALE } from '../../lib/photometry/types'

interface ColorLegendProps {
  min: number
  max: number
  /** Optional markers to annotate (e.g. average illuminance). */
  markers?: { label: string; value: number }[]
  className?: string
}

function luxToColor(t: number): string {
  // t in [0,1] across the DIALux color scale (blue → cyan → green → yellow → red).
  const stops = DIALUX_COLOR_SCALE
  const clamped = Math.max(0, Math.min(1, t))
  for (let i = 0; i < stops.length - 1; i++) {
    const a = stops[i]
    const b = stops[i + 1]
    if (clamped >= a.position && clamped <= b.position) {
      const local = (clamped - a.position) / (b.position - a.position || 1)
      const r = Math.round(a.color[0] + (b.color[0] - a.color[0]) * local)
      const g = Math.round(a.color[1] + (b.color[1] - a.color[1]) * local)
      const bl = Math.round(a.color[2] + (b.color[2] - a.color[2]) * local)
      return `rgb(${r}, ${g}, ${bl})`
    }
  }
  const last = stops[stops.length - 1]
  return `rgb(${last.color.join(',')})`
}

export function ColorLegend({ min, max, markers = [], className = '' }: ColorLegendProps) {
  if (max <= min) return null

  const gradient = DIALUX_COLOR_SCALE
    .map((s) => `rgb(${s.color[0]}, ${s.color[1]}, ${s.color[2]}) ${Math.round(s.position * 100)}%`)
    .join(', ')

  const ticks = [0, 0.25, 0.5, 0.75, 1]

  return (
    <div className={`${className}`}>
      <div className="flex items-center justify-between mb-1">
        <span className="text-[10px] font-semibold text-gray-600 uppercase tracking-wide">Lux scale</span>
        <span className="text-[10px] text-gray-500">false colour</span>
      </div>

      <div
        className="h-3 rounded-full w-full"
        style={{ background: `linear-gradient(to right, ${gradient})` }}
      />

      <div className="relative h-4 mt-0.5">
        {ticks.map((t) => {
          const value = min + (max - min) * t
          return (
            <span
              key={t}
              className="absolute -translate-x-1/2 text-[10px] text-gray-600"
              style={{ left: `${t * 100}%` }}
            >
              {value < 100 ? value.toFixed(0) : Math.round(value / 10) * 10}
            </span>
          )
        })}

        {markers.map((m, i) => {
          const t = (m.value - min) / (max - min)
          if (t < 0 || t > 1) return null
          return (
            <div
              key={i}
              className="absolute -translate-x-1/2"
              style={{ left: `${Math.max(0, Math.min(100, t * 100))}%`, top: 12 }}
            >
              <div className="mx-auto w-0 h-0 border-l-4 border-r-4 border-t-4 border-l-transparent border-r-transparent border-t-gray-900" />
              <div className="text-[9px] text-gray-700 whitespace-nowrap -translate-x-1/2">
                {m.label}
              </div>
            </div>
          )
        })}
      </div>
    </div>
  )
}

export { luxToColor }
export default ColorLegend
