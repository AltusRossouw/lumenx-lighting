/**
 * OrbitX Lighting Planner - Luminaire List
 * 
 * UI component for managing luminaires in the project.
 * Displays list of placed fixtures with selection, editing, and deletion.
 */

'use client'

import React, { useState, useCallback, useEffect } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import type { IESProfile, LuminaireInstance } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface LuminaireListProps {
  className?: string
}

interface LuminaireItemProps {
  luminaire: LuminaireInstance
  isSelected: boolean
  profile: IESProfile | undefined
  onSelect: () => void
  onDelete: () => void
  onDuplicate: () => void
  onUpdate: (updates: Partial<LuminaireInstance>) => void
}

// =============================================================================
// Luminaire Item Component
// =============================================================================

function LuminaireItem({
  luminaire,
  isSelected,
  profile,
  onSelect,
  onDelete,
  onDuplicate,
  onUpdate
}: LuminaireItemProps) {
  const [isExpanded, setIsExpanded] = useState(false)
  
  return (
    <div 
      className={`
        border rounded-lg transition-all
        ${isSelected 
          ? 'border-blue-500 bg-blue-50 shadow-md' 
          : 'border-gray-200 bg-white hover:border-gray-300'
        }
      `}
    >
      {/* Header */}
      <div 
        className="flex items-center gap-3 p-3 cursor-pointer"
        onClick={onSelect}
      >
        {/* Icon */}
        <div className={`
          w-10 h-10 rounded flex items-center justify-center flex-shrink-0
          ${isSelected ? 'bg-blue-500 text-white' : 'bg-gray-100 text-gray-600'}
        `}>
          <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
              d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" 
            />
          </svg>
        </div>
        
        {/* Info */}
        <div className="flex-1 min-w-0">
          <div className="font-medium text-gray-900 truncate">
            {luminaire.label || profile?.productName || 'Luminaire'}
          </div>
          <div className="text-xs text-gray-600">
            {profile?.variantLabel || `ID: ${luminaire.id.slice(0, 8)}`}
          </div>
        </div>
        
        {/* Dimming indicator */}
        <div className="text-sm text-gray-600 font-mono">
          {Math.round(luminaire.dimming * 100)}%
        </div>
        
        {/* Expand button */}
        <button
          onClick={(e) => { e.stopPropagation(); setIsExpanded(!isExpanded) }}
          className="p-1 hover:bg-gray-100 rounded"
        >
          <svg 
            className={`w-5 h-5 text-gray-400 transition-transform ${isExpanded ? 'rotate-180' : ''}`} 
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
      </div>
      
      {/* Expanded details */}
      {isExpanded && (
        <div className="border-t border-gray-100 p-3 space-y-3">
          {/* Position */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-xs text-gray-700 block mb-1">X (m)</label>
              <input
                type="number"
                step="0.1"
                value={luminaire.position.x.toFixed(2)}
                onChange={(e) => onUpdate({ 
                  position: { ...luminaire.position, x: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
            <div>
              <label className="text-xs text-gray-700 block mb-1">Y (m)</label>
              <input
                type="number"
                step="0.1"
                value={luminaire.position.y.toFixed(2)}
                onChange={(e) => onUpdate({ 
                  position: { ...luminaire.position, y: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
            <div>
              <label className="text-xs text-gray-700 block mb-1">Z (m)</label>
              <input
                type="number"
                step="0.1"
                value={luminaire.position.z.toFixed(2)}
                onChange={(e) => onUpdate({ 
                  position: { ...luminaire.position, z: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
          </div>
          
          {/* Rotation */}
          <div className="grid grid-cols-3 gap-2">
            <div>
              <label className="text-xs text-gray-700 block mb-1">Tilt</label>
              <input
                type="number"
                step="5"
                value={luminaire.rotation.tilt}
                onChange={(e) => onUpdate({ 
                  rotation: { ...luminaire.rotation, tilt: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
            <div>
              <label className="text-xs text-gray-700 block mb-1">Orient</label>
              <input
                type="number"
                step="15"
                value={luminaire.rotation.orientation}
                onChange={(e) => onUpdate({ 
                  rotation: { ...luminaire.rotation, orientation: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
            <div>
              <label className="text-xs text-gray-700 block mb-1">Roll</label>
              <input
                type="number"
                step="15"
                value={luminaire.rotation.roll}
                onChange={(e) => onUpdate({ 
                  rotation: { ...luminaire.rotation, roll: parseFloat(e.target.value) || 0 }
                })}
                className="w-full px-2 py-1 text-sm border rounded"
              />
            </div>
          </div>
          
          {/* Dimming slider */}
          <div>
            <label className="text-xs text-gray-700 block mb-1">
              Dimming: {Math.round(luminaire.dimming * 100)}%
            </label>
            <input
              type="range"
              min="0"
              max="100"
              value={Math.round(luminaire.dimming * 100)}
              onChange={(e) => onUpdate({ dimming: parseInt(e.target.value) / 100 })}
              className="w-full"
            />
          </div>
          
          {/* Label */}
          <div>
            <label className="text-xs text-gray-700 block mb-1">Label</label>
            <input
              type="text"
              value={luminaire.label || ''}
              onChange={(e) => onUpdate({ label: e.target.value || undefined })}
              placeholder="Optional label"
              className="w-full px-2 py-1 text-sm border rounded"
            />
          </div>
          
          {/* Actions */}
          <div className="flex gap-2 pt-2 border-t">
            <button
              onClick={onDuplicate}
              className="flex-1 px-3 py-1.5 text-sm bg-gray-100 hover:bg-gray-200 rounded transition-colors"
            >
              Duplicate
            </button>
            <button
              onClick={onDelete}
              className="flex-1 px-3 py-1.5 text-sm bg-red-50 hover:bg-red-100 text-red-600 rounded transition-colors"
            >
              Delete
            </button>
          </div>
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Main Component
// =============================================================================

export function LuminaireList({ className = '' }: LuminaireListProps) {
  const luminaires = usePlannerStore(state => state.luminaires)
  const selectedLuminaireId = usePlannerStore(state => state.selectedLuminaireId)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const selectLuminaire = usePlannerStore(state => state.selectLuminaire)
  const removeLuminaire = usePlannerStore(state => state.removeLuminaire)
  const updateLuminaire = usePlannerStore(state => state.updateLuminaire)
  const duplicateLuminaire = usePlannerStore(state => state.duplicateLuminaire)
  const clearAllLuminaires = usePlannerStore(state => state.clearAllLuminaires)
  const startPlacing = usePlannerStore(state => state.startPlacing)
  
  const [showAddModal, setShowAddModal] = useState(false)
  const [mounted, setMounted] = useState(false)
  
  // Track hydration to avoid mismatch
  useEffect(() => {
    setMounted(true)
  }, [])
  
  const getProfile = useCallback((profileId: string) => {
    return iesProfiles.find(p => p.id === profileId)
  }, [iesProfiles])
  
  // Determine empty state message (only after mount to avoid hydration mismatch)
  const emptyMessage = mounted
    ? (iesProfiles.length === 0 
        ? 'Loading products...'
        : 'Click "+ Add" to place luminaires')
    : 'Click "+ Add" to place luminaires'
  
  return (
    <div className={`flex flex-col h-full ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between p-4 border-b">
        <h3 className="font-semibold text-gray-900">
          Luminaires ({luminaires.length})
        </h3>
        <div className="flex gap-2">
          <button
            onClick={() => setShowAddModal(true)}
            className="px-3 py-1.5 text-sm bg-blue-600 hover:bg-blue-700 text-white rounded transition-colors"
          >
            + Add
          </button>
          {luminaires.length > 0 && (
            <button
              onClick={() => {
                if (confirm('Remove all luminaires?')) {
                  clearAllLuminaires()
                }
              }}
              className="px-3 py-1.5 text-sm text-red-600 hover:bg-red-50 rounded transition-colors"
            >
              Clear
            </button>
          )}
        </div>
      </div>
      
      {/* List */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {luminaires.length === 0 ? (
          <div className="text-center py-8 text-gray-500">
            <svg className="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
            <p className="font-medium text-gray-600">No luminaires placed</p>
            <p className="text-sm mt-1">{emptyMessage}</p>
          </div>
        ) : (
          luminaires.map(lum => (
            <LuminaireItem
              key={lum.id}
              luminaire={lum}
              isSelected={lum.id === selectedLuminaireId}
              profile={getProfile(lum.iesProfileId)}
              onSelect={() => selectLuminaire(lum.id)}
              onDelete={() => removeLuminaire(lum.id)}
              onDuplicate={() => duplicateLuminaire(lum.id)}
              onUpdate={(updates) => updateLuminaire(lum.id, updates)}
            />
          ))
        )}
      </div>
      
      {/* Add luminaire modal */}
      {showAddModal && (
        <AddLuminaireModal 
          onClose={() => setShowAddModal(false)}
          onSelect={(profileId) => {
            startPlacing(profileId)
            setShowAddModal(false)
          }}
        />
      )}
    </div>
  )
}

// =============================================================================
// Add Luminaire Modal
// =============================================================================

interface AddLuminaireModalProps {
  onClose: () => void
  onSelect: (profileId: string) => void
}

function AddLuminaireModal({ onClose, onSelect }: AddLuminaireModalProps) {
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const [search, setSearch] = useState('')
  
  const filteredProfiles = iesProfiles.filter(p => 
    p.productName.toLowerCase().includes(search.toLowerCase()) ||
    p.variantLabel.toLowerCase().includes(search.toLowerCase())
  )
  
  // Group by product
  const grouped = filteredProfiles.reduce((acc, profile) => {
    const key = profile.productSlug
    if (!acc[key]) {
      acc[key] = {
        name: profile.productName,
        variants: []
      }
    }
    acc[key].variants.push(profile)
    return acc
  }, {} as Record<string, { name: string; variants: IESProfile[] }>)
  
  return (
    <div className="fixed inset-0 bg-black/50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-xl shadow-xl w-full max-w-lg max-h-[80vh] flex flex-col">
        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b">
          <h3 className="font-semibold text-lg">Add Luminaire</h3>
          <button onClick={onClose} className="p-1 hover:bg-gray-100 rounded">
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>
        
        {/* Search */}
        <div className="p-4 border-b">
          <input
            type="text"
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full px-3 py-2 border rounded-lg"
            autoFocus
          />
        </div>
        
        {/* Product list */}
        <div className="flex-1 overflow-y-auto p-4">
          {Object.keys(grouped).length === 0 ? (
            <div className="text-center py-8 text-gray-500">
              <svg className="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
              </svg>
              {iesProfiles.length === 0 ? (
                <>
                  <p className="font-medium text-gray-600">Loading products...</p>
                  <p className="text-sm mt-1">Please wait while IES profiles load</p>
                </>
              ) : search ? (
                <>
                  <p className="font-medium text-gray-600">No results found</p>
                  <p className="text-sm mt-1">Try a different search term</p>
                </>
              ) : (
                <>
                  <p className="font-medium text-gray-600">No products available</p>
                  <p className="text-sm mt-1">Check IES file configuration</p>
                </>
              )}
            </div>
          ) : (
            <div className="space-y-4">
              {Object.entries(grouped).map(([slug, group]) => (
                <div key={slug}>
                  <h4 className="font-medium text-gray-900 mb-2">{group.name}</h4>
                  <div className="space-y-1">
                    {group.variants.map(variant => (
                      <button
                        key={variant.id}
                        onClick={() => onSelect(variant.id)}
                        className="w-full flex items-center justify-between p-3 text-left bg-gray-50 hover:bg-blue-50 rounded-lg transition-colors"
                      >
                        <div>
                          <div className="text-sm font-medium">{variant.variantLabel}</div>
                          <div className="text-xs text-gray-600">
                            {variant.lumens && `${variant.lumens} lm`}
                            {variant.watts && ` | ${variant.watts}W`}
                            {variant.beamAngle && ` | ${variant.beamAngle}°`}
                          </div>
                        </div>
                        <svg className="w-5 h-5 text-gray-400" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 4v16m8-8H4" />
                        </svg>
                      </button>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
        
        {/* Footer hint */}
        <div className="p-4 border-t bg-gray-50 text-xs text-gray-600 text-center rounded-b-xl">
          Select a luminaire, then click on the 2D view to place it
        </div>
      </div>
    </div>
  )
}

// =============================================================================
// Export
// =============================================================================

export default LuminaireList
