/**
 * OrbitX Lighting Planner - Toolbar Components
 * 
 * Calculate button, view toggle, and display options toolbar.
 */

'use client'

import React, { useState } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { DXFImportModal } from './DXFImportModal'
import type { ViewMode } from '../../lib/photometry/types'

// =============================================================================
// Calculate Button
// =============================================================================

interface CalculateButtonProps {
  onClick: () => void
  isCalculating: boolean
  progress: number
  estimatedTime?: number
  disabled?: boolean
  className?: string
}

export function CalculateButton({
  onClick,
  isCalculating,
  progress,
  estimatedTime,
  disabled,
  className = ''
}: CalculateButtonProps) {
  return (
    <button
      onClick={onClick}
      disabled={disabled || isCalculating}
      className={`
        relative flex items-center gap-2 px-4 py-2 rounded-lg font-medium
        transition-all overflow-hidden
        ${isCalculating
          ? 'bg-blue-100 text-blue-700 cursor-wait'
          : disabled
            ? 'bg-gray-100 text-gray-400 cursor-not-allowed'
            : 'bg-blue-600 hover:bg-blue-700 text-white shadow-sm hover:shadow'
        }
        ${className}
      `}
    >
      {/* Progress bar background */}
      {isCalculating && (
        <div
          className="absolute inset-0 bg-blue-200 transition-all duration-300"
          style={{ width: `${progress}%` }}
        />
      )}
      
      {/* Content */}
      <span className="relative flex items-center gap-2">
        {isCalculating ? (
          <>
            <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
              <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
              <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
            </svg>
            <span>{progress}%</span>
          </>
        ) : (
          <>
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" />
            </svg>
            <span>Calculate</span>
            {estimatedTime && estimatedTime > 1000 && (
              <span className="text-xs opacity-70">~{Math.ceil(estimatedTime / 1000)}s</span>
            )}
          </>
        )}
      </span>
    </button>
  )
}

// =============================================================================
// View Toggle
// =============================================================================

interface ViewToggleProps {
  value: ViewMode
  onChange: (mode: ViewMode) => void
  className?: string
}

export function ViewToggle({ value, onChange, className = '' }: ViewToggleProps) {
  return (
    <div className={`inline-flex rounded-lg border border-gray-200 p-1 bg-white ${className}`}>
      <button
        onClick={() => onChange('2d')}
        className={`
          flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-colors
          ${value === '2d'
            ? 'bg-blue-600 text-white shadow-sm'
            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
          }
        `}
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6z" />
        </svg>
        2D Plan
      </button>
      <button
        onClick={() => onChange('3d')}
        className={`
          flex items-center gap-1.5 px-3 py-1.5 text-sm rounded-md transition-colors
          ${value === '3d'
            ? 'bg-blue-600 text-white shadow-sm'
            : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
          }
        `}
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 10l-2 1m0 0l-2-1m2 1v2.5M20 7l-2 1m2-1l-2-1m2 1v2.5M14 4l-2-1-2 1M4 7l2-1M4 7l2 1M4 7v2.5M12 21l-2-1m2 1l2-1m-2 1v-2.5M6 18l-2-1v-2.5M18 18l2-1v-2.5" />
        </svg>
        3D View
      </button>
    </div>
  )
}

// =============================================================================
// Display Options Dropdown
// =============================================================================

interface DisplayOptionsDropdownProps {
  className?: string
}

export function DisplayOptionsDropdown({ className = '' }: DisplayOptionsDropdownProps) {
  const [isOpen, setIsOpen] = useState(false)
  const displayOptions = usePlannerStore(state => state.displayOptions)
  const setDisplayOptions = usePlannerStore(state => state.setDisplayOptions)
  const toggleDisplayOption = usePlannerStore(state => state.toggleDisplayOption)
  
  const options = [
    { key: 'showHeatmap' as const, label: 'Heatmap', icon: '🌡️' },
    { key: 'showIsolines' as const, label: 'Iso-lux contours', icon: '〰️' },
    { key: 'showValues' as const, label: 'Lux values', icon: '🔢' },
    { key: 'showFixtures' as const, label: 'Fixtures', icon: '💡' },
    { key: 'showGrid' as const, label: 'Grid', icon: '📐' },
    { key: 'showDimensions' as const, label: 'Dimensions', icon: '📏' }
  ]
  
  return (
    <div className={`relative ${className}`}>
      <button
        onClick={() => setIsOpen(!isOpen)}
        className="flex items-center gap-2 px-3 py-2 border rounded-lg bg-white hover:bg-gray-50 transition-colors"
      >
        <svg className="w-4 h-4 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 6V4m0 2a2 2 0 100 4m0-4a2 2 0 110 4m-6 8a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4m6 6v10m6-2a2 2 0 100-4m0 4a2 2 0 110-4m0 4v2m0-6V4" />
        </svg>
        <span className="text-sm">Display</span>
        <svg className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
        </svg>
      </button>
      
      {isOpen && (
        <>
          <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)} />
          <div className="absolute top-full right-0 mt-1 w-56 bg-white rounded-lg shadow-xl border z-50 py-2">
            {options.map(opt => (
              <button
                key={opt.key}
                onClick={() => toggleDisplayOption(opt.key)}
                className="w-full flex items-center gap-3 px-4 py-2 text-left hover:bg-gray-50 transition-colors"
              >
                <span className="text-base">{opt.icon}</span>
                <span className="flex-1 text-sm text-gray-700">{opt.label}</span>
                <div className={`
                  w-4 h-4 rounded border-2 flex items-center justify-center transition-colors
                  ${displayOptions[opt.key]
                    ? 'bg-blue-600 border-blue-600'
                    : 'border-gray-300'
                  }
                `}>
                  {displayOptions[opt.key] && (
                    <svg className="w-3 h-3 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={3} d="M5 13l4 4L19 7" />
                    </svg>
                  )}
                </div>
              </button>
            ))}
            
            <div className="border-t my-2" />
            
            {/* Heatmap opacity slider */}
            <div className="px-4 py-2">
              <label className="text-xs text-gray-700 block mb-1">
                Heatmap opacity: {Math.round(displayOptions.heatmapOpacity * 100)}%
              </label>
              <input
                type="range"
                min="0"
                max="100"
                value={Math.round(displayOptions.heatmapOpacity * 100)}
                onChange={(e) => setDisplayOptions({ heatmapOpacity: parseInt(e.target.value) / 100 })}
                className="w-full"
              />
            </div>
            
            {/* Color scale */}
            <div className="px-4 py-2">
              <label className="text-xs text-gray-700 block mb-1">Color scale</label>
              <select
                value={displayOptions.heatmapColorScale}
                onChange={(e) => setDisplayOptions({ heatmapColorScale: e.target.value as 'dialux' | 'thermal' | 'grayscale' })}
                className="w-full text-sm border rounded px-2 py-1"
              >
                <option value="dialux">DIALux (Blue-Green-Red)</option>
                <option value="thermal">Thermal (Purple-Red-Yellow)</option>
                <option value="grayscale">Grayscale</option>
              </select>
            </div>
          </div>
        </>
      )}
    </div>
  )
}

// =============================================================================
// Toolbar
// =============================================================================

interface ToolbarProps {
  onCalculate: () => void
  isCalculating: boolean
  progress: number
  estimatedTime?: number
  canCalculate?: boolean
  className?: string
}

export function Toolbar({
  onCalculate,
  isCalculating,
  progress,
  estimatedTime,
  canCalculate = true,
  className = ''
}: ToolbarProps) {
  const viewMode = usePlannerStore(state => state.viewMode)
  const setViewMode = usePlannerStore(state => state.setViewMode)
  const luminaireCount = usePlannerStore(state => state.luminaires.length)
  
  return (
    <div className={`flex items-center justify-between gap-4 p-3 bg-white border-b ${className}`}>
      {/* Left side */}
      <div className="flex items-center gap-3">
        <DXFImportModal />
        <ViewToggle value={viewMode} onChange={setViewMode} />
        <DisplayOptionsDropdown />
      </div>
      
      {/* Right side */}
      <div className="flex items-center gap-3">
        <span className="text-sm text-gray-600">
          {luminaireCount} fixture{luminaireCount !== 1 ? 's' : ''}
        </span>
        <CalculateButton
          onClick={onCalculate}
          isCalculating={isCalculating}
          progress={progress}
          estimatedTime={estimatedTime}
          disabled={!canCalculate || luminaireCount === 0}
        />
      </div>
    </div>
  )
}

// =============================================================================
// Quick Results Bar
// =============================================================================

export function QuickResultsBar({ className = '' }: { className?: string }) {
  const results = usePlannerStore(state => state.results)
  
  if (!results) return null
  
  return (
    <div className={`flex items-center gap-6 px-4 py-2 bg-gray-50 border-t text-sm ${className}`}>
      <div className="flex items-center gap-2">
        <span className="text-gray-600">Eavg:</span>
        <span className="font-semibold">{Math.round(results.Eavg)} lux</span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-gray-600">Uo:</span>
        <span className={`font-semibold ${results.Uo >= 0.4 ? 'text-green-600' : 'text-red-600'}`}>
          {results.Uo.toFixed(2)}
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-gray-600">Min/Max:</span>
        <span className="font-mono text-xs">
          {Math.round(results.Emin)} / {Math.round(results.Emax)} lux
        </span>
      </div>
      <div className="flex items-center gap-2">
        <span className="text-gray-600">Power:</span>
        <span className="font-semibold">{results.powerDensity.toFixed(1)} W/m²</span>
      </div>
    </div>
  )
}

// =============================================================================
// Export
// =============================================================================

export default Toolbar
