/**
 * OrbitX Lighting Planner - Isolines (Lux Contours)
 * 
 * Generates and renders iso-lux contour lines on the work plane
 * using the marching squares algorithm.
 */

'use client'

import React, { useMemo } from 'react'
import type { CalculationGrid, IsolinePath, Point2D, ColorStop } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface IsolinesProps {
  grid: CalculationGrid
  levels?: number[]
  showLabels?: boolean
  opacity?: number
  colorScale?: 'auto' | 'fixed'
  className?: string
}

interface IsolinesCanvasProps extends IsolinesProps {
  width: number
  height: number
  panOffset?: { x: number; y: number }
  zoom?: number
  roomWidth?: number
  roomLength?: number
}

// =============================================================================
// Color Utilities
// =============================================================================

const ISOLINE_COLORS = [
  '#1e40af', // blue - low
  '#0891b2', // cyan
  '#059669', // green
  '#ca8a04', // yellow
  '#dc2626', // red - high
]

function getIsolineColor(level: number, minLevel: number, maxLevel: number): string {
  if (maxLevel <= minLevel) return ISOLINE_COLORS[2]
  const t = (level - minLevel) / (maxLevel - minLevel)
  const index = Math.min(Math.floor(t * ISOLINE_COLORS.length), ISOLINE_COLORS.length - 1)
  return ISOLINE_COLORS[index]
}

// =============================================================================
// Marching Squares Algorithm
// =============================================================================

/**
 * Get the interpolated position where the isoline crosses between two values.
 */
function interpolate(
  x1: number, y1: number, v1: number,
  x2: number, y2: number, v2: number,
  level: number
): Point2D {
  if (Math.abs(v2 - v1) < 0.0001) {
    return { x: (x1 + x2) / 2, z: (y1 + y2) / 2 }
  }
  const t = (level - v1) / (v2 - v1)
  return {
    x: x1 + t * (x2 - x1),
    z: y1 + t * (y2 - y1)
  }
}

/**
 * Generate isolines using marching squares algorithm.
 */
export function generateIsolines(
  grid: CalculationGrid,
  levels: number[]
): IsolinePath[] {
  const { points, gridWidth, gridHeight, roomWidth, roomLength } = grid
  
  if (points.length === 0 || gridWidth < 2 || gridHeight < 2) {
    return []
  }
  
  // Get min/max for coloring
  let minLevel = Math.min(...levels)
  let maxLevel = Math.max(...levels)
  
  const isolines: IsolinePath[] = []
  
  // Helper to get illuminance at grid position
  const getValue = (xi: number, zi: number): number => {
    if (xi < 0 || xi >= gridWidth || zi < 0 || zi >= gridHeight) return 0
    return points[zi * gridWidth + xi]?.illuminance ?? 0
  }
  
  // Helper to convert grid coords to room coords
  const toRoomX = (xi: number) => {
    const spacing = roomWidth / (gridWidth + 1)
    return ((xi + 1) * spacing) - (roomWidth / 2)
  }
  
  const toRoomZ = (zi: number) => {
    const spacing = roomLength / (gridHeight + 1)
    return ((zi + 1) * spacing) - (roomLength / 2)
  }
  
  for (const level of levels) {
    const segments: Point2D[][] = []
    
    // Process each cell (quad) in the grid
    for (let zi = 0; zi < gridHeight - 1; zi++) {
      for (let xi = 0; xi < gridWidth - 1; xi++) {
        // Get corner values
        const v00 = getValue(xi, zi)         // bottom-left
        const v10 = getValue(xi + 1, zi)     // bottom-right
        const v01 = getValue(xi, zi + 1)     // top-left
        const v11 = getValue(xi + 1, zi + 1) // top-right
        
        // Get corner positions in room coordinates
        const x0 = toRoomX(xi)
        const x1 = toRoomX(xi + 1)
        const z0 = toRoomZ(zi)
        const z1 = toRoomZ(zi + 1)
        
        // Determine marching squares case (4 bits: TL, TR, BR, BL)
        let caseIndex = 0
        if (v01 >= level) caseIndex |= 1  // top-left
        if (v11 >= level) caseIndex |= 2  // top-right
        if (v10 >= level) caseIndex |= 4  // bottom-right
        if (v00 >= level) caseIndex |= 8  // bottom-left
        
        // Skip empty cases
        if (caseIndex === 0 || caseIndex === 15) continue
        
        // Interpolated edge points
        const top = interpolate(x0, z1, v01, x1, z1, v11, level)
        const bottom = interpolate(x0, z0, v00, x1, z0, v10, level)
        const left = interpolate(x0, z0, v00, x0, z1, v01, level)
        const right = interpolate(x1, z0, v10, x1, z1, v11, level)
        
        // Generate segments based on case
        // Using standard marching squares lookup
        switch (caseIndex) {
          case 1:
          case 14:
            segments.push([top, left])
            break
          case 2:
          case 13:
            segments.push([top, right])
            break
          case 3:
          case 12:
            segments.push([left, right])
            break
          case 4:
          case 11:
            segments.push([bottom, right])
            break
          case 5:
            // Saddle point - ambiguous case
            segments.push([top, right])
            segments.push([bottom, left])
            break
          case 6:
          case 9:
            segments.push([top, bottom])
            break
          case 7:
          case 8:
            segments.push([bottom, left])
            break
          case 10:
            // Saddle point - ambiguous case
            segments.push([top, left])
            segments.push([bottom, right])
            break
        }
      }
    }
    
    if (segments.length > 0) {
      isolines.push({
        level,
        segments,
        color: getIsolineColor(level, minLevel, maxLevel)
      })
    }
  }
  
  return isolines
}

/**
 * Connect segments into continuous paths for smoother rendering.
 * This is optional but creates nicer looking contours.
 */
export function connectSegments(segments: Point2D[][]): Point2D[][] {
  if (segments.length === 0) return []
  
  const paths: Point2D[][] = []
  const used = new Set<number>()
  const epsilon = 0.001
  
  const pointsEqual = (a: Point2D, b: Point2D): boolean => {
    return Math.abs(a.x - b.x) < epsilon && Math.abs(a.z - b.z) < epsilon
  }
  
  for (let i = 0; i < segments.length; i++) {
    if (used.has(i)) continue
    
    const path: Point2D[] = [...segments[i]]
    used.add(i)
    
    let changed = true
    while (changed) {
      changed = false
      
      for (let j = 0; j < segments.length; j++) {
        if (used.has(j)) continue
        
        const seg = segments[j]
        
        // Try to connect at start
        if (pointsEqual(path[0], seg[0])) {
          path.unshift(seg[1])
          used.add(j)
          changed = true
        } else if (pointsEqual(path[0], seg[1])) {
          path.unshift(seg[0])
          used.add(j)
          changed = true
        }
        // Try to connect at end
        else if (pointsEqual(path[path.length - 1], seg[0])) {
          path.push(seg[1])
          used.add(j)
          changed = true
        } else if (pointsEqual(path[path.length - 1], seg[1])) {
          path.push(seg[0])
          used.add(j)
          changed = true
        }
      }
    }
    
    paths.push(path)
  }
  
  return paths
}

// =============================================================================
// SVG Component (for use with React Three Fiber / 3D scene)
// =============================================================================

export function IsolinesSVG({
  grid,
  levels = [100, 200, 300, 500],
  showLabels = true,
  opacity = 0.8,
  className = ''
}: IsolinesProps) {
  const isolines = useMemo(() => generateIsolines(grid, levels), [grid, levels])
  
  const { roomWidth, roomLength } = grid
  
  // SVG viewBox centered on room
  const viewBox = `${-roomWidth/2} ${-roomLength/2} ${roomWidth} ${roomLength}`
  
  return (
    <svg
      viewBox={viewBox}
      className={className}
      style={{ opacity }}
      preserveAspectRatio="xMidYMid meet"
    >
      {isolines.map((iso, isoIndex) => (
        <g key={`iso-${iso.level}-${isoIndex}`}>
          {iso.segments.map((seg, segIndex) => (
            <line
              key={`seg-${segIndex}`}
              x1={seg[0].x}
              y1={seg[0].z}
              x2={seg[1].x}
              y2={seg[1].z}
              stroke={iso.color}
              strokeWidth={0.03}
              strokeLinecap="round"
            />
          ))}
          
          {/* Labels at segment midpoints (sparse) */}
          {showLabels && iso.segments.length > 0 && iso.segments
            .filter((_, i) => i % Math.max(1, Math.floor(iso.segments.length / 3)) === 0)
            .map((seg, labelIndex) => {
              const midX = (seg[0].x + seg[1].x) / 2
              const midZ = (seg[0].z + seg[1].z) / 2
              return (
                <text
                  key={`label-${labelIndex}`}
                  x={midX}
                  y={midZ}
                  fontSize={0.15}
                  fill={iso.color}
                  textAnchor="middle"
                  dominantBaseline="middle"
                  style={{ fontWeight: 600 }}
                >
                  {iso.level}
                </text>
              )
            })}
        </g>
      ))}
    </svg>
  )
}

// =============================================================================
// Canvas Component (for 2D view)
// =============================================================================

export function IsolinesCanvas({
  grid,
  levels = [100, 200, 300, 500],
  showLabels = true,
  opacity = 0.8,
  width,
  height,
  panOffset = { x: 0, y: 0 },
  zoom = 1,
  roomWidth: propRoomWidth,
  roomLength: propRoomLength,
  className = ''
}: IsolinesCanvasProps) {
  const canvasRef = React.useRef<HTMLCanvasElement>(null)
  
  const isolines = useMemo(() => generateIsolines(grid, levels), [grid, levels])
  
  React.useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    // Use passed room dimensions or fall back to grid dimensions
    const roomWidth = propRoomWidth ?? grid.roomWidth
    const roomLength = propRoomLength ?? grid.roomLength
    
    // Clear
    ctx.clearRect(0, 0, width, height)
    
    // Use the same transform calculation as Viewer2D
    const padding = 60
    const scaleX = (width - padding * 2) / roomWidth
    const scaleZ = (height - padding * 2) / roomLength
    const scale = Math.min(scaleX, scaleZ) * zoom
    
    const offsetX = width / 2 + panOffset.x
    const offsetY = height / 2 + panOffset.y
    
    ctx.save()
    ctx.globalAlpha = opacity
    
    // Draw isolines using the same room-to-canvas transform as Viewer2D
    for (const iso of isolines) {
      ctx.strokeStyle = iso.color
      ctx.lineWidth = 2
      ctx.lineCap = 'round'
      
      for (const seg of iso.segments) {
        // Convert room coords to canvas coords (same as Viewer2D.roomToCanvas)
        const x1 = offsetX + seg[0].x * scale
        const y1 = offsetY + seg[0].z * scale
        const x2 = offsetX + seg[1].x * scale
        const y2 = offsetY + seg[1].z * scale
        
        ctx.beginPath()
        ctx.moveTo(x1, y1)
        ctx.lineTo(x2, y2)
        ctx.stroke()
      }
      
      // Draw labels
      if (showLabels && iso.segments.length > 0) {
        ctx.fillStyle = iso.color
        ctx.font = 'bold 14px sans-serif'
        ctx.textAlign = 'center'
        ctx.textBaseline = 'middle'
        
        // Draw label at a few points along the contour
        const labelCount = Math.min(3, iso.segments.length)
        const step = Math.floor(iso.segments.length / labelCount)
        
        for (let i = 0; i < labelCount; i++) {
          const seg = iso.segments[i * step]
          if (seg) {
            const midX = (seg[0].x + seg[1].x) / 2
            const midZ = (seg[0].z + seg[1].z) / 2
            
            // Convert to canvas coords
            const canvasX = offsetX + midX * scale
            const canvasY = offsetY + midZ * scale
            
            // Draw background for readability
            const text = `${iso.level}`
            const metrics = ctx.measureText(text)
            const padding = 2
            
            ctx.globalAlpha = 0.8
            ctx.fillStyle = '#ffffff'
            ctx.fillRect(
              canvasX - metrics.width / 2 - padding,
              canvasY - 7 - padding,
              metrics.width + padding * 2,
              14 + padding * 2
            )
            
            ctx.globalAlpha = opacity
            ctx.fillStyle = iso.color
            ctx.fillText(text, canvasX, canvasY)
          }
        }
      }
    }
    
    ctx.restore()
  }, [grid, isolines, levels, showLabels, opacity, width, height, panOffset, zoom, propRoomWidth, propRoomLength])
  
  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className={className}
      style={{ pointerEvents: 'none' }}
    />
  )
}

// =============================================================================
// Default Export
// =============================================================================

export default IsolinesCanvas
