import React, { useRef, useState } from 'react'
import { parseDXF } from '../../lib/dxf/DXFParser'
import { isDWG, parseDWG } from '../../lib/dxf/DWGParser'
import { usePlannerStore } from '../../stores/plannerStore'

export function DXFImportModal() {
  const [isOpen, setIsOpen] = useState(false)
  const [file, setFile] = useState<File | null>(null)
  const [error, setError] = useState<string | null>(null)
  const [success, setSuccess] = useState<boolean>(false)
  const [isProcessing, setIsProcessing] = useState<boolean>(false)
  const [stats, setStats] = useState<{ width: number; length: number; layers: string[] } | null>(null)
  const fileInputRef = useRef<HTMLInputElement>(null)

  const setRoomBounds = usePlannerStore(state => state.setRoomBounds)
  const setCadEntities = usePlannerStore(state => state.setCadEntities)

  const processFile = async (selectedFile: File): Promise<{ width: number, length: number, layers: string[], bounds: any, entities: any[] } | null> => {
      if (selectedFile.name.toLowerCase().endsWith('.dwg')) {
          // Check magic bytes
          const buffer = await selectedFile.slice(0, 6).arrayBuffer()
          if (!isDWG(buffer)) {
              throw new Error('Invalid DWG file format.')
          }

          const fullBuffer = await selectedFile.arrayBuffer()
          const result = await parseDWG(fullBuffer)
          
          return {
              width: result.bounds.width,
              length: result.bounds.height,
              layers: result.layers,
              bounds: result.bounds,
              entities: result.entities
          }
      } else {
          // DXF
          const text = await selectedFile.text()
          const result = parseDXF(text)
          return {
              width: result.bounds.width,
              length: result.bounds.height,
              layers: result.layers,
              bounds: result.bounds,
              entities: result.entities
          }
      }
  }

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const selectedFile = e.target.files?.[0]
    if (!selectedFile) return

    setFile(selectedFile)
    setError(null)
    setSuccess(false)
    setStats(null)
    setIsProcessing(true)

    try {
      const result = await processFile(selectedFile)
      if (result) {
          setStats({
              width: result.width,
              length: result.length,
              layers: result.layers
          })
      }
    } catch (err) {
      setError(`Failed to parse file: ${(err as Error).message}`)
      console.error(err)
    } finally {
        setIsProcessing(false)
    }
  }

  const handleImport = async () => {
    if (!file) return
    setIsProcessing(true)

    try {
      const result = await processFile(file)
      
      if (result) {
        setRoomBounds(result.bounds)
        setCadEntities(result.entities)
        setSuccess(true)
        setTimeout(() => {
            setIsOpen(false)
            setFile(null)
            setSuccess(false)
            setStats(null)
        }, 1500)
      }
    } catch (err) {
      setError('Failed to import geometry.')
    } finally {
        setIsProcessing(false)
    }
  }

  return (
    <>
      <button
        onClick={() => setIsOpen(true)}
        className="flex items-center gap-2 px-3 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 shadow-sm transition-colors"
      >
        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 16v1a3 3 0 003 3h10a3 3 0 003-3v-1m-4-8l-4-4m0 0L8 8m4-4v12" />
        </svg>
        <span>Import DXF/DWG</span>
      </button>

      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-sm">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full overflow-hidden" onClick={(e) => e.stopPropagation()}>
            <div className="p-6">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Import Room Geometry</h3>
              <p className="text-sm text-gray-500 mb-6">
                Upload a .dxf or .dwg file to automatically set room dimensions from the floor plan.
              </p>

              <div 
                className={`
                  flex flex-col items-center justify-center border-2 border-dashed rounded-lg p-8 mb-4 transition-colors cursor-pointer
                  ${file ? 'border-blue-300 bg-blue-50' : 'border-gray-200 hover:bg-gray-50'}
                `}
                onClick={() => !isProcessing && fileInputRef.current?.click()}
              >
                <input 
                  ref={fileInputRef}
                  type="file" 
                  accept=".dxf,.dwg" 
                  className="hidden" 
                  onChange={handleFileChange}
                  disabled={isProcessing}
                />
                
                {isProcessing ? (
                     <div className="text-center">
                        <svg className="animate-spin w-10 h-10 text-blue-500 mx-auto mb-3" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                            <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                            <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                        </svg>
                        <p className="font-medium text-sm text-gray-900">Processing file...</p>
                        <p className="text-xs text-gray-500 mt-1">This may take a moment</p>
                     </div>
                ) : file ? (
                  <div className="text-center">
                    <svg className="w-10 h-10 text-blue-500 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                    </svg>
                    <p className="font-medium text-sm text-gray-900">{file.name}</p>
                    <p className="text-xs text-gray-500 mt-1">{(file.size / 1024).toFixed(1)} KB</p>
                  </div>
                ) : (
                  <div className="text-center">
                    <svg className="w-10 h-10 text-gray-400 mx-auto mb-3" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M7 16a4 4 0 01-.88-7.903A5 5 0 1115.9 6L16 6a5 5 0 011 9.9M15 13l-3-3m0 0l-3 3m3-3v12" />
                    </svg>
                    <p className="font-medium text-sm text-gray-900">Click to select file</p>
                    <p className="text-xs text-gray-500 mt-1">Supported format: .dxf (ASCII), .dwg</p>
                  </div>
                )}
              </div>

              {error && (
                <div className="mb-4 p-3 bg-red-50 text-red-700 text-sm rounded-lg flex items-start gap-2">
                  <svg className="w-5 h-5 shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>{error}</span>
                </div>
              )}

              {stats && !error && (
                <div className="mb-4 p-4 bg-gray-50 rounded-lg text-sm border border-gray-100">
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-500">Detected Width:</span>
                    <span className="font-medium text-gray-900">{stats.width.toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between mb-2">
                    <span className="text-gray-500">Detected Length:</span>
                    <span className="font-medium text-gray-900">{stats.length.toFixed(2)} m</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-500">Layers found:</span>
                    <span className="font-medium text-gray-900">{stats.layers.length}</span>
                  </div>
                </div>
              )}

              {success && (
                <div className="mb-4 p-3 bg-green-50 text-green-700 text-sm rounded-lg flex items-center gap-2">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                  </svg>
                  Room dimensions updated successfully!
                </div>
              )}

              <div className="flex justify-end gap-3 mt-6">
                <button
                  onClick={() => {
                    setIsOpen(false)
                    setFile(null)
                    setError(null)
                    setSuccess(false)
                    setIsProcessing(false)
                  }}
                  className="px-4 py-2 text-sm font-medium text-gray-700 bg-white border border-gray-300 rounded-lg hover:bg-gray-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-gray-500"
                >
                  Cancel
                </button>
                <button
                  onClick={handleImport}
                  disabled={!file || !!error || success || isProcessing}
                  className={`
                    px-4 py-2 text-sm font-medium text-white rounded-lg focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500
                    ${!file || !!error || success || isProcessing
                      ? 'bg-blue-300 cursor-not-allowed'
                      : 'bg-blue-600 hover:bg-blue-700'
                    }
                  `}
                >
                  Import Geometry
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </>
  )
}

