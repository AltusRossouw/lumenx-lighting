/**
 * OrbitX Lighting Planner - Value Grid Display
 * 
 * Renders illuminance values at grid points on the work plane.
 * Shows numeric lux values with color-coding based on intensity.
 */

'use client'

import React, { useMemo, useEffect, useRef } from 'react'
import type { CalculationGrid, ColorStop } from '../../lib/photometry/types'
import { DIALUX_COLOR_SCALE } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface ValueGridProps {
  grid: CalculationGrid
  density?: number // Show every Nth value (1 = all, 2 = every other, etc.)
  showMinMax?: boolean
  fontSize?: number
  opacity?: number
  className?: string
}

interface ValueGridCanvasProps extends ValueGridProps {
  width: number
  height: number
  panOffset?: { x: number; y: number }
  zoom?: number
  roomWidth?: number
  roomLength?: number
}

// =============================================================================
// Color Utilities
// =============================================================================

/**
 * Interpolate between color stops to get a color for a value.
 */
function getColorForValue(
  value: number,
  min: number,
  max: number,
  colorScale: ColorStop[] = DIALUX_COLOR_SCALE
): string {
  if (max <= min) return `rgb(${colorScale[2].color.join(',')})`
  
  const t = Math.max(0, Math.min(1, (value - min) / (max - min)))
  
  // Find surrounding color stops
  let lower = colorScale[0]
  let upper = colorScale[colorScale.length - 1]
  
  for (let i = 0; i < colorScale.length - 1; i++) {
    if (t >= colorScale[i].position && t <= colorScale[i + 1].position) {
      lower = colorScale[i]
      upper = colorScale[i + 1]
      break
    }
  }
  
  // Interpolate between stops
  const range = upper.position - lower.position
  const localT = range > 0 ? (t - lower.position) / range : 0
  
  const r = Math.round(lower.color[0] + (upper.color[0] - lower.color[0]) * localT)
  const g = Math.round(lower.color[1] + (upper.color[1] - lower.color[1]) * localT)
  const b = Math.round(lower.color[2] + (upper.color[2] - lower.color[2]) * localT)
  
  return `rgb(${r},${g},${b})`
}

/**
 * Get contrasting text color (black or white) for a background.
 */
function getContrastColor(r: number, g: number, b: number): string {
  // Calculate relative luminance
  const luminance = (0.299 * r + 0.587 * g + 0.114 * b) / 255
  return luminance > 0.5 ? '#000000' : '#ffffff'
}

/**
 * Parse rgb string to get components.
 */
function parseRgb(rgb: string): [number, number, number] {
  const match = rgb.match(/rgb\((\d+),(\d+),(\d+)\)/)
  if (match) {
    return [parseInt(match[1]), parseInt(match[2]), parseInt(match[3])]
  }
  return [128, 128, 128]
}

// =============================================================================
// Canvas Component
// =============================================================================

export function ValueGridCanvas({
  grid,
  density = 2,
  showMinMax = true,
  fontSize = 10,
  opacity = 1,
  width,
  height,
  panOffset = { x: 0, y: 0 },
  zoom = 1,
  roomWidth: propRoomWidth,
  roomLength: propRoomLength,
  className = ''
}: ValueGridCanvasProps) {
  const canvasRef = useRef<HTMLCanvasElement>(null)
  
  const { minValue, maxValue, minPoint, maxPoint } = useMemo(() => {
    let min = Infinity
    let max = -Infinity
    let minPt = grid.points[0]
    let maxPt = grid.points[0]
    
    for (const point of grid.points) {
      if (point.illuminance < min) {
        min = point.illuminance
        minPt = point
      }
      if (point.illuminance > max) {
        max = point.illuminance
        maxPt = point
      }
    }
    
    return {
      minValue: min === Infinity ? 0 : min,
      maxValue: max === -Infinity ? 0 : max,
      minPoint: minPt,
      maxPoint: maxPt
    }
  }, [grid.points])
  
  useEffect(() => {
    const canvas = canvasRef.current
    if (!canvas) return
    
    const ctx = canvas.getContext('2d')
    if (!ctx) return
    
    const { points, gridWidth, gridHeight } = grid
    
    // Use passed room dimensions or fall back to grid dimensions
    const roomWidth = propRoomWidth ?? grid.roomWidth
    const roomLength = propRoomLength ?? grid.roomLength
    
    // Clear
    ctx.clearRect(0, 0, width, height)
    
    if (points.length === 0) return
    
    // Use the same transform calculation as Viewer2D
    const padding = 60
    const scaleX = (width - padding * 2) / roomWidth
    const scaleZ = (height - padding * 2) / roomLength
    const scale = Math.min(scaleX, scaleZ) * zoom
    
    const offsetX = width / 2 + panOffset.x
    const offsetY = height / 2 + panOffset.y
    
    ctx.save()
    ctx.globalAlpha = opacity
    
    // Set font
    ctx.font = `bold ${fontSize}px sans-serif`
    ctx.textAlign = 'center'
    ctx.textBaseline = 'middle'
    
    // Draw values at grid points
    for (let zi = 0; zi < gridHeight; zi++) {
      for (let xi = 0; xi < gridWidth; xi++) {
        // Apply density filter
        if (density > 1 && (xi % density !== 0 || zi % density !== 0)) {
          continue
        }
        
        const index = zi * gridWidth + xi
        const point = points[index]
        if (!point) continue
        
        const value = Math.round(point.illuminance)
        const bgColor = getColorForValue(point.illuminance, minValue, maxValue)
        const [r, g, b] = parseRgb(bgColor)
        const textColor = getContrastColor(r, g, b)
        
        // Convert room coords to canvas coords (same as Viewer2D.roomToCanvas)
        const canvasX = offsetX + point.x * scale
        const canvasY = offsetY + point.z * scale
        
        // Draw background pill
        const text = value.toString()
        const metrics = ctx.measureText(text)
        const pillPadding = fontSize * 0.3
        const pillWidth = metrics.width + pillPadding * 2
        const pillHeight = fontSize + pillPadding * 2
        const cornerRadius = pillHeight / 2
        
        ctx.fillStyle = bgColor
        ctx.beginPath()
        ctx.roundRect(
          canvasX - pillWidth / 2,
          canvasY - pillHeight / 2,
          pillWidth,
          pillHeight,
          cornerRadius
        )
        ctx.fill()
        
        // Draw text
        ctx.fillStyle = textColor
        ctx.fillText(text, canvasX, canvasY)
      }
    }
    
    // Draw min/max markers
    if (showMinMax && minPoint && maxPoint) {
      const markerSize = fontSize * 1.5
      
      // Min marker (blue diamond)
      if (minPoint) {
        const minCanvasX = offsetX + minPoint.x * scale
        const minCanvasY = offsetY + minPoint.z * scale
        
        ctx.save()
        ctx.translate(minCanvasX, minCanvasY)
        ctx.rotate(Math.PI / 4)
        ctx.fillStyle = '#1e40af'
        ctx.strokeStyle = '#ffffff'
        ctx.lineWidth = 2
        ctx.fillRect(-markerSize/2, -markerSize/2, markerSize, markerSize)
        ctx.strokeRect(-markerSize/2, -markerSize/2, markerSize, markerSize)
        ctx.restore()
        
        // Label
        ctx.fillStyle = '#1e40af'
        ctx.font = `bold ${fontSize * 0.8}px sans-serif`
        ctx.fillText('MIN', minCanvasX, minCanvasY - markerSize)
      }
      
      // Max marker (red diamond)
      if (maxPoint) {
        const maxCanvasX = offsetX + maxPoint.x * scale
        const maxCanvasY = offsetY + maxPoint.z * scale
        
        ctx.save()
        ctx.translate(maxCanvasX, maxCanvasY)
        ctx.rotate(Math.PI / 4)
        ctx.fillStyle = '#dc2626'
        ctx.strokeStyle = '#ffffff'
        ctx.lineWidth = 2
        ctx.fillRect(-markerSize/2, -markerSize/2, markerSize, markerSize)
        ctx.strokeRect(-markerSize/2, -markerSize/2, markerSize, markerSize)
        ctx.restore()
        
        // Label
        ctx.fillStyle = '#dc2626'
        ctx.font = `bold ${fontSize * 0.8}px sans-serif`
        ctx.fillText('MAX', maxCanvasX, maxCanvasY - markerSize)
      }
    }
    
    ctx.restore()
  }, [grid, density, showMinMax, fontSize, opacity, width, height, panOffset, zoom, minValue, maxValue, minPoint, maxPoint, propRoomWidth, propRoomLength])
  
  return (
    <canvas
      ref={canvasRef}
      width={width}
      height={height}
      className={className}
      style={{ pointerEvents: 'none' }}
    />
  )
}

// =============================================================================
// SVG Component (for static rendering / export)
// =============================================================================

export function ValueGridSVG({
  grid,
  density = 2,
  showMinMax = true,
  fontSize = 0.15,
  opacity = 1,
  className = ''
}: ValueGridProps) {
  const { minValue, maxValue, minPoint, maxPoint, displayPoints } = useMemo(() => {
    let min = Infinity
    let max = -Infinity
    let minPt = grid.points[0]
    let maxPt = grid.points[0]
    
    for (const point of grid.points) {
      if (point.illuminance < min) {
        min = point.illuminance
        minPt = point
      }
      if (point.illuminance > max) {
        max = point.illuminance
        maxPt = point
      }
    }
    
    // Filter points by density
    const display = grid.points.filter((_, index) => {
      const xi = index % grid.gridWidth
      const zi = Math.floor(index / grid.gridWidth)
      return density <= 1 || (xi % density === 0 && zi % density === 0)
    })
    
    return {
      minValue: min === Infinity ? 0 : min,
      maxValue: max === -Infinity ? 0 : max,
      minPoint: minPt,
      maxPoint: maxPt,
      displayPoints: display
    }
  }, [grid, density])
  
  const { roomWidth, roomLength } = grid
  const viewBox = `${-roomWidth/2} ${-roomLength/2} ${roomWidth} ${roomLength}`
  
  return (
    <svg
      viewBox={viewBox}
      className={className}
      style={{ opacity }}
      preserveAspectRatio="xMidYMid meet"
    >
      {displayPoints.map((point, index) => {
        const value = Math.round(point.illuminance)
        const bgColor = getColorForValue(point.illuminance, minValue, maxValue)
        const [r, g, b] = parseRgb(bgColor)
        const textColor = getContrastColor(r, g, b)
        
        return (
          <g key={`value-${index}`}>
            <rect
              x={point.x - fontSize * 1.5}
              y={point.z - fontSize * 0.7}
              width={fontSize * 3}
              height={fontSize * 1.4}
              rx={fontSize * 0.7}
              fill={bgColor}
            />
            <text
              x={point.x}
              y={point.z}
              fontSize={fontSize}
              fill={textColor}
              textAnchor="middle"
              dominantBaseline="middle"
              fontWeight="bold"
            >
              {value}
            </text>
          </g>
        )
      })}
      
      {/* Min marker */}
      {showMinMax && minPoint && (
        <g transform={`translate(${minPoint.x}, ${minPoint.z})`}>
          <rect
            x={-fontSize}
            y={-fontSize}
            width={fontSize * 2}
            height={fontSize * 2}
            fill="#1e40af"
            stroke="#ffffff"
            strokeWidth={0.02}
            transform="rotate(45)"
          />
          <text
            y={-fontSize * 1.5}
            fontSize={fontSize * 0.8}
            fill="#1e40af"
            textAnchor="middle"
            fontWeight="bold"
          >
            MIN
          </text>
        </g>
      )}
      
      {/* Max marker */}
      {showMinMax && maxPoint && (
        <g transform={`translate(${maxPoint.x}, ${maxPoint.z})`}>
          <rect
            x={-fontSize}
            y={-fontSize}
            width={fontSize * 2}
            height={fontSize * 2}
            fill="#dc2626"
            stroke="#ffffff"
            strokeWidth={0.02}
            transform="rotate(45)"
          />
          <text
            y={-fontSize * 1.5}
            fontSize={fontSize * 0.8}
            fill="#dc2626"
            textAnchor="middle"
            fontWeight="bold"
          >
            MAX
          </text>
        </g>
      )}
    </svg>
  )
}

// =============================================================================
// Default Export
// =============================================================================

export default ValueGridCanvas
