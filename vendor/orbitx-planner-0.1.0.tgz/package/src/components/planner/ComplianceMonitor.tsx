/**
 * OrbitX Lighting Planner - Compliance Monitor
 * 
 * Displays real-time compliance status against EN 12464-1 requirements.
 * Shows traffic light indicators and recommendations.
 */

'use client'

import React, { useMemo } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { getActivityById, checkCompliance } from '../../lib/photometry/Standards'
import type { ComplianceResult, ComplianceStatus } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface ComplianceMonitorProps {
  className?: string
  compact?: boolean
}

// =============================================================================
// Main Component
// =============================================================================

export function ComplianceMonitor({ className = '', compact = false }: ComplianceMonitorProps) {
  const results = usePlannerStore(state => state.results)
  const activityType = usePlannerStore(state => state.activityType)
  
  const compliance = useMemo(() => {
    if (!results) return null
    const activity = getActivityById(activityType)
    if (!activity) return null
    return checkCompliance(results, activityType)
  }, [results, activityType])
  
  const activity = useMemo(() => getActivityById(activityType), [activityType])
  
if (!results) {
    return (
      <div className={`bg-gray-50 rounded-lg p-4 text-center text-gray-600 ${className}`}>
        <svg className="w-8 h-8 mx-auto mb-2 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} 
            d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" 
          />
        </svg>
        <p className="text-sm">Run calculation to see compliance</p>
      </div>
    )
  }
  
  if (!compliance || !activity) {
    return (
      <div className={`bg-gray-50 rounded-lg p-4 text-center text-gray-500 ${className}`}>
        <p className="text-sm">Select an activity type</p>
      </div>
    )
  }
  
  if (compact) {
    return (
      <ComplianceCompact compliance={compliance} className={className} />
    )
  }
  
  return (
    <div className={`space-y-4 ${className}`}>
      {/* Overall status */}
      <div className={`
        rounded-lg p-4 flex items-center gap-3
        ${compliance.overallPass 
          ? 'bg-green-50 border border-green-200' 
          : 'bg-red-50 border border-red-200'
        }
      `}>
        <StatusIcon status={compliance.overallPass ? 'pass' : 'fail'} size="lg" />
        <div>
          <div className="font-semibold text-gray-900">
            {compliance.overallPass ? 'Compliant' : 'Non-Compliant'}
          </div>
          <div className="text-sm text-gray-600">
            {activity.name} ({activity.category})
          </div>
        </div>
      </div>
      
      {/* Individual checks */}
      <div className="space-y-3">
        {/* Illuminance */}
        <ComplianceRow
          label="Illuminance (Eavg)"
          value={Math.round(compliance.illuminanceValue)}
          target={compliance.illuminanceTarget}
          unit="lux"
          pass={compliance.illuminancePass}
          comparison=">="
        />
        
        {/* Uniformity */}
        <ComplianceRow
          label="Uniformity (Uo)"
          value={compliance.uniformityValue.toFixed(2)}
          target={compliance.uniformityTarget}
          unit=""
          pass={compliance.uniformityPass}
          comparison=">="
        />
        
        {/* UGR */}
        <ComplianceRow
          label="Glare (UGR)"
          value={compliance.ugrValue !== null ? compliance.ugrValue.toFixed(1) : 'N/A'}
          target={compliance.ugrTarget}
          unit=""
          pass={compliance.ugrPass}
          comparison="<="
          inverted
        />
      </div>
      
      {/* Recommendations */}
      {compliance.recommendations.length > 0 && (
        <div className="bg-amber-50 border border-amber-200 rounded-lg p-3">
          <div className="flex items-start gap-2">
            <svg className="w-5 h-5 text-amber-500 flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} 
                d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" 
              />
            </svg>
            <div>
              <div className="font-medium text-amber-800 text-sm mb-1">Recommendations</div>
              <ul className="text-sm text-amber-700 space-y-1">
                {compliance.recommendations.map((rec, i) => (
                  <li key={i}>{rec}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Compact Version
// =============================================================================

function ComplianceCompact({ compliance, className }: { compliance: ComplianceResult; className?: string }) {
  return (
    <div className={`flex items-center gap-4 ${className}`}>
      {/* Overall */}
      <div className="flex items-center gap-2">
        <StatusIcon status={compliance.overallPass ? 'pass' : 'fail'} />
        <span className="text-sm font-medium">
          {compliance.overallPass ? 'Pass' : 'Fail'}
        </span>
      </div>
      
      {/* Individual indicators */}
      <div className="flex items-center gap-3 text-xs">
        <div className="flex items-center gap-1">
          <StatusDot pass={compliance.illuminancePass} />
          <span>E</span>
        </div>
        <div className="flex items-center gap-1">
          <StatusDot pass={compliance.uniformityPass} />
          <span>Uo</span>
        </div>
        <div className="flex items-center gap-1">
          <StatusDot pass={compliance.ugrPass} />
          <span>UGR</span>
        </div>
      </div>
    </div>
  )
}

// =============================================================================
// Compliance Row
// =============================================================================

interface ComplianceRowProps {
  label: string
  value: string | number
  target: number
  unit: string
  pass: boolean
  comparison: '>=' | '<='
  inverted?: boolean
}

function ComplianceRow({ label, value, target, unit, pass, comparison, inverted }: ComplianceRowProps) {
  const getStatus = (): ComplianceStatus => {
    if (pass) return 'pass'
    
    // Check if marginal (within 10% of target)
    const numValue = typeof value === 'string' ? parseFloat(value) : value
    if (isNaN(numValue)) return 'unknown'
    
    const margin = target * 0.1
    if (inverted) {
      // For UGR: lower is better
      if (numValue <= target + margin) return 'marginal'
    } else {
      // For illuminance/uniformity: higher is better
      if (numValue >= target - margin) return 'marginal'
    }
    
    return 'fail'
  }
  
  const status = getStatus()
  
  return (
    <div className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
      <div className="flex items-center gap-3">
        <StatusIcon status={status} />
        <div>
          <div className="text-sm font-medium text-gray-900">{label}</div>
          <div className="text-xs text-gray-600">
            Target: {comparison} {target}{unit}
          </div>
        </div>
      </div>
      <div className={`text-lg font-semibold ${
        status === 'pass' ? 'text-green-600' :
        status === 'marginal' ? 'text-amber-600' :
        status === 'fail' ? 'text-red-600' : 'text-gray-500'
      }`}>
        {value}{unit}
      </div>
    </div>
  )
}

// =============================================================================
// Status Indicators
// =============================================================================

interface StatusIconProps {
  status: ComplianceStatus
  size?: 'sm' | 'md' | 'lg'
}

function StatusIcon({ status, size = 'md' }: StatusIconProps) {
  const sizeClasses = {
    sm: 'w-4 h-4',
    md: 'w-5 h-5',
    lg: 'w-8 h-8'
  }
  
  const colors = {
    pass: 'text-green-500',
    marginal: 'text-amber-500',
    fail: 'text-red-500',
    unknown: 'text-gray-500'
  }
  
  const icons = {
    pass: (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
    ),
    marginal: (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
    ),
    fail: (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
    ),
    unknown: (
      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8.228 9c.549-1.165 2.03-2 3.772-2 2.21 0 4 1.343 4 3 0 1.4-1.278 2.575-3.006 2.907-.542.104-.994.54-.994 1.093m0 3h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
    )
  }
  
  return (
    <svg className={`${sizeClasses[size]} ${colors[status]}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
      {icons[status]}
    </svg>
  )
}

function StatusDot({ pass }: { pass: boolean }) {
  return (
    <span className={`w-2 h-2 rounded-full ${pass ? 'bg-green-500' : 'bg-red-500'}`} />
  )
}

// =============================================================================
// Export
// =============================================================================

export default ComplianceMonitor
