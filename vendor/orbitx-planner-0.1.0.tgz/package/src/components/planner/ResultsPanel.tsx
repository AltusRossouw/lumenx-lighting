/**
 * OrbitX Lighting Planner - Results Panel
 * 
 * Displays calculation results summary including:
 * - Illuminance metrics (Emin, Emax, Eavg)
 * - Uniformity ratios (Uo, Ud)
 * - Power metrics (total power, W/m², LENI)
 */

'use client'

import React from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { ColorLegend } from './ColorLegend'

// =============================================================================
// Types
// =============================================================================

interface ResultsPanelProps {
  className?: string
  compact?: boolean
}

// =============================================================================
// Main Component
// =============================================================================

export function ResultsPanel({ className = '', compact = false }: ResultsPanelProps) {
  const results = usePlannerStore(state => state.results)
  const isCalculating = usePlannerStore(state => state.isCalculating)
  const calculationProgress = usePlannerStore(state => state.calculationProgress)
  const calculationMessage = usePlannerStore(state => state.calculationMessage)
  const room = usePlannerStore(state => state.room)
  
  if (isCalculating) {
    return (
      <div className={`bg-white rounded-lg border p-4 ${className}`}>
        <div className="flex items-center gap-3">
          <div className="w-5 h-5 border-2 border-blue-500 border-t-transparent rounded-full animate-spin" />
          <div className="flex-1">
            <div className="text-sm font-medium">Calculating...</div>
            <div className="text-xs text-gray-600">{calculationMessage || 'Please wait'}</div>
          </div>
          <div className="text-sm font-mono text-gray-600">{calculationProgress}%</div>
        </div>
        <div className="mt-2 h-1.5 bg-gray-200 rounded-full overflow-hidden">
          <div 
            className="h-full bg-blue-500 transition-all duration-300"
            style={{ width: `${calculationProgress}%` }}
          />
        </div>
      </div>
    )
  }
  
  if (!results) {
    return (
      <div className={`bg-gray-50 rounded-lg border border-dashed border-gray-300 p-6 text-center ${className}`}>
        <svg className="w-10 h-10 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.5} 
            d="M9 7h6m0 10v-3m-3 3h.01M9 17h.01M9 14h.01M12 14h.01M15 11h.01M12 11h.01M9 11h.01M7 21h10a2 2 0 002-2V5a2 2 0 00-2-2H7a2 2 0 00-2 2v14a2 2 0 002 2z" 
          />
        </svg>
        <p className="text-sm text-gray-600 mb-1">No results yet</p>
        <p className="text-xs text-gray-500">Add luminaires and run calculation</p>
      </div>
    )
  }
  
  const area = room.width * room.length
  
  if (compact) {
    return (
      <div className={`grid grid-cols-4 gap-2 ${className}`}>
        <MetricBadge label="Eavg" value={Math.round(results.Eavg)} unit="lux" />
        <MetricBadge label="Uo" value={results.Uo.toFixed(2)} />
        <MetricBadge label="W/m²" value={results.powerDensity.toFixed(1)} />
        <MetricBadge label="Fixtures" value={results.luminaireCount} />
      </div>
    )
  }
  
  return (
    <div className={`space-y-4 ${className}`}>
      {/* Illuminance metrics */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Illuminance
        </h4>
        <div className="grid grid-cols-3 gap-2">
          <MetricCard 
            label="Average" 
            value={Math.round(results.Eavg)} 
            unit="lux"
            highlight
          />
          <MetricCard 
            label="Minimum" 
            value={Math.round(results.Emin)} 
            unit="lux"
          />
          <MetricCard 
            label="Maximum" 
            value={Math.round(results.Emax)} 
            unit="lux"
          />
        </div>
      </div>
      
      {/* Uniformity metrics */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Uniformity
        </h4>
        <div className="grid grid-cols-2 gap-2">
          <MetricCard 
            label="Uo (Emin/Eavg)" 
            value={results.Uo.toFixed(2)} 
            highlight
            status={results.Uo >= 0.4 ? 'good' : results.Uo >= 0.3 ? 'warning' : 'bad'}
          />
          <MetricCard 
            label="Ud (Emin/Emax)" 
            value={results.Ud.toFixed(2)} 
          />
        </div>
      </div>
      
      {/* Vertical & cylindrical illuminance */}
      {(results.Evavg !== undefined || results.Ezavg !== undefined) && (
        <div>
          <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
            Vertical & Cylindrical
          </h4>
          <div className="grid grid-cols-2 gap-2">
            <MetricCard
              label="Vertical (walls) Ev"
              value={Math.round(results.Evavg ?? 0)}
              unit="lux"
            />
            <MetricCard
              label="Cylindrical Ez"
              value={Math.round(results.Ezavg ?? 0)}
              unit="lux"
            />
          </div>
        </div>
      )}

      {/* Power metrics */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Energy
        </h4>
        <div className="grid grid-cols-3 gap-2">
          <MetricCard 
            label="Total Power" 
            value={Math.round(results.totalPower)} 
            unit="W"
          />
          <MetricCard 
            label="Power Density" 
            value={results.powerDensity.toFixed(1)} 
            unit="W/m²"
            highlight
          />
          <MetricCard 
            label="LENI" 
            value={results.LENI.toFixed(1)} 
            unit="kWh/m²/yr"
          />
        </div>
      </div>
      
      {/* Summary */}
      <div className="bg-gray-50 rounded-lg p-3">
        <div className="grid grid-cols-4 gap-4 text-center text-sm">
          <div>
            <div className="font-semibold text-gray-900">{results.luminaireCount}</div>
            <div className="text-xs text-gray-600">Luminaires</div>
          </div>
          <div>
            <div className="font-semibold text-gray-900">{Math.round(results.totalLumens).toLocaleString()}</div>
            <div className="text-xs text-gray-600">Total Lumens</div>
          </div>
          <div>
            <div className="font-semibold text-gray-900">{area.toFixed(1)} m²</div>
            <div className="text-xs text-gray-600">Room Area</div>
          </div>
          <div>
            <div className="font-semibold text-gray-900">{Math.round(results.maintenanceFactor * 100)}%</div>
            <div className="text-xs text-gray-600">Maintenance</div>
          </div>
        </div>
      </div>
      
      {/* False-color legend */}
      <ColorLegend
        min={results.Emin}
        max={results.Emax}
        markers={[{ label: `avg ${Math.round(results.Eavg)}`, value: results.Eavg }]}
      />

      {/* Calculation time */}
      <div className="text-xs text-gray-500 text-right">
        Calculated in {results.calculationTime.toFixed(0)}ms
      </div>
    </div>
  )
}

// =============================================================================
// Metric Components
// =============================================================================

interface MetricCardProps {
  label: string
  value: string | number
  unit?: string
  highlight?: boolean
  status?: 'good' | 'warning' | 'bad'
}

function MetricCard({ label, value, unit, highlight, status }: MetricCardProps) {
  const statusColors = {
    good: 'border-green-200 bg-green-50',
    warning: 'border-amber-200 bg-amber-50',
    bad: 'border-red-200 bg-red-50'
  }
  
  return (
    <div className={`
      rounded-lg p-2 border
      ${status ? statusColors[status] : highlight ? 'border-blue-200 bg-blue-50' : 'border-gray-200 bg-white'}
    `}>
      <div className={`text-lg font-semibold ${highlight ? 'text-blue-700' : 'text-gray-900'}`}>
        {value}
        {unit && <span className="text-xs font-normal text-gray-600 ml-1">{unit}</span>}
      </div>
      <div className="text-xs text-gray-600 truncate">{label}</div>
    </div>
  )
}

interface MetricBadgeProps {
  label: string
  value: string | number
  unit?: string
}

function MetricBadge({ label, value, unit }: MetricBadgeProps) {
  return (
    <div className="bg-gray-100 rounded px-2 py-1 text-center">
      <div className="text-sm font-semibold text-gray-900">
        {value}{unit && <span className="text-xs font-normal ml-0.5">{unit}</span>}
      </div>
      <div className="text-xs text-gray-600">{label}</div>
    </div>
  )
}

// =============================================================================
// Export
// =============================================================================

export default ResultsPanel
