/**
 * OrbitX Lighting Planner - Quote Request Modal
 * 
 * Modal for users to request a quote based on their lighting design.
 * Captures basic contact info and sends to email endpoint.
 */

'use client'

import React, { useState, useCallback } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'

// =============================================================================
// Types
// =============================================================================

interface QuoteRequestModalProps {
  isOpen: boolean
  onClose: () => void
}

interface QuoteFormData {
  name: string
  email: string
  phone: string
  company: string
  message: string
}

// =============================================================================
// Main Component
// =============================================================================

export function QuoteRequestModal({ isOpen, onClose }: QuoteRequestModalProps) {
  const [formData, setFormData] = useState<QuoteFormData>({
    name: '',
    email: '',
    phone: '',
    company: '',
    message: ''
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [submitted, setSubmitted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  
  // Get project data from store
  const projectName = usePlannerStore(state => state.projectName)
  const room = usePlannerStore(state => state.room)
  const luminaires = usePlannerStore(state => state.luminaires)
  const results = usePlannerStore(state => state.results)
  const activityType = usePlannerStore(state => state.activityType)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  
  // Handle form field changes
  const handleChange = useCallback((
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    const { name, value } = e.target
    setFormData(prev => ({ ...prev, [name]: value }))
    setError(null)
  }, [])
  
  // Submit quote request
  const handleSubmit = useCallback(async (e: React.FormEvent) => {
    e.preventDefault()
    
    // Basic validation
    if (!formData.name.trim() || !formData.email.trim()) {
      setError('Please enter your name and email address.')
      return
    }
    
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      setError('Please enter a valid email address.')
      return
    }
    
    setIsSubmitting(true)
    setError(null)
    
    try {
      // Get luminaire summary
      const luminaireSummary = getLuminaireSummary(luminaires, iesProfiles)
      
      const response = await fetch('/api/quote', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          // Contact info
          name: formData.name.trim(),
          email: formData.email.trim(),
          phone: formData.phone.trim() || undefined,
          company: formData.company.trim() || undefined,
          message: formData.message.trim() || undefined,
          
          // Project info
          projectName,
          roomDimensions: `${room.width}m x ${room.length}m x ${room.height}m`,
          roomArea: room.width * room.length,
          activityType,
          luminaireCount: luminaires.length,
          luminaireSummary,
          
          // Results (if available)
          results: results ? {
            avgLux: Math.round(results.Eavg),
            uniformity: results.Uo.toFixed(2),
            totalWatts: Math.round(results.totalPower),
            wattsPerSqm: results.powerDensity.toFixed(1)
          } : null
        })
      })
      
      if (!response.ok) {
        const data = await response.json()
        throw new Error(data.error || 'Failed to submit quote request')
      }
      
      setSubmitted(true)
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to submit. Please try again.')
    } finally {
      setIsSubmitting(false)
    }
  }, [formData, projectName, room, luminaires, results, activityType, iesProfiles])
  
  // Reset form when modal closes
  const handleClose = useCallback(() => {
    setFormData({ name: '', email: '', phone: '', company: '', message: '' })
    setSubmitted(false)
    setError(null)
    onClose()
  }, [onClose])
  
  if (!isOpen) return null
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full mx-4 overflow-hidden">
        {submitted ? (
          // Success state
          <div className="p-8 text-center">
            <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <svg className="w-8 h-8 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
              </svg>
            </div>
            <h2 className="text-2xl font-bold text-gray-900 mb-2">Request Sent!</h2>
            <p className="text-gray-600 mb-6">
              Thank you for your interest! Our team will review your lighting design and get back to you within 1-2 business days.
            </p>
            <button
              onClick={handleClose}
              className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
            >
              Close
            </button>
          </div>
        ) : (
          // Form state
          <>
            <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
              <h2 className="text-xl font-bold">Request a Quote</h2>
              <p className="text-blue-100 text-sm mt-1">
                Get pricing for your lighting design
              </p>
            </div>
            
            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              {/* Project summary */}
              <div className="bg-gray-50 rounded-lg p-4 text-sm">
                <div className="font-medium text-gray-900 mb-2">{projectName}</div>
                <div className="grid grid-cols-2 gap-2 text-gray-600">
                  <div>Room: {room.width}m x {room.length}m</div>
                  <div>Luminaires: {luminaires.length}</div>
                  {results && (
                    <>
                      <div>Avg: {Math.round(results.Eavg)} lux</div>
                      <div>Power: {Math.round(results.totalPower)}W</div>
                    </>
                  )}
                </div>
              </div>
              
              {/* Contact fields */}
              <div className="grid grid-cols-2 gap-4">
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Name <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Your name"
                  />
                </div>
                
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Email <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="your@email.com"
                  />
                </div>
                
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Phone
                  </label>
                  <input
                    type="tel"
                    name="phone"
                    value={formData.phone}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="+27 XX XXX XXXX"
                  />
                </div>
                
                <div className="col-span-2 sm:col-span-1">
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Company
                  </label>
                  <input
                    type="text"
                    name="company"
                    value={formData.company}
                    onChange={handleChange}
                    className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Company name (optional)"
                  />
                </div>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Additional Notes
                </label>
                <textarea
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  rows={3}
                  className="w-full px-3 py-2 border rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500 resize-none"
                  placeholder="Any specific requirements or questions..."
                />
              </div>
              
              {/* Error message */}
              {error && (
                <div className="p-3 bg-red-50 border border-red-200 text-red-700 rounded-lg text-sm">
                  {error}
                </div>
              )}
              
              {/* Actions */}
              <div className="flex gap-3 pt-2">
                <button
                  type="button"
                  onClick={handleClose}
                  className="flex-1 px-4 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50 transition-colors"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  disabled={isSubmitting}
                  className={`flex-1 px-4 py-2 rounded-lg text-white transition-colors flex items-center justify-center gap-2 ${
                    isSubmitting
                      ? 'bg-blue-400 cursor-wait'
                      : 'bg-blue-600 hover:bg-blue-700'
                  }`}
                >
                  {isSubmitting ? (
                    <>
                      <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
                      </svg>
                      Sending...
                    </>
                  ) : (
                    'Send Request'
                  )}
                </button>
              </div>
              
              <p className="text-xs text-gray-500 text-center">
                By submitting, you agree to be contacted regarding your quote request.
              </p>
            </form>
          </>
        )}
      </div>
    </div>
  )
}

// =============================================================================
// Helper Functions
// =============================================================================

function getLuminaireSummary(
  luminaires: Array<{ iesProfileId: string }>,
  iesProfiles: Array<{ id: string; productName: string; variantLabel: string }>
): string {
  // Group luminaires by profile
  const counts: Record<string, number> = {}
  
  for (const lum of luminaires) {
    counts[lum.iesProfileId] = (counts[lum.iesProfileId] || 0) + 1
  }
  
  // Create summary string
  const parts: string[] = []
  
  for (const [profileId, count] of Object.entries(counts)) {
    const profile = iesProfiles.find(p => p.id === profileId)
    if (profile) {
      parts.push(`${count}x ${profile.productName} ${profile.variantLabel}`)
    } else {
      parts.push(`${count}x Unknown Luminaire`)
    }
  }
  
  return parts.join(', ') || 'No luminaires'
}

// =============================================================================
// Export
// =============================================================================

export default QuoteRequestModal
