/**
 * OrbitX Lighting Planner - Responsive Layout
 * 
 * Adaptive layout that works on desktop, tablet, and mobile.
 * Desktop: 3-column layout with resizable sidebar panels
 * Tablet: 2-column with collapsible panels
 * Mobile: Bottom sheet with always-visible viewer
 */

'use client'

import React, { useState, useEffect, useCallback, useRef, TouchEvent } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import type { PlannerTab } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface PlannerLayoutProps {
  children: React.ReactNode
  leftPanel?: React.ReactNode
  rightPanel?: React.ReactNode
  bottomBar?: React.ReactNode
  header?: React.ReactNode
}

// =============================================================================
// Constants
// =============================================================================

const MIN_PANEL_WIDTH = 200
const MAX_PANEL_WIDTH = 500
const DEFAULT_PANEL_WIDTH = 320

// =============================================================================
// Hooks
// =============================================================================

function useBreakpoint() {
  const [breakpoint, setBreakpoint] = useState<'mobile' | 'tablet' | 'desktop'>('desktop')
  
  useEffect(() => {
    const checkBreakpoint = () => {
      const width = window.innerWidth
      if (width < 768) {
        setBreakpoint('mobile')
      } else if (width < 1024) {
        setBreakpoint('tablet')
      } else {
        setBreakpoint('desktop')
      }
    }
    
    checkBreakpoint()
    window.addEventListener('resize', checkBreakpoint)
    return () => window.removeEventListener('resize', checkBreakpoint)
  }, [])
  
  return breakpoint
}

// =============================================================================
// Resizable Divider Component
// =============================================================================

interface ResizeDividerProps {
  onResize: (delta: number) => void
  direction: 'left' | 'right'
}

function ResizeDivider({ onResize, direction }: ResizeDividerProps) {
  const [isDragging, setIsDragging] = useState(false)
  const startXRef = useRef(0)
  
  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault()
    setIsDragging(true)
    startXRef.current = e.clientX
  }, [])
  
  useEffect(() => {
    if (!isDragging) return
    
    const handleMouseMove = (e: MouseEvent) => {
      const delta = e.clientX - startXRef.current
      startXRef.current = e.clientX
      onResize(direction === 'left' ? delta : -delta)
    }
    
    const handleMouseUp = () => {
      setIsDragging(false)
    }
    
    document.addEventListener('mousemove', handleMouseMove)
    document.addEventListener('mouseup', handleMouseUp)
    
    return () => {
      document.removeEventListener('mousemove', handleMouseMove)
      document.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, onResize, direction])
  
  return (
    <div
      onMouseDown={handleMouseDown}
      className={`
        flex-shrink-0 w-1.5 bg-gray-200 hover:bg-blue-400 cursor-col-resize
        transition-colors duration-150 relative group
        ${isDragging ? 'bg-blue-500' : ''}
      `}
    >
      {/* Visual indicator */}
      <div className={`
        absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
        w-1 h-8 rounded-full bg-gray-400 group-hover:bg-blue-500
        transition-colors duration-150
        ${isDragging ? 'bg-blue-600' : ''}
      `} />
    </div>
  )
}

// =============================================================================
// Main Layout Component
// =============================================================================

export function PlannerLayout({
  children,
  leftPanel,
  rightPanel,
  bottomBar,
  header
}: PlannerLayoutProps) {
  const breakpoint = useBreakpoint()
  const activeTab = usePlannerStore(state => state.activeTab)
  const setActiveTab = usePlannerStore(state => state.setActiveTab)
  
  const [leftOpen, setLeftOpen] = useState(true)
  const [rightOpen, setRightOpen] = useState(true)
  const [leftWidth, setLeftWidth] = useState(DEFAULT_PANEL_WIDTH)
  const [rightWidth, setRightWidth] = useState(DEFAULT_PANEL_WIDTH)
  
  const handleLeftResize = useCallback((delta: number) => {
    setLeftWidth(w => Math.max(MIN_PANEL_WIDTH, Math.min(MAX_PANEL_WIDTH, w + delta)))
  }, [])
  
  const handleRightResize = useCallback((delta: number) => {
    setRightWidth(w => Math.max(MIN_PANEL_WIDTH, Math.min(MAX_PANEL_WIDTH, w + delta)))
  }, [])
  
  // Mobile layout - viewer always visible with bottom sheet
  if (breakpoint === 'mobile') {
    return (
      <MobileLayout
        header={header}
        leftPanel={leftPanel}
        rightPanel={rightPanel}
        activeTab={activeTab}
        onTabChange={setActiveTab}
      >
        {children}
      </MobileLayout>
    )
  }
  
  // Tablet layout
  if (breakpoint === 'tablet') {
    return (
      <div className="h-screen flex flex-col bg-gray-100">
        {header && (
          <div className="flex-shrink-0 bg-white border-b">
            {header}
          </div>
        )}
        
        <div className="flex-1 flex overflow-hidden">
          {/* Collapsible left panel */}
          {leftPanel && (
            <div className={`
              flex-shrink-0 bg-white border-r transition-all duration-300 overflow-hidden
              ${leftOpen ? 'w-80' : 'w-0'}
            `}>
              <div className="w-80 h-full overflow-y-auto">
                {leftPanel}
              </div>
            </div>
          )}
          
          {/* Toggle button - 44px touch target */}
          {leftPanel && (
            <button
              onClick={() => setLeftOpen(!leftOpen)}
              className="flex-shrink-0 w-11 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center touch-manipulation"
              aria-label={leftOpen ? 'Collapse left panel' : 'Expand left panel'}
            >
              <svg className={`w-5 h-5 text-gray-600 transition-transform ${leftOpen ? '' : 'rotate-180'}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          
          {/* Main content */}
          <div className="flex-1 overflow-hidden">
            {children}
          </div>
          
          {/* Toggle button - 44px touch target */}
          {rightPanel && (
            <button
              onClick={() => setRightOpen(!rightOpen)}
              className="flex-shrink-0 w-11 bg-gray-100 hover:bg-gray-200 active:bg-gray-300 flex items-center justify-center touch-manipulation"
              aria-label={rightOpen ? 'Collapse right panel' : 'Expand right panel'}
            >
              <svg className={`w-5 h-5 text-gray-600 transition-transform ${rightOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          
          {/* Collapsible right panel */}
          {rightPanel && (
            <div className={`
              flex-shrink-0 bg-white border-l transition-all duration-300 overflow-hidden
              ${rightOpen ? 'w-80' : 'w-0'}
            `}>
              <div className="w-80 h-full overflow-y-auto">
                {rightPanel}
              </div>
            </div>
          )}
        </div>
        
        {bottomBar && (
          <div className="flex-shrink-0 bg-white border-t">
            {bottomBar}
          </div>
        )}
      </div>
    )
  }
  
  // Desktop layout with resizable panels
  return (
    <div className="h-screen flex flex-col bg-gray-100">
      {header && (
        <div className="flex-shrink-0 bg-white border-b">
          {header}
        </div>
      )}
      
      <div className="flex-1 flex overflow-hidden">
        {/* Left panel */}
        {leftPanel && (
          <>
            <div 
              className="flex-shrink-0 bg-white border-r overflow-y-auto"
              style={{ width: leftOpen ? leftWidth : 0 }}
            >
              <div style={{ width: leftWidth }} className="h-full">
                {leftPanel}
              </div>
            </div>
            {leftOpen && (
              <ResizeDivider onResize={handleLeftResize} direction="left" />
            )}
            {!leftOpen && (
              <button
                onClick={() => setLeftOpen(true)}
                className="flex-shrink-0 w-6 bg-gray-100 hover:bg-gray-200 flex items-center justify-center border-r"
                title="Show left panel"
              >
                <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </button>
            )}
          </>
        )}
        
        {/* Main content */}
        <div className="flex-1 overflow-hidden relative">
          {children}
          
          {/* Panel collapse buttons on main area - 44px touch targets */}
          {leftPanel && leftOpen && (
            <button
              onClick={() => setLeftOpen(false)}
              className="absolute top-2 left-2 z-20 w-11 h-11 bg-white/90 hover:bg-white active:bg-gray-100 rounded-lg shadow-md flex items-center justify-center touch-manipulation"
              title="Hide left panel"
              aria-label="Hide left panel"
            >
              <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
              </svg>
            </button>
          )}
          {rightPanel && rightOpen && (
            <button
              onClick={() => setRightOpen(false)}
              className="absolute top-2 right-2 z-20 w-11 h-11 bg-white/90 hover:bg-white active:bg-gray-100 rounded-lg shadow-md flex items-center justify-center touch-manipulation"
              title="Hide right panel"
              aria-label="Hide right panel"
            >
              <svg className="w-5 h-5 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
              </svg>
            </button>
          )}
        </div>
        
        {/* Right panel */}
        {rightPanel && (
          <>
            {!rightOpen && (
              <button
                onClick={() => setRightOpen(true)}
                className="flex-shrink-0 w-6 bg-gray-100 hover:bg-gray-200 flex items-center justify-center border-l"
                title="Show right panel"
              >
                <svg className="w-4 h-4 text-gray-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
                </svg>
              </button>
            )}
            {rightOpen && (
              <ResizeDivider onResize={handleRightResize} direction="right" />
            )}
            <div 
              className="flex-shrink-0 bg-white border-l overflow-y-auto"
              style={{ width: rightOpen ? rightWidth : 0 }}
            >
              <div style={{ width: rightWidth }} className="h-full">
                {rightPanel}
              </div>
            </div>
          </>
        )}
      </div>
      
      {bottomBar && (
        <div className="flex-shrink-0 bg-white border-t">
          {bottomBar}
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Mobile Layout with Bottom Sheet
// =============================================================================

interface MobileLayoutProps {
  children: React.ReactNode
  header?: React.ReactNode
  leftPanel?: React.ReactNode
  rightPanel?: React.ReactNode
  activeTab: PlannerTab
  onTabChange: (tab: PlannerTab) => void
}

// Bottom sheet height states
const SHEET_COLLAPSED = 120  // Just tabs + peek
const SHEET_HALF = 0.45      // 45% of screen
const SHEET_EXPANDED = 0.85  // 85% of screen

function MobileLayout({
  children,
  header,
  leftPanel,
  rightPanel,
  activeTab,
  onTabChange
}: MobileLayoutProps) {
  const [sheetHeight, setSheetHeight] = useState(SHEET_COLLAPSED)
  const [isDragging, setIsDragging] = useState(false)
  const dragStartY = useRef(0)
  const dragStartHeight = useRef(0)
  const containerRef = useRef<HTMLDivElement>(null)
  
  // Get the current panel content based on active tab
  const getPanelContent = () => {
    if (activeTab === 'room' || activeTab === 'fixtures') {
      return leftPanel
    }
    return rightPanel
  }
  
  // Calculate actual pixel height
  const getPixelHeight = useCallback(() => {
    if (typeof sheetHeight === 'number' && sheetHeight < 1) {
      // It's a percentage
      return typeof window !== 'undefined' ? window.innerHeight * sheetHeight : 400
    }
    return sheetHeight
  }, [sheetHeight])
  
  // Handle touch start on drag handle
  const handleTouchStart = useCallback((e: TouchEvent) => {
    setIsDragging(true)
    dragStartY.current = e.touches[0].clientY
    dragStartHeight.current = getPixelHeight()
  }, [getPixelHeight])
  
  // Handle touch move
  const handleTouchMove = useCallback((e: TouchEvent) => {
    if (!isDragging) return
    
    const deltaY = dragStartY.current - e.touches[0].clientY
    const newHeight = dragStartHeight.current + deltaY
    const maxHeight = typeof window !== 'undefined' ? window.innerHeight * SHEET_EXPANDED : 600
    const clampedHeight = Math.max(SHEET_COLLAPSED, Math.min(maxHeight, newHeight))
    
    setSheetHeight(clampedHeight)
  }, [isDragging])
  
  // Handle touch end - snap to nearest position
  const handleTouchEnd = useCallback(() => {
    if (!isDragging) return
    setIsDragging(false)
    
    const currentHeight = getPixelHeight()
    const windowHeight = typeof window !== 'undefined' ? window.innerHeight : 800
    const halfHeight = windowHeight * SHEET_HALF
    const expandedHeight = windowHeight * SHEET_EXPANDED
    
    // Snap to nearest position
    if (currentHeight < (SHEET_COLLAPSED + halfHeight) / 2) {
      setSheetHeight(SHEET_COLLAPSED)
    } else if (currentHeight < (halfHeight + expandedHeight) / 2) {
      setSheetHeight(SHEET_HALF)
    } else {
      setSheetHeight(SHEET_EXPANDED)
    }
  }, [isDragging, getPixelHeight])
  
  // Expand sheet when tab is tapped
  const handleTabChange = useCallback((tab: PlannerTab) => {
    onTabChange(tab)
    // If collapsed and user taps a tab, expand to half
    if (sheetHeight === SHEET_COLLAPSED) {
      setSheetHeight(SHEET_HALF)
    }
  }, [onTabChange, sheetHeight])
  
  // Toggle sheet expansion on handle double-tap
  const handleHandleTap = useCallback(() => {
    const windowHeight = typeof window !== 'undefined' ? window.innerHeight : 800
    const halfHeight = windowHeight * SHEET_HALF
    const currentHeight = getPixelHeight()
    
    if (currentHeight < halfHeight / 2) {
      setSheetHeight(SHEET_HALF)
    } else {
      setSheetHeight(SHEET_COLLAPSED)
    }
  }, [getPixelHeight])
  
  const pixelHeight = getPixelHeight()
  
  return (
    <div ref={containerRef} className="h-screen flex flex-col bg-gray-100 overflow-hidden">
      {/* Header */}
      {header && (
        <div className="flex-shrink-0 bg-white border-b">
          {header}
        </div>
      )}
      
      {/* Main viewer area - always visible */}
      <div className="flex-1 overflow-hidden relative">
        {children}
        
        {/* Quick results overlay at top of viewer */}
        <div className="absolute top-2 left-2 right-2 z-10">
          <MobileQuickResults />
        </div>
      </div>
      
      {/* Bottom Sheet */}
      <div
        className={`
          flex-shrink-0 bg-white rounded-t-2xl shadow-lg
          ${isDragging ? '' : 'transition-all duration-300 ease-out'}
        `}
        style={{ height: pixelHeight }}
      >
        {/* Drag Handle */}
        <div
          className="flex flex-col items-center pt-3 pb-2 cursor-grab active:cursor-grabbing touch-none"
          onTouchStart={handleTouchStart}
          onTouchMove={handleTouchMove}
          onTouchEnd={handleTouchEnd}
          onClick={handleHandleTap}
        >
          <div className="w-10 h-1.5 bg-gray-300 rounded-full" />
        </div>
        
        {/* Tab bar in sheet */}
        <MobileSheetTabs activeTab={activeTab} onTabChange={handleTabChange} />
        
        {/* Panel content */}
        <div className="flex-1 overflow-y-auto" style={{ height: pixelHeight - 100 }}>
          {getPanelContent()}
        </div>
      </div>
    </div>
  )
}

// =============================================================================
// Mobile Quick Results (Floating overlay)
// =============================================================================

function MobileQuickResults() {
  const results = usePlannerStore(state => state.results)
  
  if (!results) return null
  
  const { Eavg, Uo } = results
  
  return (
    <div className="bg-white/95 backdrop-blur-sm rounded-lg shadow-md px-3 py-2 flex items-center gap-4 text-sm">
      <div className="flex items-center gap-1.5">
        <span className="text-gray-500">Avg:</span>
        <span className="font-semibold text-gray-900">{Math.round(Eavg)} lux</span>
      </div>
      <div className="w-px h-4 bg-gray-300" />
      <div className="flex items-center gap-1.5">
        <span className="text-gray-500">U&#x2080;:</span>
        <span className={`font-semibold ${Uo >= 0.4 ? 'text-green-600' : Uo >= 0.3 ? 'text-yellow-600' : 'text-red-600'}`}>
          {Uo.toFixed(2)}
        </span>
      </div>
    </div>
  )
}

// =============================================================================
// Mobile Sheet Tabs (Inside bottom sheet)
// =============================================================================

interface MobileSheetTabsProps {
  activeTab: PlannerTab
  onTabChange: (tab: PlannerTab) => void
}

function MobileSheetTabs({ activeTab, onTabChange }: MobileSheetTabsProps) {
  const tabs: { id: PlannerTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'room',
      label: 'Room',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
        </svg>
      )
    },
    {
      id: 'fixtures',
      label: 'Lights',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      )
    },
    {
      id: 'results',
      label: 'Results',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      )
    },
    {
      id: 'export',
      label: 'Export',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      )
    }
  ]
  
  return (
    <div className="flex border-b">
      {tabs.map(tab => (
        <button
          key={tab.id}
          onClick={() => onTabChange(tab.id)}
          className={`
            flex-1 flex flex-col items-center py-3 px-2 min-h-[56px]
            transition-colors
            ${activeTab === tab.id 
              ? 'text-blue-600 border-b-2 border-blue-600 bg-blue-50/50' 
              : 'text-gray-500 hover:text-gray-700 hover:bg-gray-50'
            }
          `}
        >
          {tab.icon}
          <span className="text-xs mt-1 font-medium">{tab.label}</span>
        </button>
      ))}
    </div>
  )
}

// =============================================================================
// Mobile Tab Bar (Legacy - kept for reference but no longer used)
// =============================================================================

interface MobileTabBarProps {
  activeTab: PlannerTab
  onTabChange: (tab: PlannerTab) => void
}

function MobileTabBar({ activeTab, onTabChange }: MobileTabBarProps) {
  const tabs: { id: PlannerTab; label: string; icon: React.ReactNode }[] = [
    {
      id: 'room',
      label: 'Room',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 5a1 1 0 011-1h14a1 1 0 011 1v2a1 1 0 01-1 1H5a1 1 0 01-1-1V5zM4 13a1 1 0 011-1h6a1 1 0 011 1v6a1 1 0 01-1 1H5a1 1 0 01-1-1v-6zM16 13a1 1 0 011-1h2a1 1 0 011 1v6a1 1 0 01-1 1h-2a1 1 0 01-1-1v-6z" />
        </svg>
      )
    },
    {
      id: 'fixtures',
      label: 'Fixtures',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
        </svg>
      )
    },
    {
      id: 'results',
      label: 'Results',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z" />
        </svg>
      )
    },
    {
      id: 'export',
      label: 'Export',
      icon: (
        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
        </svg>
      )
    }
  ]
  
  return (
    <div className="bg-white border-t safe-area-pb">
      <div className="flex">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => onTabChange(tab.id)}
            className={`
              flex-1 flex flex-col items-center py-2 px-1
              ${activeTab === tab.id 
                ? 'text-blue-600' 
                : 'text-gray-600 hover:text-gray-700'
              }
            `}
          >
            {tab.icon}
            <span className="text-xs mt-1">{tab.label}</span>
          </button>
        ))}
      </div>
    </div>
  )
}

// =============================================================================
// Panel Components
// =============================================================================

interface PanelProps {
  title: string
  children: React.ReactNode
  className?: string
  actions?: React.ReactNode
}

export function Panel({ title, children, className = '', actions }: PanelProps) {
  return (
    <div className={`flex flex-col h-full ${className}`}>
      <div className="flex items-center justify-between p-4 border-b">
        <h2 className="font-semibold text-gray-900">{title}</h2>
        {actions}
      </div>
      <div className="flex-1 overflow-y-auto p-4">
        {children}
      </div>
    </div>
  )
}

export function PanelSection({ 
  title, 
  children, 
  className = '',
  collapsible = false,
  defaultOpen = true
}: {
  title: string
  children: React.ReactNode
  className?: string
  collapsible?: boolean
  defaultOpen?: boolean
}) {
  const [isOpen, setIsOpen] = useState(defaultOpen)
  
  return (
    <div className={`border-b last:border-b-0 ${className}`}>
      <button
        onClick={() => collapsible && setIsOpen(!isOpen)}
        className={`
          w-full flex items-center justify-between py-3 text-left
          ${collapsible ? 'cursor-pointer hover:bg-gray-50' : 'cursor-default'}
        `}
        disabled={!collapsible}
      >
        <h3 className="text-sm font-medium text-gray-700">{title}</h3>
        {collapsible && (
          <svg 
            className={`w-4 h-4 text-gray-500 transition-transform ${isOpen ? '' : '-rotate-90'}`}
            fill="none" 
            stroke="currentColor" 
            viewBox="0 0 24 24"
          >
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        )}
      </button>
      {(!collapsible || isOpen) && (
        <div className="pb-4">
          {children}
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Display Options Toggle
// =============================================================================

export function DisplayOptionsBar({ className = '' }: { className?: string }) {
  const displayOptions = usePlannerStore(state => state.displayOptions)
  const toggleDisplayOption = usePlannerStore(state => state.toggleDisplayOption)
  
  const options = [
    { key: 'showHeatmap' as const, label: 'Heatmap' },
    { key: 'showIsolines' as const, label: 'Isolines' },
    { key: 'showValues' as const, label: 'Values' },
    { key: 'showFixtures' as const, label: 'Fixtures' },
    { key: 'showGrid' as const, label: 'Grid' }
  ]
  
  return (
    <div className={`flex items-center gap-1 ${className}`}>
      {options.map(opt => (
        <button
          key={opt.key}
          onClick={() => toggleDisplayOption(opt.key)}
          className={`
            px-2 py-1 text-xs rounded transition-colors
            ${displayOptions[opt.key]
              ? 'bg-blue-100 text-blue-700'
              : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
            }
          `}
        >
          {opt.label}
        </button>
      ))}
    </div>
  )
}

// =============================================================================
// Export
// =============================================================================

export default PlannerLayout
