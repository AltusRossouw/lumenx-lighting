/**
 * OrbitX Lighting Planner - Activity Type Selector
 * 
 * Dropdown for selecting room activity type from EN 12464-1 presets.
 * Updates the required illuminance, uniformity, and UGR targets.
 */

'use client'

import React, { useState, useMemo } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { ACTIVITY_PRESETS, getActivityById, getActivitiesByCategory } from '../../lib/photometry/Standards'
import type { ActivityRequirements } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface ActivitySelectorProps {
  className?: string
  compact?: boolean
}

// =============================================================================
// Main Component
// =============================================================================

export function ActivitySelector({ className = '', compact = false }: ActivitySelectorProps) {
  const activityType = usePlannerStore(state => state.activityType)
  const setActivityType = usePlannerStore(state => state.setActivityType)
  
  const [isOpen, setIsOpen] = useState(false)
  const [search, setSearch] = useState('')
  
  const currentActivity = useMemo(() => getActivityById(activityType), [activityType])
  
  const categories = useMemo(() => {
    const cats = new Set<string>()
    ACTIVITY_PRESETS.forEach(a => cats.add(a.category))
    return Array.from(cats).sort()
  }, [])
  
  const filteredActivities = useMemo(() => {
    if (!search) return ACTIVITY_PRESETS
    const searchLower = search.toLowerCase()
    return ACTIVITY_PRESETS.filter(a => 
      a.name.toLowerCase().includes(searchLower) ||
      a.category.toLowerCase().includes(searchLower)
    )
  }, [search])
  
  if (compact) {
    return (
      <div className={`relative ${className}`}>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between gap-2 px-3 py-2 bg-white border rounded-lg hover:border-gray-400 transition-colors"
        >
          <div className="flex items-center gap-2 min-w-0">
            <span className="text-lg">{getCategoryIcon(currentActivity?.category || '')}</span>
            <span className="truncate text-sm">
              {currentActivity?.name || 'Select Activity'}
            </span>
          </div>
          <svg className={`w-4 h-4 text-gray-400 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        {isOpen && (
          <ActivityDropdown
            activities={filteredActivities}
            categories={categories}
            search={search}
            onSearchChange={setSearch}
            onSelect={(id) => {
              setActivityType(id)
              setIsOpen(false)
              setSearch('')
            }}
            onClose={() => {
              setIsOpen(false)
              setSearch('')
            }}
          />
        )}
      </div>
    )
  }
  
  return (
    <div className={`space-y-3 ${className}`}>
      {/* Header */}
      <div className="flex items-center justify-between">
        <label className="text-sm font-medium text-gray-700">Activity Type</label>
        <span className="text-xs text-gray-600">EN 12464-1</span>
      </div>
      
      {/* Selector button */}
      <div className="relative">
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-full flex items-center justify-between gap-3 p-3 bg-white border rounded-lg hover:border-gray-400 transition-colors text-left"
        >
          <div className="flex items-center gap-3 min-w-0">
            <span className="text-2xl">{getCategoryIcon(currentActivity?.category || '')}</span>
            <div className="min-w-0">
              <div className="font-medium truncate">
                {currentActivity?.name || 'Select Activity Type'}
              </div>
              <div className="text-xs text-gray-600">
                {currentActivity?.category || 'Choose from EN 12464-1 presets'}
              </div>
            </div>
          </div>
          <svg className={`w-5 h-5 text-gray-400 flex-shrink-0 transition-transform ${isOpen ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
          </svg>
        </button>
        
        {isOpen && (
          <ActivityDropdown
            activities={filteredActivities}
            categories={categories}
            search={search}
            onSearchChange={setSearch}
            onSelect={(id) => {
              setActivityType(id)
              setIsOpen(false)
              setSearch('')
            }}
            onClose={() => {
              setIsOpen(false)
              setSearch('')
            }}
          />
        )}
      </div>
      
      {/* Current requirements display */}
      {currentActivity && (
        <div className="grid grid-cols-3 gap-2 text-center">
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-lg font-semibold text-gray-900">{currentActivity.Eavg}</div>
            <div className="text-xs text-gray-600">lux min</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-lg font-semibold text-gray-900">{currentActivity.Uo}</div>
            <div className="text-xs text-gray-600">Uo min</div>
          </div>
          <div className="bg-gray-50 rounded-lg p-2">
            <div className="text-lg font-semibold text-gray-900">&le;{currentActivity.UGR}</div>
            <div className="text-xs text-gray-600">UGR max</div>
          </div>
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Dropdown Component
// =============================================================================

interface ActivityDropdownProps {
  activities: ActivityRequirements[]
  categories: string[]
  search: string
  onSearchChange: (value: string) => void
  onSelect: (id: string) => void
  onClose: () => void
}

function ActivityDropdown({
  activities,
  categories,
  search,
  onSearchChange,
  onSelect,
  onClose
}: ActivityDropdownProps) {
  // Group activities by category
  const grouped = useMemo(() => {
    const result: Record<string, ActivityRequirements[]> = {}
    for (const cat of categories) {
      result[cat] = activities.filter(a => a.category === cat)
    }
    return result
  }, [activities, categories])
  
  return (
    <>
      {/* Backdrop */}
      <div 
        className="fixed inset-0 z-40" 
        onClick={onClose}
      />
      
      {/* Dropdown */}
      <div className="absolute top-full left-0 right-0 mt-1 bg-white border rounded-lg shadow-xl z-50 max-h-80 overflow-hidden flex flex-col">
        {/* Search */}
        <div className="p-2 border-b">
          <input
            type="text"
            placeholder="Search activities..."
            value={search}
            onChange={(e) => onSearchChange(e.target.value)}
            className="w-full px-3 py-2 text-sm border rounded-lg"
            autoFocus
          />
        </div>
        
        {/* List */}
        <div className="flex-1 overflow-y-auto">
          {activities.length === 0 ? (
            <div className="p-4 text-center text-gray-600 text-sm">
              No matching activities
            </div>
          ) : search ? (
            // Flat list when searching
            <div className="p-2 space-y-1">
              {activities.map(activity => (
                <ActivityItem
                  key={activity.id}
                  activity={activity}
                  onSelect={() => onSelect(activity.id)}
                />
              ))}
            </div>
          ) : (
            // Grouped by category
            <div className="p-2 space-y-3">
              {categories.map(category => {
                const categoryActivities = grouped[category]
                if (!categoryActivities?.length) return null
                
                return (
                  <div key={category}>
                    <div className="flex items-center gap-2 px-2 py-1 text-xs font-semibold text-gray-600 uppercase">
                      <span>{getCategoryIcon(category)}</span>
                      <span>{category}</span>
                    </div>
                    <div className="space-y-1">
                      {categoryActivities.map(activity => (
                        <ActivityItem
                          key={activity.id}
                          activity={activity}
                          onSelect={() => onSelect(activity.id)}
                        />
                      ))}
                    </div>
                  </div>
                )
              })}
            </div>
          )}
        </div>
      </div>
    </>
  )
}

// =============================================================================
// Activity Item
// =============================================================================

interface ActivityItemProps {
  activity: ActivityRequirements
  onSelect: () => void
}

function ActivityItem({ activity, onSelect }: ActivityItemProps) {
  return (
    <button
      onClick={onSelect}
      className="w-full flex items-center justify-between p-2 text-left hover:bg-blue-50 rounded-lg transition-colors group"
    >
      <span className="text-sm truncate">{activity.name}</span>
      <span className="text-xs text-gray-500 group-hover:text-blue-500 flex-shrink-0 ml-2">
        {activity.Eavg} lux
      </span>
    </button>
  )
}

// =============================================================================
// Helper Functions
// =============================================================================

function getCategoryIcon(category: string): string {
  const icons: Record<string, string> = {
    'Office': '🏢',
    'Education': '🎓',
    'Healthcare': '🏥',
    'Retail': '🛒',
    'Industrial': '🏭',
    'Hospitality': '🏨',
    'Sports': '⚽',
    'Transport': '🚗',
    'Residential': '🏠',
    'Outdoor': '🌳'
  }
  return icons[category] || '💡'
}

// =============================================================================
// Export
// =============================================================================

export default ActivitySelector
