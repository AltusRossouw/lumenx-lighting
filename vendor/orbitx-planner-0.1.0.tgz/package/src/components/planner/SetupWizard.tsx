/**
 * OrbitX Lighting Planner - Setup Wizard
 * 
 * Guided 3-step wizard for new users to quickly set up a lighting project.
 * Always shown on first visit, can be skipped or dismissed.
 * 
 * Steps:
 * 1. Choose room preset or enter dimensions
 * 2. Select activity type
 * 3. Add luminaires (with smart recommendation)
 */

'use client'

import React, { useState, useCallback, useMemo, useEffect } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { ROOM_PRESETS, getPresetsByCategory, type RoomPreset } from '../../data/roomPresets'
import { ACTIVITY_PRESETS, getActivityById } from '../../lib/photometry/Standards'
import { calculateRecommendedLayout, type LayoutRecommendation } from '../../lib/photometry/Recommendations'
import { fetchAndParseIES } from '../../lib/photometry/IESParser'
import type { ActivityRequirements } from '../../lib/photometry/types'

// =============================================================================
// Types
// =============================================================================

interface SetupWizardProps {
  onComplete: () => void
  onSkip: () => void
}

type WizardStep = 'room' | 'activity' | 'luminaires'

interface RoomDimensions {
  width: number
  length: number
  height: number
  workPlaneHeight: number
}

// =============================================================================
// Main Component
// =============================================================================

export function SetupWizard({ onComplete, onSkip }: SetupWizardProps) {
  const [step, setStep] = useState<WizardStep>('room')
  const [selectedPreset, setSelectedPreset] = useState<string | null>(null)
  const [customDimensions, setCustomDimensions] = useState(false)
  
  const room = usePlannerStore(state => state.room)
  const setRoom = usePlannerStore(state => state.setRoom)
  const activityType = usePlannerStore(state => state.activityType)
  const setActivityType = usePlannerStore(state => state.setActivityType)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const applyRecommendedLayout = usePlannerStore(state => state.applyRecommendedLayout)

  const [recommendation, setRecommendation] = useState<LayoutRecommendation | null>(null)
  const [recommending, setRecommending] = useState(false)

  // Get current activity requirements
  const currentActivity = useMemo(() => getActivityById(activityType), [activityType])

  // Compute the real optimized recommendation (loads the first profile's IES).
  useEffect(() => {
    let cancelled = false
    async function compute() {
      if (!currentActivity || iesProfiles.length === 0) {
        setRecommendation(null)
        return
      }
      setRecommending(true)
      try {
        const iesData = await fetchAndParseIES(iesProfiles[0].url)
        if (cancelled) return
        setRecommendation(calculateRecommendedLayout({ room, targetLux: currentActivity.Eavg, iesData }))
      } catch (err) {
        console.error('Recommendation failed:', err)
        if (!cancelled) setRecommendation(null)
      } finally {
        if (!cancelled) setRecommending(false)
      }
    }
    compute()
    return () => { cancelled = true }
  }, [room, currentActivity, iesProfiles])

  // Apply preset
  const applyPreset = useCallback((preset: RoomPreset) => {
    setRoom({
      width: preset.width,
      length: preset.length,
      height: preset.height,
      workPlaneHeight: preset.workPlaneHeight,
      ceilingReflectance: preset.ceilingReflectance,
      wallReflectance: preset.wallReflectance,
      floorReflectance: preset.floorReflectance,
      name: preset.name
    })
    setActivityType(preset.activityType)
    setSelectedPreset(preset.id)
    setCustomDimensions(false)
  }, [setRoom, setActivityType])

  // Apply recommended layout
  const applyRecommendation = useCallback(() => {
    if (!recommendation || iesProfiles.length === 0) return

    applyRecommendedLayout(iesProfiles[0].id, {
      rows: recommendation.rows,
      cols: recommendation.cols,
      spacing: recommendation.spacing,
      dimming: recommendation.dimming,
      mountingHeight: room.height - 0.1,
    })
    onComplete()
  }, [recommendation, iesProfiles, room.height, applyRecommendedLayout, onComplete])
  
  // Navigation
  const goNext = useCallback(() => {
    if (step === 'room') setStep('activity')
    else if (step === 'activity') setStep('luminaires')
    else onComplete()
  }, [step, onComplete])
  
  const goBack = useCallback(() => {
    if (step === 'activity') setStep('room')
    else if (step === 'luminaires') setStep('activity')
  }, [step])
  
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm">
      <div className="bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 overflow-hidden">
        {/* Header */}
        <div className="px-6 py-4 bg-gradient-to-r from-blue-600 to-blue-700 text-white">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-xl font-bold">Lighting Planner Setup</h2>
              <p className="text-blue-100 text-sm mt-1">
                {step === 'room' && 'Step 1: Choose your room'}
                {step === 'activity' && 'Step 2: Select activity type'}
                {step === 'luminaires' && 'Step 3: Add lights'}
              </p>
            </div>
            <button
              onClick={onSkip}
              className="text-blue-200 hover:text-white transition-colors text-sm"
            >
              Skip wizard
            </button>
          </div>
          
          {/* Progress dots */}
          <div className="flex gap-2 mt-4">
            {(['room', 'activity', 'luminaires'] as WizardStep[]).map((s, i) => (
              <div
                key={s}
                className={`h-1.5 flex-1 rounded-full transition-colors ${
                  s === step ? 'bg-white' :
                  (['room', 'activity', 'luminaires'].indexOf(s) < ['room', 'activity', 'luminaires'].indexOf(step))
                    ? 'bg-blue-400' 
                    : 'bg-blue-800'
                }`}
              />
            ))}
          </div>
        </div>
        
        {/* Content */}
        <div className="p-6 max-h-[60vh] overflow-y-auto">
          {step === 'room' && (
            <RoomStep
              selectedPreset={selectedPreset}
              customDimensions={customDimensions}
              room={room}
              setRoom={setRoom}
              onSelectPreset={applyPreset}
              onCustomToggle={() => {
                setCustomDimensions(true)
                setSelectedPreset(null)
              }}
            />
          )}
          
          {step === 'activity' && (
            <ActivityStep
              activityType={activityType}
              onSelect={setActivityType}
            />
          )}
          
          {step === 'luminaires' && (
            <LuminaireStep
              recommendation={recommendation}
              recommending={recommending}
              room={room}
              activity={currentActivity}
              onApplyRecommendation={applyRecommendation}
            />
          )}
        </div>
        
        {/* Footer */}
        <div className="px-6 py-4 bg-gray-50 border-t flex justify-between">
          <button
            onClick={step === 'room' ? onSkip : goBack}
            className="px-4 py-2 text-gray-600 hover:text-gray-900 transition-colors"
          >
            {step === 'room' ? 'Skip' : 'Back'}
          </button>
          
          <button
            onClick={step === 'luminaires' ? applyRecommendation : goNext}
            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors flex items-center gap-2"
          >
            {step === 'luminaires' ? (
              <>
                Apply & Start
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M5 13l4 4L19 7" />
                </svg>
              </>
            ) : (
              <>
                Continue
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 5l7 7-7 7" />
                </svg>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  )
}

// =============================================================================
// Step 1: Room Selection
// =============================================================================

interface RoomStepProps {
  selectedPreset: string | null
  customDimensions: boolean
  room: RoomDimensions
  setRoom: (updates: Partial<RoomDimensions>) => void
  onSelectPreset: (preset: RoomPreset) => void
  onCustomToggle: () => void
}

function RoomStep({ selectedPreset, customDimensions, room, setRoom, onSelectPreset, onCustomToggle }: RoomStepProps) {
  const categories = getPresetsByCategory()
  
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Choose a Room Type</h3>
        <p className="text-gray-600 text-sm">
          Select a preset that matches your space, or enter custom dimensions.
        </p>
      </div>
      
      {/* Preset grid */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
        {ROOM_PRESETS.slice(0, 8).map(preset => (
          <button
            key={preset.id}
            onClick={() => onSelectPreset(preset)}
            className={`p-4 rounded-xl border-2 text-left transition-all hover:shadow-md ${
              selectedPreset === preset.id
                ? 'border-blue-500 bg-blue-50'
                : 'border-gray-200 hover:border-gray-300'
            }`}
          >
            <div className="text-2xl mb-2">{getPresetIcon(preset.id)}</div>
            <div className="font-medium text-gray-900 text-sm">{preset.name}</div>
            <div className="text-xs text-gray-500 mt-1">
              {preset.width}m x {preset.length}m
            </div>
          </button>
        ))}
      </div>
      
      {/* Custom dimensions toggle */}
      <div className="border-t pt-4">
        <button
          onClick={onCustomToggle}
          className={`w-full p-4 rounded-xl border-2 text-left transition-all ${
            customDimensions
              ? 'border-blue-500 bg-blue-50'
              : 'border-gray-200 hover:border-gray-300'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className="text-2xl">📐</div>
            <div>
              <div className="font-medium text-gray-900">Custom Dimensions</div>
              <div className="text-sm text-gray-500">Enter your own room size</div>
            </div>
          </div>
        </button>
        
        {customDimensions && (
          <div className="mt-4 grid grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Width (m)</label>
              <input
                type="number"
                step="0.5"
                min="1"
                max="100"
                value={room.width}
                onChange={(e) => setRoom({ width: parseFloat(e.target.value) || 1 })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Length (m)</label>
              <input
                type="number"
                step="0.5"
                min="1"
                max="100"
                value={room.length}
                onChange={(e) => setRoom({ length: parseFloat(e.target.value) || 1 })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">Height (m)</label>
              <input
                type="number"
                step="0.1"
                min="2"
                max="20"
                value={room.height}
                onChange={(e) => setRoom({ height: parseFloat(e.target.value) || 2.5 })}
                className="w-full px-3 py-2 border rounded-lg"
              />
            </div>
          </div>
        )}
      </div>
      
      {/* Current selection summary */}
      <div className="bg-gray-50 rounded-lg p-4">
        <div className="text-sm text-gray-600">
          Selected room: <span className="font-medium text-gray-900">
            {room.width}m x {room.length}m x {room.height}m
          </span>
          <span className="text-gray-400 ml-2">
            ({(room.width * room.length).toFixed(1)} m² floor area)
          </span>
        </div>
      </div>
    </div>
  )
}

// =============================================================================
// Step 2: Activity Selection
// =============================================================================

interface ActivityStepProps {
  activityType: string
  onSelect: (id: string) => void
}

function ActivityStep({ activityType, onSelect }: ActivityStepProps) {
  const [searchQuery, setSearchQuery] = useState('')
  
  const filteredActivities = useMemo(() => {
    if (!searchQuery) return ACTIVITY_PRESETS.slice(0, 12) // Show first 12
    const query = searchQuery.toLowerCase()
    return ACTIVITY_PRESETS.filter(a => 
      a.name.toLowerCase().includes(query) ||
      a.category.toLowerCase().includes(query)
    ).slice(0, 12)
  }, [searchQuery])
  
  const currentActivity = getActivityById(activityType)
  
  // Common activity shortcuts
  const commonActivities = useMemo(() => {
    return ACTIVITY_PRESETS.filter(a => 
      ['office-general', 'warehouse-active', 'retail-general', 'classroom', 'corridor'].includes(a.id)
    )
  }, [])
  
  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">What will this space be used for?</h3>
        <p className="text-gray-600 text-sm">
          This determines the lighting requirements (EN 12464-1 standard).
        </p>
      </div>
      
      {/* Quick picks */}
      <div>
        <div className="text-sm font-medium text-gray-700 mb-2">Common activities:</div>
        <div className="flex flex-wrap gap-2">
          {commonActivities.map(activity => (
            <button
              key={activity.id}
              onClick={() => onSelect(activity.id)}
              className={`px-4 py-2 rounded-lg text-sm transition-all ${
                activityType === activity.id
                  ? 'bg-blue-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              {activity.name}
            </button>
          ))}
        </div>
      </div>
      
      {/* Search */}
      <div>
        <div className="text-sm font-medium text-gray-700 mb-2">Or search all activities:</div>
        <input
          type="text"
          placeholder="Search activities..."
          value={searchQuery}
          onChange={(e) => setSearchQuery(e.target.value)}
          className="w-full px-4 py-2 border rounded-lg"
        />
        
        {searchQuery && (
          <div className="mt-3 max-h-48 overflow-y-auto border rounded-lg divide-y">
            {filteredActivities.map(activity => (
              <button
                key={activity.id}
                onClick={() => {
                  onSelect(activity.id)
                  setSearchQuery('')
                }}
                className={`w-full px-4 py-3 text-left hover:bg-blue-50 transition-colors flex justify-between items-center ${
                  activityType === activity.id ? 'bg-blue-50' : ''
                }`}
              >
                <div>
                  <div className="font-medium text-gray-900">{activity.name}</div>
                  <div className="text-xs text-gray-500">{activity.category}</div>
                </div>
                <div className="text-sm text-gray-500">{activity.Eavg} lux</div>
              </button>
            ))}
          </div>
        )}
      </div>
      
      {/* Current selection */}
      {currentActivity && (
        <div className="bg-blue-50 rounded-xl p-4 border border-blue-200">
          <div className="flex items-start justify-between">
            <div>
              <div className="font-semibold text-gray-900">{currentActivity.name}</div>
              <div className="text-sm text-gray-600">{currentActivity.category}</div>
            </div>
            <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
              EN 12464-1
            </span>
          </div>
          
          <div className="grid grid-cols-3 gap-4 mt-4">
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{currentActivity.Eavg}</div>
              <div className="text-xs text-gray-500">lux required</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">{currentActivity.Uo}</div>
              <div className="text-xs text-gray-500">min uniformity</div>
            </div>
            <div className="text-center">
              <div className="text-2xl font-bold text-blue-600">&le;{currentActivity.UGR}</div>
              <div className="text-xs text-gray-500">max glare</div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// =============================================================================
// Step 3: Luminaire Recommendation
// =============================================================================

interface LuminaireStepProps {
  recommendation: LayoutRecommendation | null
  recommending: boolean
  room: { width: number; length: number; height: number }
  activity: ActivityRequirements | undefined
  onApplyRecommendation: () => void
}

function LuminaireStep({ recommendation, recommending, room, activity, onApplyRecommendation }: LuminaireStepProps) {
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const firstProfile = iesProfiles[0]

  if (!activity) {
    return (
      <div className="text-center py-8">
        <div className="text-gray-500">
          <svg className="w-12 h-12 mx-auto mb-4 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
          </svg>
          <p>Please complete the previous steps first.</p>
        </div>
      </div>
    )
  }

  if (recommending || !recommendation) {
    return (
      <div className="text-center py-8">
        <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
        <p className="text-gray-600">Calculating optimal layout…</p>
      </div>
    )
  }

  const { total, rows, cols, dimming, predictedEavg, predictedUo, summary, notes } = recommendation

  return (
    <div className="space-y-6">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-2">Recommended Lighting Layout</h3>
        <p className="text-gray-600 text-sm">
          Optimized for your room and activity, dimmed to hit the target illuminance.
        </p>
      </div>

      {/* Recommendation card */}
      <div className="bg-gradient-to-br from-green-50 to-emerald-50 rounded-xl p-6 border border-green-200">
        <div className="flex items-start gap-4">
          <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
            <svg className="w-6 h-6 text-green-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9.663 17h4.673M12 3v1m6.364 1.636l-.707.707M21 12h-1M4 12H3m3.343-5.657l-.707-.707m2.828 9.9a5 5 0 117.072 0l-.548.547A3.374 3.374 0 0014 18.469V19a2 2 0 11-4 0v-.531c0-.895-.356-1.754-.988-2.386l-.548-.547z" />
            </svg>
          </div>

          <div className="flex-1">
            <div className="text-2xl font-bold text-gray-900">
              {total} luminaires
            </div>
            <div className="text-gray-600 mt-1">
              {rows} rows x {cols} columns
            </div>

            {firstProfile && (
              <div className="mt-3 text-sm text-gray-500">
                Using: {firstProfile.productName}
                {firstProfile.lumens && ` (${firstProfile.lumens} lm)`}
              </div>
            )}

            {dimming < 1 && (
              <div className="mt-2 text-xs font-medium text-emerald-700">
                Dimmed to {Math.round(dimming * 100)}% to hit target
              </div>
            )}
          </div>

          <div className="text-right">
            <div className="text-3xl font-bold text-green-600">{Math.round(predictedEavg)}</div>
            <div className="text-sm text-gray-500">predicted lux</div>
            <div className="text-xs text-gray-400 mt-1">
              Target: {activity.Eavg} lux
            </div>
            <div className="text-xs text-gray-400 mt-1">
              Uo: {predictedUo.toFixed(2)}
            </div>
          </div>
        </div>

        {/* Visual layout preview */}
        <div className="mt-6 p-4 bg-white rounded-lg border">
          <div className="text-xs text-gray-500 mb-2 text-center">Layout preview</div>
          <div
            className="mx-auto border-2 border-gray-300 rounded relative"
            style={{
              width: Math.min(200, room.width * 20),
              height: Math.min(150, room.length * 15),
              aspectRatio: `${room.width} / ${room.length}`
            }}
          >
            {Array.from({ length: rows }).map((_, rowIdx) => (
              Array.from({ length: cols }).map((_, colIdx) => (
                <div
                  key={`${rowIdx}-${colIdx}`}
                  className="absolute w-3 h-3 bg-yellow-400 rounded-full shadow-sm"
                  style={{
                    left: `${((colIdx + 0.5) / cols) * 100}%`,
                    top: `${((rowIdx + 0.5) / rows) * 100}%`,
                    transform: 'translate(-50%, -50%)'
                  }}
                />
              ))
            ))}
          </div>
        </div>

        {/* Summary */}
        <div className="mt-4 text-sm text-gray-700 bg-white/50 rounded-lg p-3">
          {summary}
        </div>

        {notes.length > 0 && (
          <ul className="mt-2 text-xs text-gray-600 space-y-1">
            {notes.map((n, i) => <li key={i}>• {n}</li>)}
          </ul>
        )}
      </div>

      {/* Alternative options */}
      <div className="text-sm text-gray-500 text-center">
        You can adjust the layout manually after setup.
      </div>
    </div>
  )
}

// =============================================================================
// Helper Functions
// =============================================================================

function getPresetIcon(id: string): string {
  const icons: Record<string, string> = {
    'small-office': '🏢',
    'open-plan': '🗄️',
    'warehouse': '🏭',
    'corridor': '🚶',
    'classroom': '🎓',
    'retail': '🛒',
    'workshop': '🔧',
    'parking': '🚗'
  }
  return icons[id] || '💡'
}

// =============================================================================
// Export
// =============================================================================

export default SetupWizard
