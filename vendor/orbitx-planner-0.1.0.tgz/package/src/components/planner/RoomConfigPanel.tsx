/**
 * OrbitX Lighting Planner - Room Config Panel
 * 
 * UI panel for configuring room dimensions and surface properties.
 * Includes room presets, maintenance factor, and inter-reflection settings.
 */

'use client'

import React, { useState } from 'react'
import { usePlannerStore } from '../../stores/plannerStore'
import { ROOM_PRESETS, getPresetsByCategory, type RoomPreset } from '../../data/roomPresets'
import {
  MAINTENANCE_PRESETS,
  DEFAULT_MAINTENANCE_FACTORS,
  calculateMaintenanceFactor,
} from '../../lib/photometry/Maintenance'

// =============================================================================
// Types
// =============================================================================

interface RoomConfigPanelProps {
  className?: string
}

// =============================================================================
// Main Component
// =============================================================================

export function RoomConfigPanel({ className = '' }: RoomConfigPanelProps) {
  const room = usePlannerStore(state => state.room)
  const setRoom = usePlannerStore(state => state.setRoom)
  const setActivityType = usePlannerStore(state => state.setActivityType)
  
  const [showPresets, setShowPresets] = useState(false)

  const factors = room.maintenanceFactors ?? DEFAULT_MAINTENANCE_FACTORS
  const mf = calculateMaintenanceFactor(factors)
  
  // Apply a room preset
  const applyPreset = (preset: RoomPreset) => {
    setRoom({
      width: preset.width,
      length: preset.length,
      height: preset.height,
      workPlaneHeight: preset.workPlaneHeight,
      ceilingReflectance: preset.ceilingReflectance,
      wallReflectance: preset.wallReflectance,
      floorReflectance: preset.floorReflectance,
      name: preset.name
    })
    setActivityType(preset.activityType)
    setShowPresets(false)
  }
  
  return (
    <div className={`space-y-4 ${className}`}>
      {/* Room Presets */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Quick Setup
        </h4>
        <div className="relative">
          <button
            onClick={() => setShowPresets(!showPresets)}
            className="w-full px-3 py-2 text-left text-sm bg-blue-50 hover:bg-blue-100 border border-blue-200 rounded-lg text-blue-700 flex items-center justify-between transition-colors"
          >
            <span>Choose a room preset...</span>
            <svg className={`w-4 h-4 transition-transform ${showPresets ? 'rotate-180' : ''}`} fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
            </svg>
          </button>
          
          {showPresets && (
            <div className="absolute z-10 mt-1 w-full bg-white border rounded-lg shadow-lg max-h-64 overflow-y-auto">
              {getPresetsByCategory().map(({ category, presets }) => (
                <div key={category}>
                  <div className="px-3 py-1.5 text-xs font-semibold text-gray-500 bg-gray-50 sticky top-0">
                    {category}
                  </div>
                  {presets.map(preset => (
                    <button
                      key={preset.id}
                      onClick={() => applyPreset(preset)}
                      className="w-full px-3 py-2 text-left hover:bg-blue-50 flex items-start gap-2 border-b border-gray-100 last:border-0"
                    >
                      <div className="flex-1">
                        <div className="text-sm font-medium text-gray-900">{preset.name}</div>
                        <div className="text-xs text-gray-500">
                          {preset.width}m x {preset.length}m x {preset.height}m
                        </div>
                        <div className="text-xs text-gray-400">{preset.description}</div>
                      </div>
                    </button>
                  ))}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
      
      {/* Dimensions */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Room Dimensions
        </h4>
        <div className="grid grid-cols-3 gap-2">
          <div>
            <label className="text-xs text-gray-700 block mb-1">Width (m)</label>
            <input
              type="number"
              step="0.5"
              min="1"
              max="100"
              value={room.width}
              onChange={(e) => setRoom({ width: Math.max(1, parseFloat(e.target.value) || 1) })}
              className="w-full px-2 py-1.5 text-sm text-gray-900 border rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="text-xs text-gray-700 block mb-1">Length (m)</label>
            <input
              type="number"
              step="0.5"
              min="1"
              max="100"
              value={room.length}
              onChange={(e) => setRoom({ length: Math.max(1, parseFloat(e.target.value) || 1) })}
              className="w-full px-2 py-1.5 text-sm text-gray-900 border rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div>
            <label className="text-xs text-gray-700 block mb-1">Height (m)</label>
            <input
              type="number"
              step="0.1"
              min="2"
              max="20"
              value={room.height}
              onChange={(e) => setRoom({ height: Math.max(2, parseFloat(e.target.value) || 2.5) })}
              className="w-full px-2 py-1.5 text-sm text-gray-900 border rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
        </div>
        
        {/* Area display */}
        <div className="mt-2 text-xs text-gray-600 text-right">
          Floor area: {(room.width * room.length).toFixed(1)} m²
        </div>
      </div>
      
      {/* Work plane */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Work Plane
        </h4>
        <div className="flex items-center gap-3">
          <div className="flex-1">
            <label className="text-xs text-gray-700 block mb-1">Height from floor (m)</label>
            <input
              type="number"
              step="0.05"
              min="0"
              max={room.height - 0.5}
              value={room.workPlaneHeight}
              onChange={(e) => setRoom({ 
                workPlaneHeight: Math.max(0, Math.min(room.height - 0.5, parseFloat(e.target.value) || 0))
              })}
              className="w-full px-2 py-1.5 text-sm text-gray-900 border rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
            />
          </div>
          <div className="flex gap-1 pt-5">
            <button
              onClick={() => setRoom({ workPlaneHeight: 0 })}
              className={`px-2 py-1 text-xs rounded ${room.workPlaneHeight === 0 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
            >
              Floor
            </button>
            <button
              onClick={() => setRoom({ workPlaneHeight: 0.85 })}
              className={`px-2 py-1 text-xs rounded ${room.workPlaneHeight === 0.85 ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 hover:bg-gray-200 text-gray-700'}`}
            >
              Desk
            </button>
          </div>
        </div>
      </div>
      
      {/* Surface Reflectances */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Surface Reflectances
        </h4>
        <div className="space-y-3">
          <ReflectanceSlider
            label="Ceiling"
            value={room.ceilingReflectance}
            onChange={(v) => setRoom({ ceilingReflectance: v })}
            presets={[
              { value: 0.8, label: 'White' },
              { value: 0.7, label: 'Light' },
              { value: 0.5, label: 'Medium' }
            ]}
          />
          <ReflectanceSlider
            label="Walls"
            value={room.wallReflectance}
            onChange={(v) => setRoom({ wallReflectance: v })}
            presets={[
              { value: 0.7, label: 'Light' },
              { value: 0.5, label: 'Medium' },
              { value: 0.3, label: 'Dark' }
            ]}
          />
          <ReflectanceSlider
            label="Floor"
            value={room.floorReflectance}
            onChange={(v) => setRoom({ floorReflectance: v })}
            presets={[
              { value: 0.3, label: 'Light' },
              { value: 0.2, label: 'Medium' },
              { value: 0.1, label: 'Dark' }
            ]}
          />
        </div>
        
        {/* Common presets */}
        <div className="mt-3 pt-3 border-t">
          <div className="text-xs text-gray-700 mb-2">Quick presets:</div>
          <div className="flex gap-2">
            <button
              onClick={() => setRoom({ 
                ceilingReflectance: 0.7, 
                wallReflectance: 0.5, 
                floorReflectance: 0.2 
              })}
              className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
            >
              Office (70/50/20)
            </button>
            <button
              onClick={() => setRoom({ 
                ceilingReflectance: 0.8, 
                wallReflectance: 0.7, 
                floorReflectance: 0.3 
              })}
              className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
            >
              Bright (80/70/30)
            </button>
            <button
              onClick={() => setRoom({ 
                ceilingReflectance: 0.5, 
                wallReflectance: 0.3, 
                floorReflectance: 0.1 
              })}
              className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
            >
              Dark (50/30/10)
            </button>
          </div>
        </div>
      </div>
      
      {/* Calculation Settings */}
      <div>
        <h4 className="text-xs font-semibold text-gray-700 uppercase tracking-wide mb-2">
          Calculation Settings
        </h4>
        
        {/* Maintenance Factor */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-2">
            <span className="text-sm text-gray-700">Maintenance Factor</span>
            <span className="text-sm font-mono text-gray-600">{Math.round(mf * 100)}%</span>
          </div>

          {/* Environment presets */}
          <div className="flex flex-wrap gap-1 mb-3">
            {MAINTENANCE_PRESETS.map(preset => {
              const active = JSON.stringify(factors) === JSON.stringify(preset.factors)
              return (
                <button
                  key={preset.id}
                  onClick={() => setRoom({ maintenanceFactors: { ...preset.factors } })}
                  className={`px-2 py-1 text-xs rounded ${active ? 'bg-blue-100 text-blue-700' : 'bg-gray-100 hover:bg-gray-200 text-gray-600'}`}
                  title={preset.description}
                >
                  {preset.name}
                </button>
              )
            })}
          </div>

          {/* Factor sliders */}
          <div className="space-y-2">
            <FactorSlider
              label="LLMF · lamp lumen"
              value={factors.llmf}
              onChange={(v) => setRoom({ maintenanceFactors: { ...factors, llmf: v } })}
            />
            <FactorSlider
              label="LSF · lamp survival"
              value={factors.lsf}
              onChange={(v) => setRoom({ maintenanceFactors: { ...factors, lsf: v } })}
            />
            <FactorSlider
              label="LMF · luminaire dirt"
              value={factors.lmf}
              onChange={(v) => setRoom({ maintenanceFactors: { ...factors, lmf: v } })}
            />
            <FactorSlider
              label="RSMF · room surfaces"
              value={factors.rsmf}
              onChange={(v) => setRoom({ maintenanceFactors: { ...factors, rsmf: v } })}
            />
          </div>

          <p className="text-xs text-gray-500 mt-2">
            Maintained illuminance = MF × calculated. MF = LLMF × LSF × LMF × RSMF (CIE 97).
          </p>
        </div>
        
        {/* Operating hours (LENI) */}
        <div className="mb-3">
          <div className="flex items-center justify-between mb-1">
            <span className="text-sm text-gray-700">Operating Hours / Year</span>
            <span className="text-sm font-mono text-gray-600">{room.operatingHours ?? 2500} h</span>
          </div>
          <input
            type="range"
            min="500"
            max="8760"
            step="250"
            value={room.operatingHours ?? 2500}
            onChange={(e) => setRoom({ operatingHours: parseInt(e.target.value) })}
            className="w-full"
          />
          <div className="flex justify-between text-xs text-gray-500 mt-1">
            <span>500 h</span>
            <span>24/7 (8760 h)</span>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Used for LENI energy metric (EN 15193).
          </p>
        </div>

        {/* Include Reflections Toggle */}
        <div className="flex items-center justify-between py-2 border-t">
          <div>
            <span className="text-sm text-gray-700">Include Reflections</span>
            <p className="text-xs text-gray-500">Add light bouncing off surfaces (more accurate)</p>
          </div>
          <label className="relative inline-flex items-center cursor-pointer">
            <input
              type="checkbox"
              checked={room.includeReflections ?? true}
              onChange={(e) => setRoom({ includeReflections: e.target.checked })}
              className="sr-only peer"
            />
            <div className="w-9 h-5 bg-gray-200 peer-focus:outline-none peer-focus:ring-2 peer-focus:ring-blue-300 rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-blue-600"></div>
          </label>
        </div>
      </div>
      
      {/* Room Name */}
      <div>
        <label className="text-xs text-gray-700 block mb-1">Room Name</label>
        <input
          type="text"
          value={room.name || ''}
          onChange={(e) => setRoom({ name: e.target.value })}
          placeholder="e.g., Open Office Area"
          className="w-full px-2 py-1.5 text-sm text-gray-900 border rounded focus:ring-1 focus:ring-blue-500 focus:border-blue-500"
        />
      </div>
    </div>
  )
}

// =============================================================================
// Reflectance Slider
// =============================================================================

interface ReflectanceSliderProps {
  label: string
  value: number
  onChange: (value: number) => void
  presets: { value: number; label: string }[]
}

function ReflectanceSlider({ label, value, onChange, presets }: ReflectanceSliderProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-1">
        <span className="text-sm text-gray-700">{label}</span>
        <span className="text-sm font-mono text-gray-600">{Math.round(value * 100)}%</span>
      </div>
      <div className="flex items-center gap-2">
        <input
          type="range"
          min="0"
          max="90"
          value={Math.round(value * 100)}
          onChange={(e) => onChange(parseInt(e.target.value) / 100)}
          className="flex-1"
        />
        <div className="flex gap-1">
          {presets.map(preset => (
            <button
              key={preset.value}
              onClick={() => onChange(preset.value)}
              className={`px-1.5 py-0.5 text-xs rounded ${
                Math.abs(value - preset.value) < 0.05 
                  ? 'bg-blue-100 text-blue-700' 
                  : 'bg-gray-100 hover:bg-gray-200 text-gray-600'
              }`}
              title={preset.label}
            >
              {Math.round(preset.value * 100)}
            </button>
          ))}
        </div>
      </div>
    </div>
  )
}

interface FactorSliderProps {
  label: string
  value: number
  onChange: (value: number) => void
}

function FactorSlider({ label, value, onChange }: FactorSliderProps) {
  return (
    <div>
      <div className="flex items-center justify-between mb-0.5">
        <span className="text-xs text-gray-700">{label}</span>
        <span className="text-xs font-mono text-gray-600">{Math.round(value * 100)}%</span>
      </div>
      <input
        type="range"
        min="50"
        max="100"
        value={Math.round(value * 100)}
        onChange={(e) => onChange(parseInt(e.target.value) / 100)}
        className="w-full"
      />
    </div>
  )
}

// =============================================================================
// Export
// =============================================================================

export default RoomConfigPanel
