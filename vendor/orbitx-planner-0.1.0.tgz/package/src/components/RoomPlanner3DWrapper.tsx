'use client'

import { forwardRef, useMemo } from 'react'
import RoomPlanner3D, { type RoomPlanner3DHandle } from './RoomPlanner3D'
import type { IESProfile } from '../types/ies'

// Position data for custom luminaire placement
export interface LuminairePosition {
  x: number
  y: number
  z: number
  iesProfileId?: string
  dimming?: number
  /** Yaw rotation about the vertical axis (degrees), matching the photometric C-plane convention. */
  orientation?: number
}

interface RoomPlanner3DWrapperProps {
  width: number
  length: number
  height: number
  lights: number
  rows?: number
  columns?: number
  iesProfile?: IESProfile | null
  showHeatmap?: boolean
  showNavigationCube?: boolean
  onReady?: () => void
  
  // New props for custom positions
  customPositions?: LuminairePosition[]
}

const RoomPlanner3DWrapper = forwardRef<RoomPlanner3DHandle, RoomPlanner3DWrapperProps>(({
  customPositions,
  ...props
}, ref) => {
  // Convert custom positions to the format RoomPlanner3D expects
  const computedProps = useMemo(() => {
    if (customPositions && customPositions.length > 0) {
      // Convert positions from room coordinates to Three.js coordinates
      // Room coordinates: origin at center, Y is mounting height from floor
      // Three.js coordinates: origin at center, Y is relative to center
      const positions = customPositions.map(pos => ({
        x: pos.x,
        y: pos.y - props.height / 2, // Convert from floor-based to center-based
        z: pos.z,
        orientation: pos.orientation ?? 0
      }))
      
      return {
        ...props,
        lights: customPositions.length,
        customPositions: positions
      }
    }
    return props
  }, [customPositions, props])
  
  return (
    <div style={{ height: '100%', width: '100%' }}>
      <RoomPlanner3D ref={ref} {...computedProps} />
    </div>
  )
})

RoomPlanner3DWrapper.displayName = 'RoomPlanner3DWrapper'

export default RoomPlanner3DWrapper
export type { RoomPlanner3DHandle }
