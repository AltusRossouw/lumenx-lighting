"use client"

import React, { useState, useRef, useEffect } from 'react'

interface NavigationCubeProps {
  onViewSelect: (view: 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom' | 'iso1' | 'iso2' | 'iso3' | 'iso4') => void
  onManualRotate?: (rotX: number, rotY: number) => void
  rotateX?: number
  rotateY?: number
  size?: number
}

export default function NavigationCube({ onViewSelect, onManualRotate, rotateX = -25, rotateY = 35, size = 100 }: NavigationCubeProps) {
  const [hoveredFace, setHoveredFace] = useState<string | null>(null)
  const [isDragging, setIsDragging] = useState(false)
  const dragStartRef = useRef<{ x: number; y: number; rotX: number; rotY: number } | null>(null)

  const handleMouseDown = (e: React.MouseEvent) => {
    setIsDragging(true)
    dragStartRef.current = {
      x: e.clientX,
      y: e.clientY,
      rotX: rotateX,
      rotY: rotateY,
    }
    e.preventDefault()
  }

  useEffect(() => {
    if (!isDragging) return

    const handleMouseMove = (e: MouseEvent) => {
      if (!dragStartRef.current || !onManualRotate) return
      const deltaX = e.clientX - dragStartRef.current.x
      const deltaY = e.clientY - dragStartRef.current.y
      const newRotY = dragStartRef.current.rotY + deltaX * 0.5
      const newRotX = dragStartRef.current.rotX - deltaY * 0.5
      onManualRotate(newRotX, newRotY)
    }

    const handleMouseUp = () => {
      setIsDragging(false)
      dragStartRef.current = null
      // Clear manual rotation when drag ends
      if (onManualRotate) {
        // Wait a bit to allow the last rotation to apply
        setTimeout(() => {
          // Signal to stop manual rotation by not calling onManualRotate
          // The parent will handle reverting to camera tracking
        }, 50)
      }
    }

    window.addEventListener('mousemove', handleMouseMove)
    window.addEventListener('mouseup', handleMouseUp)
    return () => {
      window.removeEventListener('mousemove', handleMouseMove)
      window.removeEventListener('mouseup', handleMouseUp)
    }
  }, [isDragging, onManualRotate])

  const cubeHalf = size / 2
  const cornerSize = 12
  const faces = [
    { name: 'front', label: 'FRONT', transform: `rotateY(0deg) translateZ(${cubeHalf}px)`, view: 'front' as const },
    { name: 'back', label: 'BACK', transform: `rotateY(180deg) translateZ(${cubeHalf}px)`, view: 'back' as const },
    { name: 'right', label: 'RIGHT', transform: `rotateY(90deg) translateZ(${cubeHalf}px)`, view: 'right' as const },
    { name: 'left', label: 'LEFT', transform: `rotateY(-90deg) translateZ(${cubeHalf}px)`, view: 'left' as const },
    { name: 'top', label: 'TOP', transform: `rotateX(90deg) translateZ(${cubeHalf}px)`, view: 'top' as const },
    { name: 'bottom', label: 'BOTTOM', transform: `rotateX(-90deg) translateZ(${cubeHalf}px)`, view: 'bottom' as const },
  ]

  const corners = [
    { view: 'iso1' as const, title: 'Front-Right-Top', style: { top: 0, right: 0 } },
    { view: 'iso2' as const, title: 'Back-Right-Top', style: { top: 0, left: 0 } },
    { view: 'iso3' as const, title: 'Front-Left-Top', style: { bottom: 0, right: 0 } },
    { view: 'iso4' as const, title: 'Back-Left-Top', style: { bottom: 0, left: 0 } },
  ]

  return (
    <div
      style={{
        width: size,
        height: size,
        position: 'relative',
      }}
      className="pointer-events-auto select-none"
    >
      <div
        style={{
          width: '100%',
          height: '100%',
          perspective: '800px',
          cursor: isDragging ? 'grabbing' : 'grab',
        }}
        onMouseDown={handleMouseDown}
      >
        <div
          style={{
            width: '100%',
            height: '100%',
            position: 'relative',
            transformStyle: 'preserve-3d',
            transform: `rotateX(${rotateX}deg) rotateY(${rotateY}deg)`,
          }}
        >
          {faces.map((face) => (
            <div
              key={face.name}
              onClick={(e) => {
                e.stopPropagation()
                onViewSelect(face.view)
              }}
              onMouseEnter={() => setHoveredFace(face.name)}
              onMouseLeave={() => setHoveredFace(null)}
              style={{
                position: 'absolute',
                width: `${size}px`,
                height: `${size}px`,
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '10px',
                fontWeight: '600',
                color: 'white',
                backgroundColor: hoveredFace === face.name ? '#374151' : '#1f2937',
                border: '2px solid #4b5563',
                transform: face.transform,
                backfaceVisibility: 'hidden',
                cursor: 'pointer',
                transition: 'background-color 0.2s',
                textShadow: '0 1px 2px rgba(0,0,0,0.5)',
                pointerEvents: 'auto',
              }}
            >
              {face.label}
              {/* Add corner cubes to each face */}
              {corners.map((corner) => (
                <div
                  key={`${face.name}-${corner.view}`}
                  onClick={(e) => {
                    e.stopPropagation()
                    onViewSelect(corner.view)
                  }}
                  title={corner.title}
                  style={{
                    position: 'absolute',
                    width: `${cornerSize}px`,
                    height: `${cornerSize}px`,
                    backgroundColor: hoveredFace === `${face.name}-${corner.view}` ? '#60a5fa' : '#3b82f6',
                    border: '1px solid #2563eb',
                    cursor: 'pointer',
                    transition: 'background-color 0.2s',
                    zIndex: 10,
                    ...corner.style,
                  }}
                  onMouseEnter={(e) => {
                    e.stopPropagation()
                    setHoveredFace(`${face.name}-${corner.view}`)
                  }}
                  onMouseLeave={(e) => {
                    e.stopPropagation()
                    setHoveredFace(face.name)
                  }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>
    </div>
  )
}
