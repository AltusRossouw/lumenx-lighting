/**
 * OrbitX Lighting Planner — Consumer Edition (standalone package component)
 *
 * A refined three-step lighting estimator styled with a dark UI and Inter.
 * Theme color is exposed to the host via the `--op-accent` custom property, so
 * it is theme-agnostic and decoupled from any specific brand accent.
 */

'use client'

import React, { useState, useCallback, useMemo, useEffect, lazy, Suspense } from 'react'
import type { IESProfile } from '../types/ies'

// Lazy load the 3D viewer (framework-agnostic; works in Next.js and Vite)
const RoomPlanner3DWrapperLazy = lazy(() => import('./RoomPlanner3DWrapper'))
function RoomPlanner3DWrapper(props: React.ComponentProps<typeof RoomPlanner3DWrapperLazy>) {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center h-full bg-gray-900 rounded-xl">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-[var(--op-accent)] border-t-transparent rounded-full animate-spin mx-auto mb-3" />
          <p className="text-gray-400 text-sm">Loading preview…</p>
        </div>
      </div>
    }>
      <RoomPlanner3DWrapperLazy {...props} />
    </Suspense>
  )
}

// =============================================================================
// Types & data
// =============================================================================

type Step = 'room' | 'lights' | 'results'

interface RoomType {
  id: string
  name: string
  description: string
  width: number
  length: number
  height: number
  recommendedLux: number
  suggestedLights: number
}

const ROOM_TYPES: RoomType[] = [
  { id: 'bedroom', name: 'Bedroom', description: 'Soft ambient light for rest', width: 4, length: 4, height: 2.7, recommendedLux: 150, suggestedLights: 2 },
  { id: 'living-room', name: 'Living Room', description: 'Comfortable general illumination', width: 5, length: 6, height: 2.7, recommendedLux: 200, suggestedLights: 4 },
  { id: 'kitchen', name: 'Kitchen', description: 'Bright, even task lighting', width: 4, length: 5, height: 2.7, recommendedLux: 300, suggestedLights: 4 },
  { id: 'bathroom', name: 'Bathroom', description: 'Clean, shadow-free light', width: 3, length: 3, height: 2.5, recommendedLux: 300, suggestedLights: 2 },
  { id: 'home-office', name: 'Home Office', description: 'Focus-grade work lighting', width: 3, length: 4, height: 2.7, recommendedLux: 400, suggestedLights: 3 },
  { id: 'garage', name: 'Garage', description: 'High-output workshop light', width: 6, length: 6, height: 3, recommendedLux: 300, suggestedLights: 6 },
  { id: 'dining-room', name: 'Dining Room', description: 'Warm, inviting table light', width: 4, length: 5, height: 2.7, recommendedLux: 200, suggestedLights: 3 },
  { id: 'hallway', name: 'Hallway', description: 'Safe, consistent passage light', width: 1.5, length: 6, height: 2.5, recommendedLux: 100, suggestedLights: 3 },
]

// =============================================================================
// Helpers
// =============================================================================

type QualityScore = 'excellent' | 'good' | 'adequate' | 'insufficient'

function calculateLightingQuality(
  lumens: number,
  area: number,
  targetLux: number
): { score: QualityScore; estimatedLux: number; message: string } {
  const estimatedLux = (lumens * 0.5) / area
  const ratio = estimatedLux / targetLux

  if (ratio >= 1.1) return { score: 'excellent', estimatedLux, message: 'Comfortable headroom above the recommended level.' }
  if (ratio >= 0.9) return { score: 'good', estimatedLux, message: 'On target for everyday activities.' }
  if (ratio >= 0.7) return { score: 'adequate', estimatedLux, message: 'Acceptable, but adding a fixture would help.' }
  return { score: 'insufficient', estimatedLux, message: 'Below the recommended level for this space.' }
}

function qualityTone(score: QualityScore) {
  switch (score) {
    case 'excellent': return { fg: '#4ade80', bg: 'rgba(34,197,94,0.08)', ring: 'rgba(34,197,94,0.3)', label: 'Excellent' }
    case 'good': return { fg: '#38bdf8', bg: 'rgba(56,189,248,0.08)', ring: 'rgba(56,189,248,0.3)', label: 'Good' }
    case 'adequate': return { fg: '#fbbf24', bg: 'rgba(251,191,36,0.08)', ring: 'rgba(251,191,36,0.3)', label: 'Adequate' }
    default: return { fg: '#f87171', bg: 'rgba(248,113,113,0.08)', ring: 'rgba(248,113,113,0.3)', label: 'Insufficient' }
  }
}

function formatArea(room: RoomType) {
  return (room.width * room.length).toFixed(1)
}

function extractWatts(label?: string): number | null {
  if (!label) return null
  const m = label.match(/(\d+)\s*W\b/i)
  return m ? parseInt(m[1], 10) : null
}

// =============================================================================
// Small line-glyph icons (stroke, 24x24)
// =============================================================================

function RoomGlyph({ id }: { id: string }) {
  const paths: Record<string, React.ReactNode> = {
    bedroom: <><path d="M3 18v-6a2 2 0 012-2h14a2 2 0 012 2v6" /><path d="M3 18h18M5 10V6a1 1 0 011-1h3a1 1 0 011 1v4M14 10V6a1 1 0 011-1h3a1 1 0 011 1v4" /></>,
    'living-room': <><path d="M4 11h16M6 11V5h12v6M3 12l9-7 9 7M7 20v-4a2 2 0 012-2h6a2 2 0 012 2v4" /></>,
    kitchen: <><path d="M4 12V6a2 2 0 012-2h12a2 2 0 012 2v6M4 12v7M20 12v7M8 12v-2M12 12v-2M16 12v-2" /><path d="M8 19h8" /></>,
    bathroom: <><path d="M4 12V5a1 1 0 011-1h14a1 1 0 011 1v7M4 12v8M20 12v8M9 4v2M15 4v2" /><path d="M12 16a2 2 0 100-4 2 2 0 000 4z" /></>,
    'home-office': <><path d="M4 6h16v9H4zM8 19h8M12 15v4M8 9l3 3 5-5" /></>,
    garage: <><path d="M4 14V7l8-4 8 4v7M4 14h16M5 14v6M19 14v6M6 18h4M14 18h4" /></>,
    'dining-room': <><circle cx="12" cy="12" r="6" /><path d="M12 6v12M6 12h12M12 3v2M12 19v2" /></>,
    hallway: <><path d="M3 6h18M3 18h18M5 6v12M19 6v12" /><path d="M12 6v12" /></>,
  }
  return (
    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.4} strokeLinecap="round" strokeLinejoin="round" className="w-6 h-6">
      {paths[id] ?? <path d="M4 4h16v16H4z" />}
    </svg>
  )
}

// =============================================================================
// Main component
// =============================================================================

export interface ConsumerPlannerProps {
  /** Target route/anchor for the "Open in Pro mode" / "Pro mode" links. */
  proHref?: string
  /** Target route/anchor for the "Contact our team" link. */
  contactHref?: string
}

export default function ConsumerPlanner({
  proHref = '#pro-edition',
  contactHref = '#contact',
}: ConsumerPlannerProps = {}) {
  const [step, setStep] = useState<Step>('room')
  const [selectedRoom, setSelectedRoom] = useState<RoomType | null>(null)
  const [lightCount, setLightCount] = useState(4)
  const [iesProfiles, setIesProfiles] = useState<IESProfile[]>([])
  const [selectedProfile, setSelectedProfile] = useState<IESProfile | null>(null)
  const [loading, setLoading] = useState(true)
  const [showCustomSize, setShowCustomSize] = useState(false)
  const [customWidth, setCustomWidth] = useState(5)
  const [customLength, setCustomLength] = useState(5)
  const [customHeight, setCustomHeight] = useState(2.7)

  useEffect(() => {
    async function loadProfiles() {
      try {
        const response = await fetch('/api/ies')
        if (response.ok) {
          const data = await response.json()
          const profiles: IESProfile[] = data?.profiles ?? []
          setIesProfiles(profiles)
          if (profiles.length > 0) setSelectedProfile(profiles[0])
        }
      } catch (e) {
        console.error('Failed to load IES profiles:', e)
      } finally {
        setLoading(false)
      }
    }
    loadProfiles()
  }, [])

  const roomDimensions = useMemo(() => {
    if (showCustomSize) return { width: customWidth, length: customLength, height: customHeight }
    return selectedRoom
      ? { width: selectedRoom.width, length: selectedRoom.length, height: selectedRoom.height }
      : { width: 5, length: 5, height: 2.7 }
  }, [selectedRoom, showCustomSize, customWidth, customLength, customHeight])

  const lightingQuality = useMemo(() => {
    if (!selectedProfile?.lumens || !selectedRoom) return null
    const totalLumens = lightCount * selectedProfile.lumens
    const area = roomDimensions.width * roomDimensions.length
    return calculateLightingQuality(totalLumens, area, selectedRoom.recommendedLux)
  }, [selectedProfile, lightCount, roomDimensions, selectedRoom])

  const gridLayout = useMemo(() => {
    const cols = Math.ceil(Math.sqrt(lightCount * (roomDimensions.width / roomDimensions.length)))
    const rows = Math.ceil(lightCount / cols)
    return { rows, cols }
  }, [lightCount, roomDimensions])

  const totalLumens = selectedProfile?.lumens ? lightCount * selectedProfile.lumens : 0
  const fixtureWatts = extractWatts(selectedProfile?.variantLabel)
  const totalWatts = fixtureWatts != null ? lightCount * fixtureWatts : null

  const handleRoomSelect = useCallback((room: RoomType) => {
    setSelectedRoom(room)
    setLightCount(room.suggestedLights)
    setShowCustomSize(false)
  }, [])

  const handleNext = useCallback(() => {
    if (step === 'room' && selectedRoom) setStep('lights')
    else if (step === 'lights') setStep('results')
  }, [step, selectedRoom])

  const handleBack = useCallback(() => {
    if (step === 'lights') setStep('room')
    else if (step === 'results') setStep('lights')
  }, [step])

  const stepIndex = step === 'room' ? 0 : step === 'lights' ? 1 : 2

  return (
    <div className="min-h-screen bg-black text-white flex flex-col">
      <main className="flex-1 planner-shell relative overflow-hidden">
        {/* Subtle top glow */}
        <div
          className="pointer-events-none absolute inset-x-0 top-0 h-72 opacity-40"
          style={{ background: 'radial-gradient(circle at 50% 0%, rgba(0,132,255,0.22) 0%, transparent 60%)' }}
        />

        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-24 pb-12">
          {/* Stepper */}
          <div className="planner-stepper mb-10">
            {[
              { key: 'room', label: 'Room', no: '01' },
              { key: 'lights', label: 'Lights', no: '02' },
              { key: 'results', label: 'Result', no: '03' },
            ].map((s, i) => {
              const active = step === s.key
              const done = i < stepIndex
              return (
                <React.Fragment key={s.key}>
                  <button
                    onClick={() => {
                      if (s.key === 'room') setStep('room')
                      else if (s.key === 'lights' && selectedRoom) setStep('lights')
                      else if (s.key === 'results' && selectedRoom) setStep('results')
                    }}
                    className={`planner-step ${active ? 'is-active' : done ? 'is-done' : ''}`}
                  >
                    <span className="planner-step__no">{s.no}</span>
                    <span className="planner-step__label">{s.label}</span>
                  </button>
                  {i < 2 && <span className={`planner-step__line ${i < stepIndex ? 'is-done' : ''}`} />}
                </React.Fragment>
              )
            })}
          </div>
          {/* Step 1 — Room */}
          {step === 'room' && (
            <section className="planner-section" key="room">
              <div className="planner-section__head">
                <p className="planner-kicker">01 — Space</p>
                <h1 className="planner-title">Which room are you lighting?</h1>
                <p className="planner-sub">Pick a space, then we&apos;ll recommend a starting layout.</p>
              </div>

              <div className="room-grid">
                {ROOM_TYPES.map((room) => {
                  const active = selectedRoom?.id === room.id
                  return (
                    <button key={room.id} onClick={() => handleRoomSelect(room)} className={`room-card ${active ? 'is-active' : ''}`}>
                      <span className="room-card__corner" />
                      <span className="room-card__icon"><RoomGlyph id={room.id} /></span>
                      <span className="room-card__name">{room.name}</span>
                      <span className="room-card__desc">{room.description}</span>
                      <span className="room-card__meta">
                        <span className="room-card__dim">{room.width} × {room.length} m</span>
                        <span className="room-card__lux">{room.recommendedLux} lx</span>
                      </span>
                    </button>
                  )
                })}
              </div>

              {/* Custom size */}
              <div className="custom-size">
                <button onClick={() => setShowCustomSize(!showCustomSize)} className="custom-size__toggle">
                  <svg className={`w-4 h-4 transition-transform ${showCustomSize ? 'rotate-45' : ''}`} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={1.6} strokeLinecap="round">
                    <path d="M12 5v14M5 12h14" />
                  </svg>
                  {showCustomSize ? 'Hide custom dimensions' : 'Enter custom dimensions'}
                </button>

                {showCustomSize && (
                  <div className="custom-size__panel">
                    <div className="dim-field">
                      <label>Width <span className="dim-field__unit">m</span></label>
                      <input type="number" min={1} max={50} step={0.5} value={customWidth} onChange={(e) => setCustomWidth(parseFloat(e.target.value) || 1)} />
                    </div>
                    <div className="dim-field">
                      <label>Length <span className="dim-field__unit">m</span></label>
                      <input type="number" min={1} max={50} step={0.5} value={customLength} onChange={(e) => setCustomLength(parseFloat(e.target.value) || 1)} />
                    </div>
                    <div className="dim-field">
                      <label>Height <span className="dim-field__unit">m</span></label>
                      <input type="number" min={2} max={10} step={0.1} value={customHeight} onChange={(e) => setCustomHeight(parseFloat(e.target.value) || 2.5)} />
                    </div>
                    <div className="dim-field dim-field--area">
                      <span className="dim-field__label">Floor area</span>
                      <span className="dim-field__value">{(customWidth * customLength).toFixed(1)} m²</span>
                    </div>
                  </div>
                )}
              </div>

              <div className="planner-nav">
                <button onClick={handleNext} disabled={!selectedRoom} className={`btn-primary ${selectedRoom ? '' : 'is-disabled'}`}>
                  Continue to lights
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
                </button>
              </div>
            </section>
          )}

          {/* Step 2 — Lights */}
          {step === 'lights' && selectedRoom && (
            <section className="planner-section" key="lights">
              <div className="planner-section__head">
                <p className="planner-kicker">02 — Selection</p>
                <h1 className="planner-title">Choose a fixture &amp; quantity</h1>
                <p className="planner-sub">
                  {selectedRoom.name} · {formatArea(selectedRoom)} m² · recommended {selectedRoom.recommendedLux} lx
                </p>
              </div>

              <div className="lights-layout">
                <div className="lights-controls">
                  {/* Product */}
                  <div className="control-block">
                    <span className="control-block__label">Fixture</span>
                    {!loading && iesProfiles.length > 0 ? (
                      <select value={selectedProfile?.id || ''} onChange={(e) => { const p = iesProfiles.find((x) => x.id === e.target.value); if (p) setSelectedProfile(p) }} className="select-control">
                        {iesProfiles.map((p) => (
                          <option key={p.id} value={p.id}>
                            {p.productName} — {p.variantLabel}{p.lumens ? ` (${p.lumens.toLocaleString()} lm)` : ''}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <div className="select-control is-loading">Loading fixtures…</div>
                    )}
                  </div>

                  {/* Quantity */}
                  <div className="control-block">
                    <div className="control-block__row">
                      <span className="control-block__label">Quantity</span>
                      <span className="qty-value">{lightCount}</span>
                    </div>
                    <input type="range" min={1} max={20} value={lightCount} onChange={(e) => setLightCount(parseInt(e.target.value))} className="range-control" />
                    <div className="qty-presets">
                      {[1, 2, 4, 6, 8, 12].map((n) => (
                        <button key={n} onClick={() => setLightCount(n)} className={`qty-chip ${lightCount === n ? 'is-active' : ''}`}>{n}</button>
                      ))}
                    </div>
                  </div>

                  {/* Live metrics */}
                  <div className="metrics-strip">
                    <div className="metric">
                      <span className="metric__label">Total flux</span>
                      <span className="metric__value">{totalLumens.toLocaleString()}</span>
                      <span className="metric__unit">lm</span>
                    </div>
                    <div className="metric">
                      <span className="metric__label">Est. load</span>
                      <span className="metric__value">{totalWatts != null ? totalWatts : '—'}</span>
                      <span className="metric__unit">W</span>
                    </div>
                    <div className="metric metric--accent">
                      <span className="metric__label">Est. illuminance</span>
                      <span className="metric__value">{lightingQuality ? Math.round(lightingQuality.estimatedLux) : '—'}</span>
                      <span className="metric__unit">lx</span>
                    </div>
                  </div>

                  <div className="layout-note">
                    <span className="layout-note__glyph">⌗</span>
                    Grid layout {gridLayout.rows} × {gridLayout.cols}
                  </div>
                </div>

                <div className="viewer-panel">
                  <div className="viewer-panel__bar">
                    <span>LIVE PREVIEW</span>
                    <span className="viewer-panel__dots"><i /><i /><i /></span>
                  </div>
                  <div className="viewer-panel__canvas">
                    <RoomPlanner3DWrapper width={roomDimensions.width} length={roomDimensions.length} height={roomDimensions.height} lights={lightCount} rows={gridLayout.rows} columns={gridLayout.cols} iesProfile={selectedProfile} showHeatmap showNavigationCube={false} />
                  </div>
                </div>
              </div>

              <div className="planner-nav">
                <button onClick={handleBack} className="btn-ghost">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M19 12H5M11 18l-6-6 6-6" /></svg>
                  Back
                </button>
                <button onClick={handleNext} className="btn-primary">
                  View results
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M5 12h14M13 6l6 6-6 6" /></svg>
                </button>
              </div>
            </section>
          )}

          {/* Step 3 — Results */}
          {step === 'results' && selectedRoom && (
            <section className="planner-section" key="results">
              <div className="planner-section__head">
                <p className="planner-kicker">03 — Review</p>
                <h1 className="planner-title">Your lighting plan</h1>
                <p className="planner-sub">{selectedRoom.name} · {roomDimensions.width} × {roomDimensions.length} m</p>
              </div>

              <div className="results-layout">
                <div className="results-sheet">
                  {/* Quality */}
                  {lightingQuality && (
                    <div className="quality-card" style={{ background: qualityTone(lightingQuality.score).bg, borderColor: qualityTone(lightingQuality.score).ring }}>
                      <div className="quality-card__top">
                        <span className="quality-card__label">Lighting quality</span>
                        <span className="quality-card__badge" style={{ color: qualityTone(lightingQuality.score).fg }}>
                          {qualityTone(lightingQuality.score).label}
                        </span>
                      </div>
                      <div className="quality-card__big">
                        {Math.round(lightingQuality.estimatedLux)} <span className="quality-card__unit">lx</span>
                      </div>
                      <p className="quality-card__msg">{lightingQuality.message}</p>

                      <div className="quality-card__bars">
                        <div className="quality-bar">
                          <span className="quality-bar__label">Estimated</span>
                          <div className="quality-bar__track"><div className="quality-bar__fill" style={{ width: `${Math.min(100, (lightingQuality.estimatedLux / (selectedRoom.recommendedLux * 1.5)) * 100)}%` }} /></div>
                          <span className="quality-bar__val">{Math.round(lightingQuality.estimatedLux)}</span>
                        </div>
                        <div className="quality-bar">
                          <span className="quality-bar__label">Recommended</span>
                          <div className="quality-bar__track"><div className="quality-bar__fill quality-bar__fill--ref" style={{ width: `${Math.min(100, (selectedRoom.recommendedLux / (selectedRoom.recommendedLux * 1.5)) * 100)}%` }} /></div>
                          <span className="quality-bar__val">{selectedRoom.recommendedLux}</span>
                        </div>
                      </div>
                    </div>
                  )}

                  {/* Spec sheet */}
                  <div className="spec-sheet">
                    <div className="spec-sheet__title">Configuration</div>
                    {[
                      ['Room', selectedRoom.name],
                      ['Dimensions', `${roomDimensions.width} × ${roomDimensions.length} × ${roomDimensions.height} m`],
                      ['Floor area', `${(roomDimensions.width * roomDimensions.length).toFixed(1)} m²`],
                      ['Fixture', selectedProfile?.variantLabel || 'LED'],
                      ['Quantity', `${lightCount} × ${selectedProfile?.lumens?.toLocaleString() ?? 0} lm`],
                      ['Total flux', `${totalLumens.toLocaleString()} lm`],
                      ['Layout', `${gridLayout.rows} × ${gridLayout.cols}`],
                    ].map(([k, v]) => (
                      <div className="spec-row" key={k}>
                        <span className="spec-row__k">{k}</span>
                        <span className="spec-row__v">{v}</span>
                      </div>
                    ))}
                  </div>

                  <div className="results-actions">
                    <button
                      onClick={() => {
                        const projectData = {
                          room: { width: roomDimensions.width, length: roomDimensions.length, height: roomDimensions.height, name: selectedRoom.name },
                          lights: lightCount,
                          layout: gridLayout,
                          iesProfileId: selectedProfile?.id || '',
                          roomType: selectedRoom.id,
                        }
                        const querySep = proHref.includes('?') ? '&' : proHref.startsWith('#') ? '' : '?'
                        window.location.href = `${proHref}${querySep}import=${encodeURIComponent(JSON.stringify(projectData))}`
                      }}
                      className="btn-primary btn-primary--block"
                    >
                      Open in Pro mode
                      <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M7 17L17 7M8 7h9v9" /></svg>
                    </button>
                    <button
                      onClick={() => {
                        const summary = `OrbitX Lighting Plan\n${selectedRoom.name} (${roomDimensions.width}m × ${roomDimensions.length}m)\n${lightCount} × ${selectedProfile?.productName || 'LED'}\nEstimated: ${lightingQuality?.estimatedLux.toFixed(0) || 'N/A'} lux`
                        navigator.clipboard.writeText(summary)
                        alert('Plan summary copied to clipboard.')
                      }}
                      className="btn-ghost btn-ghost--block"
                    >
                      Copy summary
                    </button>
                  </div>

                  <p className="results-note">
                    Refine reflectances, mounting height, glare (UGR) and generate a full PDF report in{' '}
                    <a href={proHref} className="results-note__link">Pro mode</a>.
                  </p>
                </div>

                <div className="viewer-panel">
                  <div className="viewer-panel__bar">
                    <span>PREVIEW</span>
                    <span className="viewer-panel__dots"><i /><i /><i /></span>
                  </div>
                  <div className="viewer-panel__canvas">
                    <RoomPlanner3DWrapper width={roomDimensions.width} length={roomDimensions.length} height={roomDimensions.height} lights={lightCount} rows={gridLayout.rows} columns={gridLayout.cols} iesProfile={selectedProfile} showHeatmap showNavigationCube={false} />
                  </div>
                </div>
              </div>

              <div className="planner-nav">
                <button onClick={handleBack} className="btn-ghost">
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M19 12H5M11 18l-6-6 6-6" /></svg>
                  Adjust
                </button>
                <button onClick={() => { setStep('room'); setSelectedRoom(null) }} className="btn-ghost">
                  Start over
                  <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" className="w-4 h-4"><path d="M3 12a9 9 0 109-9 9.75 9.75 0 00-6.74 2.74L3 8M3 3v5h5" /></svg>
                </button>
              </div>
            </section>
          )}
        </div>
      </main>

      {/* ======================= Footer ======================= */}
      <footer className="border-t border-gray-800 py-10">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-400">
          <p>Estimates for planning only — verified photometrics available in Pro mode.</p>
          <p>Need help? <a href={contactHref} className="text-[var(--op-accent)] hover:underline">Contact our team</a></p>
        </div>
      </footer>

    </div>
  )
}
