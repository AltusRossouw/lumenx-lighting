/**
 * OrbitX Lighting Planner Pro - Enhanced DIALux-Inspired Lighting Design Tool
 * (standalone package component)
 *
 * Professional lighting design interface with:
 * - 2D/3D visualization
 * - Point-by-point illuminance calculation (Web Worker)
 * - EN 12464-1 compliance checking
 * - Heatmap, isolines, and value grid overlays
 * - Real IES photometric data
 */

'use client'

import React, { useEffect, useCallback, useState, useMemo, useRef, lazy, Suspense } from 'react'
import { usePlannerStore } from '../stores/plannerStore'
import { usePlannerCalculation, usePlannerIESProfiles } from '../hooks/usePlannerCalculation'
import { usePDFExport } from '../hooks/usePDFExport'
import { useProjectStorage } from '../hooks/useProjectStorage'
import {
  PlannerLayout,
  Panel,
  PanelSection,
  Viewer2D,
  LuminaireList,
  ActivitySelector,
  ComplianceMonitor,
  ResultsPanel,
  RoomConfigPanel,
  Toolbar,
  QuickResultsBar,
  SetupWizard,
  QuoteRequestModal
} from './planner'

// Lazy load the 3D viewer (framework-agnostic; works in Next.js and Vite)
const RoomPlanner3DWrapperLazy = lazy(() => import('./RoomPlanner3DWrapper'))
function RoomPlanner3DWrapper(props: React.ComponentProps<typeof RoomPlanner3DWrapperLazy>) {
  return (
    <Suspense fallback={
      <div className="flex items-center justify-center h-full bg-gray-900">
        <div className="text-center">
          <div className="w-8 h-8 border-2 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-2" />
          <p className="text-gray-400 text-sm">Loading 3D viewer...</p>
        </div>
      </div>
    }>
      <RoomPlanner3DWrapperLazy {...props} />
    </Suspense>
  )
}

// =============================================================================
// Header Component
// =============================================================================

interface PlannerHeaderProps {
  onOpenQuote: () => void
  onOpenWizard: () => void
  homeHref: string
}

function PlannerHeader({ onOpenQuote, onOpenWizard, homeHref }: PlannerHeaderProps) {
  const projectName = usePlannerStore(state => state.projectName)
  const isDirty = usePlannerStore(state => state.isDirty)
  const projectId = usePlannerStore(state => state.projectId)
  const setProjectName = usePlannerStore(state => state.setProjectName)
  const newProject = usePlannerStore(state => state.newProject)
  const results = usePlannerStore(state => state.results)
  const luminaires = usePlannerStore(state => state.luminaires)
  
  const { exportPDF, isExporting, progress, message } = usePDFExport()
  const { saveProject, isSaving, lastSaved, projects, loadProject } = useProjectStorage()
  const [showProjectsModal, setShowProjectsModal] = useState(false)
  
  const handleExport = useCallback(async () => {
    await exportPDF({
      includeCompliance: true,
      include2DView: true,
      includeLuminaireList: true
    })
  }, [exportPDF])
  
  const handleSave = useCallback(async () => {
    try {
      await saveProject()
    } catch (err) {
      console.error('Failed to save:', err)
      alert('Failed to save project')
    }
  }, [saveProject])
  
  const handleLoad = useCallback(async (id: string) => {
    try {
      await loadProject(id)
      setShowProjectsModal(false)
    } catch (err) {
      console.error('Failed to load:', err)
      alert('Failed to load project')
    }
  }, [loadProject])
  
  return (
    <>
      <div className="flex items-center justify-between px-4 py-2 bg-gray-900 text-white">
        {/* Left - Logo and back */}
        <div className="flex items-center gap-4">
          <a 
            href={homeHref} 
            className="flex items-center gap-2 text-gray-400 hover:text-white transition-colors"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 19l-7-7 7-7" />
            </svg>
            <span className="text-sm">Back</span>
          </a>
          
          <div className="h-6 w-px bg-gray-700" />
          
          <div className="flex items-center gap-2">
            <span className="text-blue-400 font-bold">OrbitX</span>
            <span className="text-gray-500">|</span>
            <span className="font-medium">Lighting Planner Pro</span>
          </div>
        </div>
        
        {/* Center - Project name */}
        <div className="flex items-center gap-2">
          <input
            type="text"
            value={projectName}
            onChange={(e) => setProjectName(e.target.value)}
            className="bg-transparent border-b border-transparent hover:border-gray-600 focus:border-blue-500 px-2 py-1 text-center outline-none transition-colors"
            placeholder="Untitled Project"
          />
          {isDirty && (
            <span className="text-xs text-amber-400" title="Unsaved changes">*</span>
          )}
          {lastSaved && !isDirty && (
            <span className="text-xs text-green-400" title={`Saved at ${lastSaved.toLocaleTimeString()}`}>
              Saved
            </span>
          )}
        </div>
        
        {/* Right - Actions */}
        <div className="flex items-center gap-2">
          {/* Setup Wizard */}
          <button
            onClick={onOpenWizard}
            className="px-3 py-1.5 text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1"
            title="Open setup wizard"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 10V3L4 14h7v7l9-11h-7z" />
            </svg>
            <span className="hidden sm:inline">Wizard</span>
          </button>
          
          {/* Open Projects */}
          <button
            onClick={() => setShowProjectsModal(true)}
            className="px-3 py-1.5 text-sm text-gray-400 hover:text-white transition-colors flex items-center gap-1"
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
            </svg>
            <span>Projects</span>
          </button>
          
          {/* New Project */}
          <button
            onClick={() => {
              if (isDirty && !confirm('Discard unsaved changes?')) return
              newProject()
            }}
            className="px-3 py-1.5 text-sm text-gray-400 hover:text-white transition-colors"
          >
            New
          </button>
          
          {/* Save */}
          <button
            onClick={handleSave}
            disabled={isSaving}
            className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-1 ${
              isSaving 
                ? 'bg-gray-700 cursor-wait text-gray-400' 
                : isDirty
                  ? 'bg-green-600 hover:bg-green-700 text-white'
                  : 'bg-gray-700 text-gray-400 hover:bg-gray-600'
            }`}
          >
            {isSaving ? (
              <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4z" />
              </svg>
            ) : (
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 7H5a2 2 0 00-2 2v9a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-3m-1 4l-3 3m0 0l-3-3m3 3V4" />
              </svg>
            )}
            <span>Save</span>
          </button>
          
          {/* Export PDF */}
          <button
            onClick={handleExport}
            disabled={isExporting || !results}
            className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-2 ${
              isExporting 
                ? 'bg-blue-500 cursor-wait' 
                : !results
                  ? 'bg-gray-600 cursor-not-allowed text-gray-400'
                  : 'bg-blue-600 hover:bg-blue-700'
            }`}
            title={!results ? 'Calculate first to enable export' : 'Export PDF report'}
          >
            {isExporting ? (
              <>
                <svg className="w-4 h-4 animate-spin" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                </svg>
                <span>{progress}%</span>
              </>
            ) : (
              <>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 10v6m0 0l-3-3m3 3l3-3m2 8H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                </svg>
                <span>PDF</span>
              </>
            )}
          </button>
          
          {/* Request Quote */}
          <button
            onClick={onOpenQuote}
            disabled={luminaires.length === 0}
            className={`px-3 py-1.5 text-sm rounded transition-colors flex items-center gap-2 ${
              luminaires.length === 0
                ? 'bg-gray-600 cursor-not-allowed text-gray-400'
                : 'bg-green-600 hover:bg-green-700 text-white'
            }`}
            title={luminaires.length === 0 ? 'Add luminaires first' : 'Request a quote for this design'}
          >
            <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
            </svg>
            <span>Quote</span>
          </button>
        </div>
      </div>
      
      {/* Projects Modal */}
      {showProjectsModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50">
          <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full mx-4 max-h-[80vh] overflow-hidden">
            <div className="flex items-center justify-between px-6 py-4 border-b">
              <h2 className="text-lg font-semibold text-gray-900">Saved Projects</h2>
              <button
                onClick={() => setShowProjectsModal(false)}
                className="text-gray-400 hover:text-gray-600"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                </svg>
              </button>
            </div>
            
            <div className="p-6 overflow-y-auto max-h-[60vh]">
              {projects.length === 0 ? (
                <div className="text-center py-8 text-gray-500">
                  <svg className="w-12 h-12 mx-auto mb-3 text-gray-300" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                  </svg>
                  <p>No saved projects yet</p>
                  <p className="text-sm mt-1">Save your current project to see it here</p>
                </div>
              ) : (
                <div className="space-y-2">
                  {projects.map(project => (
                    <button
                      key={project.id}
                      onClick={() => handleLoad(project.id)}
                      className="w-full text-left p-4 rounded-lg border border-gray-200 hover:border-blue-300 hover:bg-blue-50 transition-colors"
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <h3 className="font-medium text-gray-900">{project.name}</h3>
                          <p className="text-sm text-gray-500 mt-1">
                            {project.roomDimensions} • {project.luminaireCount} luminaire{project.luminaireCount !== 1 ? 's' : ''}
                          </p>
                          <p className="text-xs text-gray-400 mt-1">
                            Last modified: {new Date(project.updatedAt).toLocaleDateString()}
                          </p>
                        </div>
                        {project.id === projectId && (
                          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">
                            Current
                          </span>
                        )}
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>
          </div>
        </div>
      )}
    </>
  )
}

// =============================================================================
// Left Panel - Configuration
// =============================================================================

function LeftPanel() {
  return (
    <Panel title="Configuration">
      <div className="space-y-6">
        <PanelSection title="Room Setup" collapsible defaultOpen>
          <RoomConfigPanel />
        </PanelSection>
        
        <PanelSection title="Activity Type" collapsible defaultOpen>
          <ActivitySelector />
        </PanelSection>
        
        <PanelSection title="Luminaires" collapsible defaultOpen>
          <LuminaireListSection />
        </PanelSection>
      </div>
    </Panel>
  )
}

function LuminaireListSection() {
  const luminaires = usePlannerStore(state => state.luminaires)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const room = usePlannerStore(state => state.room)
  const addLuminaire = usePlannerStore(state => state.addLuminaire)
  const createLuminaireGrid = usePlannerStore(state => state.createLuminaireGrid)
  const startPlacing = usePlannerStore(state => state.startPlacing)
  const isPlacing = usePlannerStore(state => state.isPlacing)
  const placingIesProfileId = usePlannerStore(state => state.placingIesProfileId)
  const stopPlacing = usePlannerStore(state => state.stopPlacing)
  
  const handleQuickAdd = useCallback((profileId: string) => {
    // Add at center of room, near ceiling
    addLuminaire(profileId, {
      x: 0,
      y: room.height - 0.1,
      z: 0
    })
  }, [addLuminaire, room.height])
  
  const handleAddGrid = useCallback((profileId: string, rows: number, cols: number) => {
    // Calculate optimal spacing based on room size
    const spacingX = room.width / (cols + 1)
    const spacingZ = room.length / (rows + 1)
    createLuminaireGrid(profileId, rows, cols, spacingX, spacingZ, room.height - 0.1)
  }, [createLuminaireGrid, room])
  
  return (
    <div className="space-y-3">
      {/* Quick add buttons */}
      {iesProfiles.length > 0 && (
        <div className="space-y-2">
          <div className="text-xs text-gray-700">Quick add:</div>
          <div className="flex flex-wrap gap-2">
            <button
              onClick={() => startPlacing(iesProfiles[0].id)}
              className={`px-3 py-1.5 text-xs rounded transition-colors ${
                isPlacing 
                  ? 'bg-amber-100 text-amber-700 border border-amber-300'
                  : 'bg-blue-50 hover:bg-blue-100 text-blue-700 border border-blue-200'
              }`}
            >
              {isPlacing ? 'Click to place...' : '+ Click to place'}
            </button>
            {isPlacing && (
              <button
                onClick={stopPlacing}
                className="px-3 py-1.5 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
              >
                Cancel
              </button>
            )}
          </div>
          
          {/* Grid presets */}
          {!isPlacing && iesProfiles.length > 0 && (
            <div className="flex flex-wrap gap-2">
              <button
                onClick={() => handleAddGrid(iesProfiles[0].id, 2, 3)}
                className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
              >
                2x3 Grid
              </button>
              <button
                onClick={() => handleAddGrid(iesProfiles[0].id, 3, 4)}
                className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
              >
                3x4 Grid
              </button>
              <button
                onClick={() => handleAddGrid(iesProfiles[0].id, 4, 5)}
                className="px-2 py-1 text-xs bg-gray-100 hover:bg-gray-200 rounded text-gray-700"
              >
                4x5 Grid
              </button>
            </div>
          )}
        </div>
      )}
      
      {/* Luminaire count */}
      <div className="text-sm text-gray-600">
        {luminaires.length === 0 
          ? 'No luminaires placed yet' 
          : `${luminaires.length} luminaire${luminaires.length !== 1 ? 's' : ''} placed`
        }
      </div>
    </div>
  )
}

// =============================================================================
// Right Panel - Results
// =============================================================================

function RightPanel() {
  return (
    <Panel title="Results & Compliance">
      <div className="space-y-6">
        <PanelSection title="Calculation Results" collapsible={false}>
          <ResultsPanel />
        </PanelSection>
        
        <PanelSection title="Compliance Check" collapsible defaultOpen>
          <ComplianceMonitor />
        </PanelSection>
        
        <PanelSection title="Placed Luminaires" collapsible defaultOpen>
          <LuminaireList className="max-h-64 overflow-y-auto -mx-4" />
        </PanelSection>
      </div>
    </Panel>
  )
}

// =============================================================================
// Main Viewer Component
// =============================================================================

function MainViewer() {
  const viewMode = usePlannerStore(state => state.viewMode)
  const room = usePlannerStore(state => state.room)
  const luminaires = usePlannerStore(state => state.luminaires)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  const displayOptions = usePlannerStore(state => state.displayOptions)
  const isPlacing = usePlannerStore(state => state.isPlacing)
  const placingIesProfileId = usePlannerStore(state => state.placingIesProfileId)
  const addLuminaire = usePlannerStore(state => state.addLuminaire)
  
  // Handle luminaire placement in 2D view
  const handlePlaceLuminaire = useCallback((x: number, z: number) => {
    if (isPlacing && placingIesProfileId) {
      addLuminaire(placingIesProfileId, {
        x,
        y: room.height - 0.1,
        z
      })
      // Keep placing mode active for multiple placements
    }
  }, [isPlacing, placingIesProfileId, addLuminaire, room.height])
  
  // Convert luminaire positions for 3D viewer
  const customPositions = useMemo(() => {
    if (luminaires.length === 0) return undefined
    return luminaires.map(lum => ({
      x: lum.position.x,
      y: lum.position.y,
      z: lum.position.z,
      iesProfileId: lum.iesProfileId,
      dimming: lum.dimming,
      orientation: lum.rotation.orientation
    }))
  }, [luminaires])
  
  // Get the first IES profile for 3D viewer (it expects a single profile)
  const firstProfile = iesProfiles.length > 0 ? {
    id: iesProfiles[0].id,
    productName: iesProfiles[0].productName,
    variantLabel: iesProfiles[0].variantLabel,
    url: iesProfiles[0].url,
    lumens: iesProfiles[0].lumens ?? undefined,
    productSlug: iesProfiles[0].productSlug
  } : null
  
  if (viewMode === '2d') {
    return (
      <div className="relative h-full">
        <Viewer2D 
          className="h-full" 
          onPlaceLuminaire={handlePlaceLuminaire}
        />
        
        {/* Placement hint */}
        {isPlacing && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 px-4 py-2 bg-amber-100 text-amber-800 rounded-lg shadow-lg text-sm">
            Click anywhere on the room to place a luminaire
          </div>
        )}
      </div>
    )
  }
  
  // 3D View - only show luminaires if actually placed
  return (
    <div style={{ height: '100%', width: '100%' }} className="bg-gray-900">
      <RoomPlanner3DWrapper
        width={room.width}
        length={room.length}
        height={room.height}
        lights={luminaires.length}
        iesProfile={firstProfile}
        showHeatmap={displayOptions.showHeatmap && luminaires.length > 0}
        customPositions={customPositions}
      />
    </div>
  )
}

// =============================================================================
// Main Page Component
// =============================================================================

const WIZARD_DISMISSED_KEY = 'orbitx-planner-wizard-dismissed'

export interface ProPlannerProps {
  /** Target route/anchor for the "Back" / "Back to Home" links. */
  homeHref?: string
}

export default function ProPlanner({ homeHref = '#' }: ProPlannerProps = {}) {
  return <ProPlannerContent homeHref={homeHref} />
}

function ProPlannerContent({ homeHref }: { homeHref: string }) {
  // Wizard and quote modal state
  const [showWizard, setShowWizard] = useState(false)
  const [showQuoteModal, setShowQuoteModal] = useState(false)
  const [wizardChecked, setWizardChecked] = useState(false)
  const [importApplied, setImportApplied] = useState(false)
  
  // URL params for importing from the simple planner (framework-agnostic)
  const searchParams = useMemo(() => {
    if (typeof window === 'undefined') return new URLSearchParams()
    return new URLSearchParams(window.location.search)
  }, [])
  
  // Store actions
  const setRoom = usePlannerStore(state => state.setRoom)
  const createLuminaireGrid = usePlannerStore(state => state.createLuminaireGrid)
  const clearAllLuminaires = usePlannerStore(state => state.clearAllLuminaires)
  const setProjectName = usePlannerStore(state => state.setProjectName)
  const iesProfiles = usePlannerStore(state => state.iesProfiles)
  
  // Load IES profiles on mount
  const { profiles, loading: profilesLoading, error: profilesError } = usePlannerIESProfiles()
  
  // Calculation hook
  const {
    calculate,
    isCalculating,
    progress,
    progressMessage,
    error: calcError,
    estimatedTime,
    isQuickCalculation
  } = usePlannerCalculation({
    autoCalculate: true,
    debounceMs: 500,
    gridSpacing: 0.5
  })
  
  const luminaires = usePlannerStore(state => state.luminaires)
  const canCalculate = luminaires.length > 0 && profiles.length > 0
  
  // Import project from simple planner via URL params
  useEffect(() => {
    if (importApplied || profilesLoading || profiles.length === 0) return
    
    const importData = searchParams.get('import')
    if (!importData) {
      setImportApplied(true)
      return
    }
    
    try {
      const data = JSON.parse(decodeURIComponent(importData))
      
      // Apply room configuration
      if (data.room) {
        setRoom({
          width: data.room.width,
          length: data.room.length,
          height: data.room.height,
          name: data.room.name || 'Imported Room'
        })
        setProjectName(`${data.room.name || 'Imported'} Project`)
      }
      
      // Create luminaire grid
      if (data.lights && data.layout) {
        // Find the IES profile - try to match by ID first, then use first available
        let profileId = data.iesProfileId
        if (!profiles.find(p => p.id === profileId)) {
          profileId = profiles[0]?.id
        }
        
        if (profileId) {
          const { rows, cols } = data.layout
          const roomWidth = data.room?.width || 5
          const roomLength = data.room?.length || 5
          const roomHeight = data.room?.height || 2.7
          
          // Calculate spacing
          const spacingX = roomWidth / (cols + 1)
          const spacingZ = roomLength / (rows + 1)
          
          // Clear existing and create new grid
          clearAllLuminaires()
          createLuminaireGrid(profileId, rows, cols, spacingX, spacingZ, roomHeight - 0.1)
        }
      }
      
      // Don't show wizard since we imported a project
      localStorage.setItem(WIZARD_DISMISSED_KEY, 'true')
      setWizardChecked(true)
      
      // Remove import param from URL without reload
      const url = new URL(window.location.href)
      url.searchParams.delete('import')
      window.history.replaceState({}, '', url.toString())
      
    } catch (err) {
      console.error('Failed to import project:', err)
    }
    
    setImportApplied(true)
  }, [importApplied, profilesLoading, profiles, searchParams, setRoom, setProjectName, clearAllLuminaires, createLuminaireGrid])
  
  // Check if wizard should be shown on first visit
  useEffect(() => {
    if (wizardChecked || profilesLoading) return
    
    const dismissed = localStorage.getItem(WIZARD_DISMISSED_KEY)
    if (!dismissed) {
      setShowWizard(true)
    }
    setWizardChecked(true)
  }, [wizardChecked, profilesLoading])
  
  // Wizard callbacks
  const handleWizardComplete = useCallback(() => {
    setShowWizard(false)
    localStorage.setItem(WIZARD_DISMISSED_KEY, 'true')
  }, [])
  
  const handleWizardSkip = useCallback(() => {
    setShowWizard(false)
    localStorage.setItem(WIZARD_DISMISSED_KEY, 'true')
  }, [])
  
  const handleOpenWizard = useCallback(() => {
    setShowWizard(true)
  }, [])
  
  const handleOpenQuote = useCallback(() => {
    setShowQuoteModal(true)
  }, [])
  
  const handleCloseQuote = useCallback(() => {
    setShowQuoteModal(false)
  }, [])
  
  // Show loading state while profiles load
  if (profilesLoading) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center">
          <div className="w-12 h-12 border-3 border-blue-500 border-t-transparent rounded-full animate-spin mx-auto mb-4" />
          <p className="text-gray-600">Loading IES profiles...</p>
        </div>
      </div>
    )
  }
  
  // Show error if profiles failed to load
  if (profilesError) {
    return (
      <div className="h-screen flex items-center justify-center bg-gray-100">
        <div className="text-center max-w-md p-6 bg-white rounded-xl shadow-lg">
          <div className="w-12 h-12 bg-red-100 text-red-500 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-lg font-semibold text-gray-900 mb-2">Failed to Load Products</h2>
          <p className="text-gray-600 text-sm mb-4">{profilesError}</p>
          <a 
            href={homeHref}
            className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors"
          >
            Back to Home
          </a>
        </div>
      </div>
    )
  }
  
  return (
    <PlannerLayout
      header={<PlannerHeader onOpenQuote={handleOpenQuote} onOpenWizard={handleOpenWizard} homeHref={homeHref} />}
      leftPanel={<LeftPanel />}
      rightPanel={<RightPanel />}
      bottomBar={<QuickResultsBar />}
    >
      {/* Flex container for toolbar + viewer */}
      <div className="flex flex-col h-full">
        {/* Toolbar */}
        <Toolbar
          onCalculate={calculate}
          isCalculating={isCalculating}
          progress={progress}
          estimatedTime={estimatedTime}
          canCalculate={canCalculate}
        />
        
        {/* Main viewer area - takes remaining space */}
        <div className="flex-1 min-h-0">
          <MainViewer />
        </div>
      </div>
      
      {/* Calculation error toast */}
      {calcError && (
        <div className="absolute bottom-4 right-4 z-20 max-w-sm p-4 bg-red-50 border border-red-200 rounded-lg shadow-lg">
          <div className="flex items-start gap-3">
            <div className="w-5 h-5 text-red-500 flex-shrink-0 mt-0.5">
              <svg fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
              </svg>
            </div>
            <div>
              <h4 className="font-medium text-red-800">Calculation Error</h4>
              <p className="text-sm text-red-600 mt-1">{calcError}</p>
            </div>
          </div>
        </div>
      )}
      
      {/* Setup Wizard Modal */}
      {showWizard && (
        <SetupWizard
          onComplete={handleWizardComplete}
          onSkip={handleWizardSkip}
        />
      )}
      
      {/* Quote Request Modal */}
      <QuoteRequestModal
        isOpen={showQuoteModal}
        onClose={handleCloseQuote}
      />
    </PlannerLayout>
  )
}
