/**
 * OrbitX Lighting Planner - Smart Recommendations Engine
 * 
 * Calculates optimal luminaire layouts based on:
 * - Room dimensions
 * - Target illuminance from activity type
 * - Luminaire photometric data (IES)
 * - Surface reflectances
 */

import type { RoomConfig, IESData, ActivityRequirements, LuminaireInstance, CalculationResults } from './types'
import { getActivityRequirements } from './Standards'
import { calculateIlluminance } from './Calculator'
import { getMaintenanceFactor } from './Maintenance'

// =============================================================================
// Types
// =============================================================================

export interface LayoutRecommendation {
  /** Number of rows (along room length) */
  rows: number
  /** Number of columns (along room width) */
  cols: number
  /** Total luminaire count */
  total: number
  /** Spacing between luminaires */
  spacing: {
    x: number  // meters, along width
    z: number  // meters, along length
  }
  /** Dimming factor (0.1–1) applied to hit the target illuminance exactly. */
  dimming: number
  /** Predicted average illuminance */
  predictedEavg: number
  /** Predicted uniformity */
  predictedUo: number
  /** Confidence level (how accurate the prediction is likely to be) */
  confidence: 'high' | 'medium' | 'low'
  /** Human-readable recommendation text */
  summary: string
  /** Any warnings or notes */
  notes: string[]
}

export interface RecommendationInput {
  room: RoomConfig
  targetLux: number
  iesData: IESData
  maintenanceFactor?: number
}

// =============================================================================
// Main Recommendation Function
// =============================================================================

/**
 * Calculate recommended luminaire layout for a room.
 * Uses the Lumen Method (Zonal Cavity Method) for initial estimate,
 * then optimizes for uniformity.
 */
export function calculateRecommendedLayout(input: RecommendationInput): LayoutRecommendation {
  const { room, targetLux, iesData } = input

  const area = room.width * room.length
  const mf = input.maintenanceFactor ?? getMaintenanceFactor(room)
  const cu = calculateCoefficientOfUtilization(room, iesData)
  const lumensPerLuminaire = iesData.totalLumens

  if (lumensPerLuminaire <= 0) {
    return createFallbackRecommendation(room, targetLux)
  }

  // Lumen method gives the starting estimate; then iterate to converge.
  const estimate = Math.max(1, Math.ceil((targetLux * area) / (lumensPerLuminaire * cu * mf)))
  const mountingHeight = room.height - 0.1

  let rows = 1
  let cols = 1
  let results: CalculationResults | null = null
  let count = estimate

  // Grow the grid (one luminaire at a time) until it can reach the target,
  // then dim down to hit it exactly. Cap at 12 iterations.
  for (let iter = 0; iter < 12; iter++) {
    const grid = calculateOptimalGrid(room, count)
    rows = grid.rows
    cols = grid.cols
    const sim = simulateGrid(room, iesData, rows, cols, mountingHeight)
    results = sim.results
    if (results.Eavg >= targetLux) break
    count = rows * cols + 1
  }

  const eavgFull = results ? results.Eavg : 0
  const dimming = Math.max(0.1, Math.min(1, targetLux / Math.max(eavgFull, 1)))
  const predictedEavg = eavgFull * dimming
  const predictedUo = results ? results.Uo : 0.5
  const total = rows * cols

  let confidence: 'high' | 'medium' | 'low' = 'high'
  const notes: string[] = []

  if (dimming < 1) {
    notes.push(`Fixtures dimmed to ${Math.round(dimming * 100)}% to hit the ${targetLux} lux target`)
  }

  if (predictedUo < 0.4) {
    confidence = 'low'
    notes.push('Predicted uniformity is below 0.4 — consider more fixtures or closer spacing')
  } else if (predictedUo < 0.6) {
    confidence = 'medium'
    notes.push('Predicted uniformity is moderate — tighter spacing would improve it')
  }

  if (room.height < 2.5) {
    confidence = confidence === 'high' ? 'medium' : confidence
    notes.push('Low ceiling height may cause glare issues')
  }

  if (total > 50) {
    notes.push('Large installation — consider zone control for energy savings')
  }

  const summary = generateSummary(total, rows, cols, predictedEavg, targetLux, iesData)

  return {
    rows,
    cols,
    total,
    spacing: { x: room.width / cols, z: room.length / rows },
    dimming: Math.round(dimming * 100) / 100,
    predictedEavg: Math.round(predictedEavg),
    predictedUo: Math.round(predictedUo * 100) / 100,
    confidence,
    summary,
    notes,
  }
}

/**
 * Build a uniform grid of luminaires and run the real point-by-point +
 * radiosity calculation, returning the layout and its metrics.
 */
function simulateGrid(
  room: RoomConfig,
  iesData: IESData,
  rows: number,
  cols: number,
  mountingHeight: number
): { luminaires: LuminaireInstance[]; results: CalculationResults } {
  const spacingX = room.width / cols
  const spacingZ = room.length / rows
  const luminaires: LuminaireInstance[] = []

  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      luminaires.push({
        id: `rec-${r}-${c}`,
        iesProfileId: 'rec',
        position: {
          x: (c - (cols - 1) / 2) * spacingX,
          y: mountingHeight,
          z: (r - (rows - 1) / 2) * spacingZ,
        },
        rotation: { tilt: 0, orientation: 0, roll: 0 },
        dimming: 1,
      })
    }
  }

  const results = calculateIlluminance(room, luminaires, new Map([['rec', iesData]]), 0.5)
  return { luminaires, results }
}

/**
 * Quick recommendation result type
 */
export interface QuickRecommendation {
  count: number
  layout: { rows: number; cols: number }
  estimatedLux: number
  summary: string
}

/**
 * Get quick recommendation for activity type without detailed IES data.
 * Uses typical lumens and efficacy values for estimation.
 */
export function getQuickRecommendation(
  room: RoomConfig,
  targetLux: number,
  typicalLumens: number = 4000
): QuickRecommendation {
  const area = room.width * room.length
  
  // Simplified calculation with assumed CU of 0.5 and LLF of 0.8
  const count = Math.max(1, Math.ceil((targetLux * area) / (typicalLumens * 0.5 * 0.8)))
  
  // Calculate optimal grid
  const { rows, cols } = calculateOptimalGrid(room, count)
  const actualCount = rows * cols
  
  // Estimate lux with actual count
  const estimatedLux = Math.round((actualCount * typicalLumens * 0.5 * 0.8) / area)
  
  const summary = `${actualCount} luminaires arranged in a ${rows} x ${cols} grid will provide approximately ${estimatedLux} lux.`
  
  return {
    count: actualCount,
    layout: { rows, cols },
    estimatedLux,
    summary
  }
}

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Calculate Coefficient of Utilization using the physical definition: the
 * fraction of a luminaire's flux that reaches the work plane (direct +
 * inter-reflected), obtained by simulating a single representative luminaire
 * with the real point-by-point + radiosity engine.
 */
export function calculateCoefficientOfUtilization(room: RoomConfig, ies: IESData): number {
  if (ies.totalLumens <= 0) return 0.5

  const luminaire: LuminaireInstance = {
    id: 'cu-reference',
    iesProfileId: 'cu-reference',
    position: { x: 0, y: room.height - 0.1, z: 0 },
    rotation: { tilt: 0, orientation: 0, roll: 0 },
    dimming: 1,
  }

  const iesMap = new Map([['cu-reference', ies]])
  const probeRoom: RoomConfig = { ...room, maintenanceFactor: 1, includeReflections: true }
  const results = calculateIlluminance(probeRoom, [luminaire], iesMap, 0.5)

  const workPlaneArea = room.width * room.length
  const fluxOnWorkPlane = results.Eavg * workPlaneArea
  const cu = fluxOnWorkPlane / ies.totalLumens

  return Math.max(0.05, Math.min(0.95, cu))
}

/**
 * Calculate optimal grid dimensions for a given luminaire count.
 */
function calculateOptimalGrid(room: RoomConfig, targetCount: number): { rows: number; cols: number } {
  const aspectRatio = room.length / room.width
  
  // Find grid that best matches room aspect ratio
  let bestRows = 1
  let bestCols = targetCount
  let bestRatioDiff = Infinity
  
  for (let rows = 1; rows <= targetCount; rows++) {
    const cols = Math.ceil(targetCount / rows)
    const gridRatio = rows / cols
    const ratioDiff = Math.abs(gridRatio - aspectRatio)
    
    if (ratioDiff < bestRatioDiff) {
      bestRatioDiff = ratioDiff
      bestRows = rows
      bestCols = cols
    }
  }
  
  // Ensure minimum of 1 in each direction
  return {
    rows: Math.max(1, bestRows),
    cols: Math.max(1, bestCols)
  }
}

/**
 * Generate human-readable summary.
 */
function generateSummary(
  total: number,
  rows: number,
  cols: number,
  predictedEavg: number,
  targetLux: number,
  ies: IESData
): string {
  const gridText = rows === 1 || cols === 1 
    ? `${total} luminaire${total > 1 ? 's' : ''} in a row`
    : `${total} luminaires in a ${rows} x ${cols} grid`
  
  const luxComparison = predictedEavg >= targetLux
    ? `achieving ~${Math.round(predictedEavg)} lux (target: ${targetLux} lux)`
    : `providing ~${Math.round(predictedEavg)} lux (below target of ${targetLux} lux)`
  
  return `${gridText}, ${luxComparison}`
}

/**
 * Create fallback recommendation when IES data is insufficient.
 */
function createFallbackRecommendation(room: RoomConfig, targetLux: number): LayoutRecommendation {
  const area = room.width * room.length
  
  // Very rough estimate: 1 luminaire per 4-6 m² depending on target lux
  const m2PerLight = targetLux > 500 ? 4 : targetLux > 300 ? 5 : 6
  const total = Math.max(1, Math.ceil(area / m2PerLight))
  
  const { rows, cols } = calculateOptimalGrid(room, total)
  
  return {
    rows,
    cols,
    total: rows * cols,
    spacing: {
      x: room.width / (cols + 1),
      z: room.length / (rows + 1)
    },
    dimming: 1,
    predictedEavg: 0,
    predictedUo: 0.5,
    confidence: 'low',
    summary: `Approximately ${rows * cols} luminaires recommended (select a luminaire type for accurate calculation)`,
    notes: ['This is a rough estimate - select a luminaire for accurate calculation']
  }
}

// =============================================================================
// Adjustment Recommendations
// =============================================================================

/**
 * Get recommendations for improving an existing layout.
 */
export function getImprovementRecommendations(
  currentEavg: number,
  currentUo: number,
  targetEavg: number,
  targetUo: number,
  luminaireCount: number,
  room: RoomConfig
): string[] {
  const recommendations: string[] = []
  
  // Illuminance recommendations
  if (currentEavg < targetEavg * 0.9) {
    const deficit = ((targetEavg - currentEavg) / currentEavg) * 100
    const additionalNeeded = Math.ceil(luminaireCount * (targetEavg / currentEavg - 1))
    
    if (deficit > 30) {
      recommendations.push(`Add ${additionalNeeded} more luminaires to reach the ${targetEavg} lux target`)
    } else {
      recommendations.push(`Add ${additionalNeeded} luminaire${additionalNeeded > 1 ? 's' : ''} or increase dimming levels`)
    }
  } else if (currentEavg > targetEavg * 1.3) {
    recommendations.push('Consider reducing luminaire count or dimming to save energy')
  }
  
  // Uniformity recommendations
  if (currentUo < targetUo) {
    if (currentUo < 0.4) {
      recommendations.push('Uniformity is poor - reduce spacing between luminaires')
    } else if (currentUo < targetUo) {
      recommendations.push('Improve uniformity by adjusting luminaire positions or adding fixtures in dark areas')
    }
  }
  
  // General recommendations
  if (luminaireCount === 0) {
    recommendations.push('Add luminaires to begin the lighting design')
  }
  
  if (recommendations.length === 0 && currentEavg >= targetEavg && currentUo >= targetUo) {
    recommendations.push('Your design meets the requirements!')
  }
  
  return recommendations
}
