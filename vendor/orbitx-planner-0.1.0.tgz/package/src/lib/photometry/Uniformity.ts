/**
 * OrbitX Lighting Planner - Uniformity Calculations
 * 
 * Calculates uniformity metrics per lighting standards:
 * - Uo (Overall Uniformity) = Emin / Eavg
 * - Ud (Diversity) = Emin / Emax
 */

/**
 * Uniformity metrics result.
 */
export interface UniformityMetrics {
  Emin: number      // Minimum illuminance (lux)
  Emax: number      // Maximum illuminance (lux)
  Eavg: number      // Average illuminance (lux)
  Emedian: number   // Median illuminance (lux)
  Uo: number        // Overall uniformity (Emin/Eavg)
  Ud: number        // Diversity ratio (Emin/Emax)
}

/**
 * Calculate uniformity metrics from an array of illuminance values.
 */
export function calculateUniformityMetrics(illuminances: number[]): UniformityMetrics {
  if (illuminances.length === 0) {
    return {
      Emin: 0,
      Emax: 0,
      Eavg: 0,
      Emedian: 0,
      Uo: 0,
      Ud: 0
    }
  }
  
  // Calculate min, max, and sum
  let Emin = illuminances[0]
  let Emax = illuminances[0]
  let sum = 0
  
  for (const e of illuminances) {
    if (e < Emin) Emin = e
    if (e > Emax) Emax = e
    sum += e
  }
  
  // Calculate average
  const Eavg = sum / illuminances.length
  
  // Calculate median
  const sorted = [...illuminances].sort((a, b) => a - b)
  const mid = Math.floor(sorted.length / 2)
  const Emedian = sorted.length % 2 !== 0
    ? sorted[mid]
    : (sorted[mid - 1] + sorted[mid]) / 2
  
  // Calculate uniformity ratios
  const Uo = Eavg > 0 ? Emin / Eavg : 0
  const Ud = Emax > 0 ? Emin / Emax : 0
  
  return {
    Emin: roundTo(Emin, 1),
    Emax: roundTo(Emax, 1),
    Eavg: roundTo(Eavg, 1),
    Emedian: roundTo(Emedian, 1),
    Uo: roundTo(Uo, 3),
    Ud: roundTo(Ud, 3)
  }
}

/**
 * Check if uniformity meets a target value.
 */
export function checkUniformity(
  Uo: number,
  target: number
): { pass: boolean; margin: number } {
  const margin = Uo - target
  return {
    pass: Uo >= target,
    margin: roundTo(margin, 3)
  }
}

/**
 * Get uniformity rating description.
 */
export function getUniformityRating(Uo: number): string {
  if (Uo >= 0.8) return 'Excellent'
  if (Uo >= 0.6) return 'Good'
  if (Uo >= 0.4) return 'Acceptable'
  if (Uo >= 0.2) return 'Poor'
  return 'Very Poor'
}

/**
 * Calculate standard deviation of illuminance values.
 */
export function calculateStdDev(illuminances: number[], avg: number): number {
  if (illuminances.length <= 1) return 0
  
  let sumSquaredDiff = 0
  for (const e of illuminances) {
    const diff = e - avg
    sumSquaredDiff += diff * diff
  }
  
  return Math.sqrt(sumSquaredDiff / (illuminances.length - 1))
}

/**
 * Calculate coefficient of variation (CV).
 */
export function calculateCV(illuminances: number[]): number {
  if (illuminances.length === 0) return 0
  
  const { Eavg } = calculateUniformityMetrics(illuminances)
  if (Eavg === 0) return 0
  
  const stdDev = calculateStdDev(illuminances, Eavg)
  return stdDev / Eavg
}

/**
 * Get histogram of illuminance distribution.
 */
export function getIlluminanceHistogram(
  illuminances: number[],
  binCount: number = 10
): { min: number; max: number; count: number }[] {
  if (illuminances.length === 0) return []
  
  const min = Math.min(...illuminances)
  const max = Math.max(...illuminances)
  const range = max - min || 1
  const binSize = range / binCount
  
  const bins: { min: number; max: number; count: number }[] = []
  
  for (let i = 0; i < binCount; i++) {
    bins.push({
      min: min + i * binSize,
      max: min + (i + 1) * binSize,
      count: 0
    })
  }
  
  for (const e of illuminances) {
    const binIndex = Math.min(
      binCount - 1,
      Math.floor((e - min) / binSize)
    )
    bins[binIndex].count++
  }
  
  return bins
}

/**
 * Get percentile value from illuminance array.
 */
export function getPercentile(illuminances: number[], percentile: number): number {
  if (illuminances.length === 0) return 0
  
  const sorted = [...illuminances].sort((a, b) => a - b)
  const index = (percentile / 100) * (sorted.length - 1)
  const lower = Math.floor(index)
  const upper = Math.ceil(index)
  
  if (lower === upper) {
    return sorted[lower]
  }
  
  const fraction = index - lower
  return sorted[lower] + (sorted[upper] - sorted[lower]) * fraction
}

/**
 * Round to specified decimal places.
 */
function roundTo(value: number, decimals: number): number {
  const factor = Math.pow(10, decimals)
  return Math.round(value * factor) / factor
}
