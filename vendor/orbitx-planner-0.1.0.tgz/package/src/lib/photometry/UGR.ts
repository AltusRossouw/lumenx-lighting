/**
 * OrbitX Lighting Planner - UGR (Unified Glare Rating) Calculation
 *
 * CIE 117:1995 Unified Glare Rating:
 *
 *   UGR = 8 · log₁₀ [ (0.25 / Lb) · Σ (L² · ω / p²) ]
 *
 * where:
 *   L  = luminance of each luminaire's luminous parts toward the observer (cd/m²)
 *   ω  = solid angle of the luminous parts at the observer's eye (sr)
 *   p  = Guth position index
 *   Lb = background luminance (cd/m²), derived from the radiosity wall exitances
 */

import type { RoomConfig, LuminaireInstance, IESData, UGRResult } from './types'
import { getIntensity } from './IESParser'
import { directionToPhotometricAngles } from './Calculator'

// =============================================================================
// UGR Calculation
// =============================================================================

/**
 * Calculate UGR for a specific observer position and view direction.
 *
 * @param backgroundLuminance Background luminance in cd/m². When omitted, a
 *   conservative estimate is used; pass the radiosity-derived wall luminance
 *   for a proper CIE 117 result.
 */
export function calculateUGR(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>,
  observerPosition: { x: number; z: number },
  viewDirection: number, // degrees, 0 = looking toward -Z
  backgroundLuminance?: number
): number {
  // Observer eye height (1.2 m above the work plane for seated tasks).
  const eyeHeight = room.workPlaneHeight + 1.2

  const Lb = backgroundLuminance ?? estimateBackgroundLuminance(room, luminaires, iesDataMap)
  if (Lb <= 0) return 10

  // View direction (horizontal yaw), 0 = -Z.
  const viewRad = (viewDirection * Math.PI) / 180
  const viewX = Math.sin(viewRad)
  const viewZ = -Math.cos(viewRad)

  let sumGlare = 0

  for (const luminaire of luminaires) {
    if (luminaire.dimming <= 0) continue

    const ies = iesDataMap.get(luminaire.iesProfileId)
    if (!ies) continue

    // Vector from observer to luminaire.
    const ox = luminaire.position.x - observerPosition.x
    const oy = luminaire.position.y - eyeHeight
    const oz = luminaire.position.z - observerPosition.z
    const distSq = ox * ox + oy * oy + oz * oz
    const dist = Math.sqrt(distSq)

    // Luminaires below the eye are excluded from UGR.
    if (dist < 0.5 || oy <= 0) continue

    // --- Position index geometry ---
    const horizDist = Math.sqrt(ox * ox + oz * oz)

    // tau: angle from the vertical (deg).
    const tau = (Math.atan2(horizDist, oy) * 180) / Math.PI

    // sigma: horizontal angle from the line of sight (deg).
    const cosSigma = horizDist > 1e-6
      ? Math.max(-1, Math.min(1, (ox * viewX + oz * viewZ) / horizDist))
      : 0
    const sigma = (Math.acos(cosSigma) * 180) / Math.PI

    const p = guthPositionIndex(tau, sigma)
    if (p <= 0) continue

    // --- Luminance and solid angle toward the observer ---
    // Direction from luminaire to observer.
    const lumToObsX = -ox / dist
    const lumToObsY = -oy / dist
    const lumToObsZ = -oz / dist

    const { gamma, cPlane } = directionToPhotometricAngles(
      lumToObsX, lumToObsY, lumToObsZ, luminaire.rotation
    )

    const intensity = getIntensity(ies, gamma, cPlane) * luminaire.dimming
    if (intensity <= 0) continue

    // Luminous opening area. If the IES reports no area, assume 0.2 m².
    const lumArea = Math.max(0.001, ies.luminousWidth * ies.luminousLength || 0.2)

    // Projected area as seen by the observer: a down-facing opening seen at
    // angle gamma from nadir is foreshortened by cos(gamma).
    const cosGamma = Math.max(0.05, Math.cos((gamma * Math.PI) / 180))
    const projectedArea = lumArea * cosGamma

    const L = intensity / projectedArea // cd/m²
    const omega = projectedArea / distSq // sr

    sumGlare += (L * L * omega) / (p * p)
  }

  if (sumGlare <= 0) return 10

  const ugr = 8 * Math.log10((0.25 / Lb) * sumGlare)
  return Math.max(10, Math.min(30, Math.round(ugr * 10) / 10))
}

/**
 * Guth position index (CIE 117:1995, Iwata polynomial approximation).
 *
 *   p = exp[ (35.2 − 0.31889·τ − 1.22×10⁻³·τ²)·10⁻³·σ
 *          + (21 + 0.26667·τ − 0.002963·τ²)·10⁻⁵·σ² ]
 *
 * τ = angle from the vertical (deg), σ = angle from the line of sight (deg).
 */
export function guthPositionIndex(tau: number, sigma: number): number {
  const tau2 = tau * tau
  const sigma2 = sigma * sigma
  const A = (35.2 - 0.31889 * tau - 1.22e-3 * tau2) * 1e-3 * sigma
  const B = (21 + 0.26667 * tau - 0.002963 * tau2) * 1e-5 * sigma2
  return Math.exp(A + B)
}

/**
 * Fallback background-luminance estimate (used only when radiosity exitances
 * are unavailable). Treats the walls as a Lambertian reflector of the total
 * indirect flux.
 */
function estimateBackgroundLuminance(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>
): number {
  let totalLumens = 0
  for (const lum of luminaires) {
    const ies = iesDataMap.get(lum.iesProfileId)
    if (ies) totalLumens += ies.totalLumens * lum.dimming
  }

  const wallArea = 2 * (room.width + room.length) * room.height
  if (wallArea <= 0) return 0

  // Approximate indirect illuminance on the walls, then Lambertian luminance.
  const indirectIlluminance = (totalLumens * room.wallReflectance * 0.5) / wallArea
  return (indirectIlluminance * room.wallReflectance) / Math.PI
}

// =============================================================================
// Multi-Position UGR
// =============================================================================

/**
 * Calculate UGR at multiple standard observer positions and return the
 * worst-case (highest) value.
 *
 * @param surfaceExitances Optional 6-element radiosity exitance array
 *   (lm/m²) indexed by SurfaceType, used to derive a real background luminance.
 */
export function calculateWorstCaseUGR(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>,
  surfaceExitances?: number[]
): { worstUGR: number; positions: UGRResult[] } {
  // Background luminance from the average wall exitance (Lambertian surfaces).
  let Lb: number | undefined
  if (surfaceExitances && surfaceExitances.length >= 6) {
    const wallExitance =
      (surfaceExitances[2] + surfaceExitances[3] + surfaceExitances[4] + surfaceExitances[5]) / 4
    Lb = wallExitance / Math.PI
  }

  const positions = getStandardObserverPositions(room)
  const viewDirections = [0, 90, 180, 270]

  const results: UGRResult[] = []
  let worstUGR = 10

  for (const pos of positions) {
    for (const dir of viewDirections) {
      const ugr = calculateUGR(room, luminaires, iesDataMap, pos, dir, Lb)

      results.push({ position: pos, viewDirection: dir, value: ugr })
      if (ugr > worstUGR) worstUGR = ugr
    }
  }

  return { worstUGR, positions: results }
}

/**
 * Standard observer positions: room center, corners, and mid-edges (1 m inset).
 */
function getStandardObserverPositions(room: RoomConfig): { x: number; z: number }[] {
  const { width, length } = room
  const margin = 1.0

  const positions: { x: number; z: number }[] = [{ x: 0, z: 0 }]

  if (width > 3 && length > 3) {
    const hw = width / 2 - margin
    const hl = length / 2 - margin
    positions.push({ x: -hw, z: -hl }, { x: hw, z: -hl }, { x: -hw, z: hl }, { x: hw, z: hl })
  }

  if (width > 6 || length > 6) {
    const hw = width / 2 - margin
    const hl = length / 2 - margin
    positions.push({ x: 0, z: -hl }, { x: 0, z: hl }, { x: -hw, z: 0 }, { x: hw, z: 0 })
  }

  return positions
}

// =============================================================================
// UGR Rating
// =============================================================================

export function getUGRRating(ugr: number): string {
  if (ugr <= 13) return 'Excellent (suitable for precision work)'
  if (ugr <= 16) return 'Good (suitable for reading/writing)'
  if (ugr <= 19) return 'Acceptable (office work)'
  if (ugr <= 22) return 'Moderate (industrial)'
  if (ugr <= 25) return 'Poor (rough work)'
  if (ugr <= 28) return 'Very Poor (circulation only)'
  return 'Unacceptable'
}

export function checkUGRCompliance(ugr: number, target: number): { pass: boolean; margin: number } {
  return { pass: ugr <= target, margin: target - ugr }
}

export function getRecommendedUGRLimit(activity: string): number {
  const limits: Record<string, number> = {
    precision: 13,
    'technical-drawing': 16,
    office: 19,
    reading: 19,
    classroom: 19,
    retail: 22,
    workshop: 22,
    assembly: 22,
    industrial: 25,
    warehouse: 25,
    corridor: 28,
    stairs: 28,
  }
  return limits[activity.toLowerCase()] ?? 22
}
