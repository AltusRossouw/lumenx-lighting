/**
 * OrbitX Lighting Planner - Maintenance Factors (Light Loss Factors)
 *
 * The maintained illuminance is the design illuminance multiplied by the
 * maintenance factor MF = LLMF × LSF × LMF × RSMF (CIE 97 / EN 12464-1):
 *
 *   LLMF  Lamp Lumen Maintenance Factor  — LED lumen depreciation (LM-80/TM-21)
 *   LSF   Lamp Survival Factor           — fraction of sources still operating
 *   LMF   Luminaire Maintenance Factor   — dirt on the luminaire optics/housing
 *   RSMF  Room Surface Maintenance Factor — dirt on walls/ceiling/floor
 *
 * Values below are representative defaults; LLMF/LSF should be taken from the
 * manufacturer's LM-80 / TM-21 projection for the specific product.
 */

import type { MaintenanceFactors, RoomConfig } from './types'

export interface MaintenancePreset {
  id: string
  name: string
  description: string
  factors: MaintenanceFactors
}

export const MAINTENANCE_PRESETS: MaintenancePreset[] = [
  {
    id: 'very-clean',
    name: 'Very clean',
    description: 'Air-conditioned offices, labs, clinics',
    factors: { llmf: 0.96, lsf: 1.0, lmf: 0.94, rsmf: 0.95 },
  },
  {
    id: 'clean',
    name: 'Clean',
    description: 'Normal offices, retail, schools',
    factors: { llmf: 0.92, lsf: 1.0, lmf: 0.88, rsmf: 0.90 },
  },
  {
    id: 'normal',
    name: 'Normal',
    description: 'Light industry, warehouses',
    factors: { llmf: 0.89, lsf: 1.0, lmf: 0.82, rsmf: 0.85 },
  },
  {
    id: 'dirty',
    name: 'Dirty',
    description: 'Dusty, moist or polluted environments',
    factors: { llmf: 0.86, lsf: 0.98, lmf: 0.74, rsmf: 0.80 },
  },
  {
    id: 'custom',
    name: 'Custom',
    description: 'Manually set each factor',
    factors: { llmf: 0.9, lsf: 1.0, lmf: 0.85, rsmf: 0.88 },
  },
]

/** Multiply the four loss factors into the single maintenance factor. */
export function calculateMaintenanceFactor(factors: MaintenanceFactors): number {
  return factors.llmf * factors.lsf * factors.lmf * factors.rsmf
}

/**
 * Resolve the maintenance factor for a room: uses the detailed breakdown when
 * present, otherwise falls back to the legacy flat value.
 */
export function getMaintenanceFactor(room: Pick<RoomConfig, 'maintenanceFactors' | 'maintenanceFactor'>): number {
  if (room.maintenanceFactors) {
    return calculateMaintenanceFactor(room.maintenanceFactors)
  }
  return room.maintenanceFactor ?? 0.8
}

/** Default maintenance breakdown (≈ the legacy 0.8 flat factor). */
export const DEFAULT_MAINTENANCE_FACTORS: MaintenanceFactors = {
  llmf: 0.92,
  lsf: 1.0,
  lmf: 0.88,
  rsmf: 0.99,
}
