/**
 * OrbitX Lighting Planner - Point-by-Point Calculator
 * 
 * Calculates illuminance at each grid point on the work plane
 * using the inverse square law with cosine correction.
 * 
 * Features:
 * - Point-by-point direct illuminance calculation
 * - Inter-reflection calculation (simplified radiosity)
 * - Maintenance factor support
 * - Configurable grid resolution
 */

import type {
  RoomConfig,
  LuminaireInstance,
  IESData,
  CalculationPoint,
  CalculationGrid,
  CalculationResults
} from './types'
import { getIntensity } from './IESParser'
import { calculateUniformityMetrics } from './Uniformity'
import { getMaintenanceFactor } from './Maintenance'

import { solveRadiosity, integrateSurfaceContribution } from './Radiosity'

// =============================================================================
// Constants
// =============================================================================

/** Patch subdivisions (per axis) used when numerically integrating reflected light. */
const REFLECTION_SUBDIVISIONS = 8

// =============================================================================
// Main Calculation Function
// =============================================================================

/**
 * Calculate illuminance at all grid points on the work plane.
 * 
 * @param room Room configuration
 * @param luminaires Array of placed luminaires
 * @param iesDataMap Map of IES profile ID to parsed IES data
 * @param gridSpacing Spacing between grid points in meters (default 0.5m)
 * @param onProgress Optional callback for progress updates
 * @returns Complete calculation results
 */
export function calculateIlluminance(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>,
  gridSpacing: number = 0.5,
  onProgress?: (percent: number, message?: string) => void
): CalculationResults {
  const startTime = performance.now()
  
  // Convert Record to Map if needed
  const iesMap = iesDataMap instanceof Map 
    ? iesDataMap 
    : new Map(Object.entries(iesDataMap))
  
  // Resolve maintenance factor (detailed LLMF×LSF×LMF×RSMF breakdown, or legacy flat).
  const maintenanceFactor = getMaintenanceFactor(room)
  const includeReflections = room.includeReflections ?? true
  
  // Create calculation grid
  const grid = createCalculationGrid(room, gridSpacing)
  
  onProgress?.(5, 'Grid created')
  
  // Calculate direct illuminance at each point
  const totalPoints = grid.points.length
  const activeLuminaires = luminaires.filter(l => l.dimming > 0)
  
  for (let i = 0; i < totalPoints; i++) {
    const point = grid.points[i]
    point.illuminance = calculatePointIlluminance(
      point,
      room,
      activeLuminaires,
      iesMap
    )
    
    // Report progress every 10%
    if (i % Math.ceil(totalPoints / 10) === 0) {
      const percent = 5 + Math.round((i / totalPoints) * 60)
      onProgress?.(percent, `Calculating point ${i + 1} of ${totalPoints}`)
    }
  }
  
  onProgress?.(70, 'Direct illuminance complete')
  
  // Calculate inter-reflections if enabled
  if (includeReflections && activeLuminaires.length > 0) {
    onProgress?.(72, 'Solving surface exitances (radiosity)...')
    const exitances = computeSurfaceExitances(room, activeLuminaires, iesMap)
    const surfaces = getSurfaceGeometries(room)

    onProgress?.(85, 'Adding reflected component...')
    for (let i = 0; i < totalPoints; i++) {
      const point = grid.points[i]
      const P = { x: point.x, y: room.workPlaneHeight, z: point.z }

      let reflected = 0
      for (let s = 0; s < surfaces.length; s++) {
        const exitance = exitances[s]
        if (exitance <= 0) continue
        const geom = surfaces[s]
        reflected += integrateSurfaceContribution(
          P,
          geom.origin,
          geom.uVec,
          geom.vVec,
          geom.normal,
          exitance,
          REFLECTION_SUBDIVISIONS
        )
      }
      point.illuminance += reflected
    }
    onProgress?.(90, 'Reflections complete')
  } else {
    onProgress?.(90, 'Reflections skipped')
  }
  
  // Apply maintenance factor
  for (let i = 0; i < totalPoints; i++) {
    grid.points[i].illuminance *= maintenanceFactor
  }
  
  onProgress?.(90, 'Computing metrics')
  
  // Calculate uniformity metrics
  const illuminances = grid.points.map(p => p.illuminance)
  const metrics = calculateUniformityMetrics(illuminances)
  
  // Calculate power metrics
  let totalPower = 0
  let totalLumens = 0
  
  luminaires.forEach(lum => {
    const ies = iesMap.get(lum.iesProfileId)
    if (ies) {
      totalPower += ies.inputWatts * lum.dimming
      totalLumens += ies.totalLumens * lum.dimming
    }
  })
  
  const area = room.width * room.length
  const powerDensity = area > 0 ? totalPower / area : 0
  
  // LENI (EN 15193): kWh/m²/year = power density × annual operating hours / 1000.
  const operatingHours = room.operatingHours ?? 2500
  const LENI = (powerDensity * operatingHours) / 1000
  
  onProgress?.(100, 'Complete')
  
  const calculationTime = performance.now() - startTime
  
  return {
    grid,
    
    Emin: metrics.Emin,
    Emax: metrics.Emax,
    Eavg: metrics.Eavg,
    Emedian: metrics.Emedian,
    
    Uo: metrics.Uo,
    Ud: metrics.Ud,
    
    totalPower,
    powerDensity,
    LENI,

    maintenanceFactor,
    
    luminaireCount: luminaires.length,
    totalLumens,
    
    calculatedAt: new Date().toISOString(),
    calculationTime
  }
}

// =============================================================================
// Grid Creation
// =============================================================================

/**
 * Create the calculation grid on the work plane.
 */
export function createCalculationGrid(
  room: RoomConfig,
  gridSpacing: number = 0.5
): CalculationGrid {
  const { width, length, workPlaneHeight } = room
  
  // Calculate grid dimensions
  // Grid starts at half-spacing from walls
  const gridWidth = Math.max(1, Math.floor(width / gridSpacing))
  const gridHeight = Math.max(1, Math.floor(length / gridSpacing))
  
  // Actual spacing to fit evenly
  const actualSpacingX = width / (gridWidth + 1)
  const actualSpacingZ = length / (gridHeight + 1)
  
  const points: CalculationPoint[] = []
  
  // Create grid points centered in the room
  // Room coordinates: center is (0, 0), extends from -width/2 to +width/2
  for (let zi = 1; zi <= gridHeight; zi++) {
    for (let xi = 1; xi <= gridWidth; xi++) {
      const x = (xi * actualSpacingX) - (width / 2)
      const z = (zi * actualSpacingZ) - (length / 2)
      
      points.push({
        x,
        z,
        illuminance: 0
      })
    }
  }
  
  return {
    points,
    gridWidth,
    gridHeight,
    gridSpacing,
    roomWidth: width,
    roomLength: length,
    workPlaneHeight
  }
}

// =============================================================================
// Point Illuminance Calculation
// =============================================================================

/**
 * Calculate illuminance at a single point from all luminaires.
 */
export function calculatePointIlluminance(
  point: CalculationPoint,
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>
): number {
  let totalIlluminance = 0
  
  for (const luminaire of luminaires) {
    const ies = iesDataMap.get(luminaire.iesProfileId)
    if (!ies || luminaire.dimming <= 0) continue
    
    const contribution = calculateSingleLuminaireContribution(
      point,
      room,
      luminaire,
      ies
    )
    
    totalIlluminance += contribution * luminaire.dimming
  }
  
  return totalIlluminance
}

/**
 * Calculate illuminance contribution from a single luminaire to a point using
 * the inverse-square law with cosine correction:
 *
 *   E = I(γ, C) · cosθ / d²
 *
 * γ and C are resolved in the luminaire's own photometric frame (accounting
 * for orientation, tilt and roll), so the correct IES candela value is used.
 *
 * @param point Target point coordinates (x, z required; y optional)
 * @param room Room configuration (work-plane height reference)
 * @param luminaire The luminaire instance (world position + rotation)
 * @param ies IES photometry data
 * @param normal Receiving surface normal (default: up-facing horizontal plane)
 */
export function calculateSingleLuminaireContribution(
  point: CalculationPoint | { x: number, z: number, y?: number },
  room: RoomConfig,
  luminaire: LuminaireInstance,
  ies: IESData,
  normal: { x: number, y: number, z: number } = { x: 0, y: 1, z: 0 }
): number {
  // World coordinates use absolute Y: 0 = floor, room.height = ceiling.
  const px = point.x
  const py = ('y' in point && typeof point.y === 'number') ? point.y : room.workPlaneHeight
  const pz = point.z

  const lx = luminaire.position.x
  const ly = luminaire.position.y
  const lz = luminaire.position.z

  // Vector from luminaire to point.
  const dx = px - lx
  const dy = py - ly
  const dz = pz - lz

  const distanceSquared = dx * dx + dy * dy + dz * dz
  const distance = Math.sqrt(distanceSquared)
  if (distance < 0.01) return 0

  const dirX = dx / distance
  const dirY = dy / distance
  const dirZ = dz / distance

  const { gamma, cPlane } = directionToPhotometricAngles(dirX, dirY, dirZ, luminaire.rotation)

  const intensity = getIntensity(ies, gamma, cPlane)
  if (intensity <= 0) return 0

  // Cosine of the incidence angle onto the receiving surface.
  // The ray travels along (dirX, dirY, dirZ) from the luminaire to the point;
  // a front-facing surface has normal · dir < 0.
  const cosIncidence = Math.max(0, -(dirX * normal.x + dirY * normal.y + dirZ * normal.z))

  return (intensity * cosIncidence) / distanceSquared
}

/**
 * Convert a world-space direction (luminaire → point) into the luminaire's
 * local photometric frame and return the IES angles:
 *   - gamma: from nadir (0° = straight down, 90° = horizontal)
 *   - cPlane: horizontal C-plane angle (0° along the local +Z reference)
 *
 * Rotation convention (intrinsic yaw → pitch → roll):
 *   - orientation: yaw about the world Y axis (0° keeps +Z as the C0 reference)
 *   - tilt: pitch about the local X axis (positive aims the beam toward +Z)
 *   - roll: spin about the local Y (nadir) axis
 */
export function directionToPhotometricAngles(
  dx: number,
  dy: number,
  dz: number,
  rotation: { tilt: number; orientation: number; roll: number }
): { gamma: number; cPlane: number } {
  const orient = (rotation.orientation * Math.PI) / 180
  const tilt = (rotation.tilt * Math.PI) / 180
  const roll = (rotation.roll * Math.PI) / 180

  // 1) Undo yaw (orientation) about world Y.
  const cosO = Math.cos(orient)
  const sinO = Math.sin(orient)
  const x1 = cosO * dx - sinO * dz
  const y1 = dy
  const z1 = sinO * dx + cosO * dz

  // 2) Undo pitch (tilt) about local X.
  const cosT = Math.cos(tilt)
  const sinT = Math.sin(tilt)
  const x2 = x1
  const y2 = cosT * y1 - sinT * z1
  const z2 = sinT * y1 + cosT * z1

  // 3) Undo roll (spin) about local Y.
  const cosR = Math.cos(roll)
  const sinR = Math.sin(roll)
  const x3 = cosR * x2 - sinR * z2
  const y3 = y2
  const z3 = sinR * x2 + cosR * z2

  // gamma measured from nadir (local -Y).
  const gamma = Math.acos(Math.max(-1, Math.min(1, -y3))) * (180 / Math.PI)
  const cPlane = (Math.atan2(x3, z3) * (180 / Math.PI) + 360) % 360

  return { gamma, cPlane }
}

/**
 * Calculates the initial direct luminous flux (lumens) landing on each of the 6 room surfaces.
 * Used to initialize the radiosity solver.
 */
export function calculateInitialSurfaceFlux(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData>
): number[] {
  // Surface indices matching SurfaceType in Radiosity.ts:
  // 0: Floor, 1: Ceiling, 2: North(-Z), 3: South(+Z), 4: East(+X), 5: West(-X)
  
  const fluxes = [0, 0, 0, 0, 0, 0]
  
  // Define sampling resolution (points per dimension)
  // Higher = more accurate initial distribution, slower
  const SAMPLES_X = 6
  const SAMPLES_Y = 4
  const SAMPLES_Z = 6
  
  // Helper to integrate illuminance over a surface
  const integrateSurface = (
    uSteps: number, 
    vSteps: number, 
    origin: {x:number, y:number, z:number},
    uVec: {x:number, y:number, z:number}, // Step vector U
    vVec: {x:number, y:number, z:number}, // Step vector V
    normal: {x:number, y:number, z:number}
  ) => {
    let totalE = 0
    const pointCount = uSteps * vSteps
    
    // Step sizes
    const du = { x: uVec.x / uSteps, y: uVec.y / uSteps, z: uVec.z / uSteps }
    const dv = { x: vVec.x / vSteps, y: vVec.y / vSteps, z: vVec.z / vSteps }
    
    // Area of one patch
    const patchArea = Math.sqrt(
      (du.x*du.x + du.y*du.y + du.z*du.z) * 
      (dv.x*dv.x + dv.y*dv.y + dv.z*dv.z) // Approximate rectangular patch area
      // Actually strictly: |du x dv|
      // For axis aligned, simple multiply
    )
    
    // We actually assume patches are uniform size
    // Just sum illuminance at centers and multiply by TotalArea / Count
    // Or sum (E * patchArea)
    
    for (let i = 0; i < uSteps; i++) {
      for (let j = 0; j < vSteps; j++) {
        // Center of patch
        const p = {
          x: origin.x + du.x * (i + 0.5) + dv.x * (j + 0.5),
          y: origin.y + du.y * (i + 0.5) + dv.y * (j + 0.5),
          z: origin.z + du.z * (i + 0.5) + dv.z * (j + 0.5)
        }
        
        // Sum illuminance from all lights
        let E = 0
        for (const lum of luminaires) {
          const ies = iesDataMap.get(lum.iesProfileId)
          if (ies && lum.dimming > 0) {
            E += calculateSingleLuminaireContribution(
              { x: p.x, z: p.z, y: p.y }, // Pass y explicitly
              room,
              lum,
              ies,
              normal
            ) * lum.dimming
          }
        }
        totalE += E
      }
    }
    
    // Average Illuminance * Total Area
    // = (Sum E / Count) * Total Area
    // = Sum E * (Total Area / Count)
    // = Sum E * PatchArea
    
    // Calculate exact area of surface defined by vectors
    const Ulen = Math.sqrt(uVec.x*uVec.x + uVec.y*uVec.y + uVec.z*uVec.z)
    const Vlen = Math.sqrt(vVec.x*vVec.x + vVec.y*vVec.y + vVec.z*vVec.z)
    const totalArea = Ulen * Vlen
    
    return totalE * (totalArea / pointCount)
  }
  
// 0: Floor (y=0)
  fluxes[0] = integrateSurface(
    SAMPLES_X, SAMPLES_Z,
    { x: -room.width/2, y: 0, z: -room.length/2 },
    { x: room.width, y: 0, z: 0 },
    { x: 0, y: 0, z: room.length },
    { x: 0, y: 1, z: 0 }
  )
  
  // 1: Ceiling (y=height)
  fluxes[1] = integrateSurface(
    SAMPLES_X, SAMPLES_Z,
    { x: -room.width/2, y: room.height, z: -room.length/2 },
    { x: room.width, y: 0, z: 0 },
    { x: 0, y: 0, z: room.length },
    { x: 0, y: -1, z: 0 }
  )
  
  // 2: Wall North (-Z)
  fluxes[2] = integrateSurface(
    SAMPLES_X, SAMPLES_Y,
    { x: -room.width/2, y: 0, z: -room.length/2 },
    { x: room.width, y: 0, z: 0 },
    { x: 0, y: room.height, z: 0 },
    { x: 0, y: 0, z: 1 }
  )
  
  // 3: Wall South (+Z)
  fluxes[3] = integrateSurface(
    SAMPLES_X, SAMPLES_Y,
    { x: -room.width/2, y: 0, z: room.length/2 },
    { x: room.width, y: 0, z: 0 },
    { x: 0, y: room.height, z: 0 },
    { x: 0, y: 0, z: -1 }
  )
  
  // 4: Wall East (+X)
  fluxes[4] = integrateSurface(
    SAMPLES_Z, SAMPLES_Y,
    { x: room.width/2, y: 0, z: -room.length/2 },
    { x: 0, y: 0, z: room.length },
    { x: 0, y: room.height, z: 0 },
    { x: -1, y: 0, z: 0 }
  )
  
  // 5: Wall West (-X)
  fluxes[5] = integrateSurface(
    SAMPLES_Z, SAMPLES_Y,
    { x: -room.width/2, y: 0, z: -room.length/2 },
    { x: 0, y: 0, z: room.length },
    { x: 0, y: room.height, z: 0 },
    { x: 1, y: 0, z: 0 }
  )
  
  return fluxes
}

// =============================================================================
// Surface Geometry & Radiosity
// =============================================================================

/** Geometric description of one of the 6 room surfaces. */
export interface SurfaceGeometry {
  origin: { x: number; y: number; z: number }
  uVec: { x: number; y: number; z: number }
  vVec: { x: number; y: number; z: number }
  normal: { x: number; y: number; z: number }
}

/**
 * The 6 room surfaces indexed by SurfaceType:
 * 0 Floor, 1 Ceiling, 2 North(-Z), 3 South(+Z), 4 East(+X), 5 West(-X).
 * Normals point into the room.
 */
export function getSurfaceGeometries(room: RoomConfig): SurfaceGeometry[] {
  const { width, length, height } = room
  const hw = width / 2
  const hl = length / 2
  return [
    { origin: { x: -hw, y: 0, z: -hl }, uVec: { x: width, y: 0, z: 0 }, vVec: { x: 0, y: 0, z: length }, normal: { x: 0, y: 1, z: 0 } },
    { origin: { x: -hw, y: height, z: -hl }, uVec: { x: width, y: 0, z: 0 }, vVec: { x: 0, y: 0, z: length }, normal: { x: 0, y: -1, z: 0 } },
    { origin: { x: -hw, y: 0, z: -hl }, uVec: { x: width, y: 0, z: 0 }, vVec: { x: 0, y: height, z: 0 }, normal: { x: 0, y: 0, z: 1 } },
    { origin: { x: -hw, y: 0, z: hl }, uVec: { x: width, y: 0, z: 0 }, vVec: { x: 0, y: height, z: 0 }, normal: { x: 0, y: 0, z: -1 } },
    { origin: { x: hw, y: 0, z: -hl }, uVec: { x: 0, y: 0, z: length }, vVec: { x: 0, y: height, z: 0 }, normal: { x: -1, y: 0, z: 0 } },
    { origin: { x: -hw, y: 0, z: -hl }, uVec: { x: 0, y: 0, z: length }, vVec: { x: 0, y: height, z: 0 }, normal: { x: 1, y: 0, z: 0 } },
  ]
}

/**
 * Compute the final luminous exitance (lm/m²) of each of the 6 surfaces by
 * first calculating the direct flux landing on each surface, then solving the
 * radiosity equations for inter-reflections.
 */
export function computeSurfaceExitances(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>
): number[] {
  const iesMap = iesDataMap instanceof Map ? iesDataMap : new Map(Object.entries(iesDataMap))
  const initialFluxes = calculateInitialSurfaceFlux(room, luminaires, iesMap)
  return solveRadiosity(room, initialFluxes)
}

// =============================================================================
// Helper Functions
// =============================================================================

/**
 * Helper to round a number to a specific number of decimal places.
 */
function roundTo(value: number, decimals: number): number {
  const factor = Math.pow(10, decimals)
  return Math.round(value * factor) / factor
}

/**
 * Get the illuminance at a specific point on the grid.
 * Useful for inspecting specific locations.
 */
export function getIlluminanceAt(
  grid: CalculationGrid,
  x: number,
  z: number
): number {
  // Find the closest grid point
  // Simple search for now, could be optimized with grid indexing
  let minDist = Infinity
  let closestPoint = grid.points[0]
  
  for (const point of grid.points) {
    const dist = (point.x - x) * (point.x - x) + (point.z - z) * (point.z - z)
    if (dist < minDist) {
      minDist = dist
      closestPoint = point
    }
  }
  
  return closestPoint ? closestPoint.illuminance : 0
}

/**
 * Find the points with minimum and maximum illuminance.
 */
export function findMinMaxPoints(grid: CalculationGrid): { 
  min: CalculationPoint, 
  max: CalculationPoint 
} {
  if (grid.points.length === 0) {
    throw new Error('Grid has no points')
  }
  
  let min = grid.points[0]
  let max = grid.points[0]
  
  for (const point of grid.points) {
    if (point.illuminance < min.illuminance) min = point
    if (point.illuminance > max.illuminance) max = point
  }
  
  return { min, max }
}


