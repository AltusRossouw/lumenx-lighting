/**
 * OrbitX Lighting Planner - Calculation Web Worker
 *
 * Thin orchestration layer. All photometric math lives in the shared modules
 * (Calculator.ts, UGR.ts, Vertical.ts) via `runCalculation`, so the worker and
 * any synchronous fallback use exactly the same, single source of truth.
 */

import type {
  CalculationWorkerInput,
  CalculationWorkerOutput,
  IESData
} from './types'
import { runCalculation } from './runCalculation'

self.onmessage = (event: MessageEvent<CalculationWorkerInput>) => {
  const { type, room, luminaires, iesDataMap, gridSpacing, calculateUGR } = event.data

  if (type !== 'calculate') {
    self.postMessage({ type: 'error', message: 'Unknown message type' } as CalculationWorkerOutput)
    return
  }

  try {
    const iesMap = new Map<string, IESData>(Object.entries(iesDataMap))

    const results = runCalculation(
      room,
      luminaires,
      iesMap,
      { gridSpacing, calculateUGR },
      (percent, message) => self.postMessage({ type: 'progress', percent, message } as CalculationWorkerOutput)
    )

    self.postMessage({ type: 'complete', results } as CalculationWorkerOutput)
  } catch (error) {
    const message = error instanceof Error ? error.message : 'Unknown calculation error'
    self.postMessage({ type: 'error', message } as CalculationWorkerOutput)
  }
}

export {}
