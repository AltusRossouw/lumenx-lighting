/**
 * OrbitX Lighting Planner - IES File Parser
 * 
 * Complete IESNA LM-63 format parser that extracts full photometric data
 * including the candela intensity distribution table.
 */

import type { IESData, IESProfile } from './types'

// =============================================================================
// IES File Parsing
// =============================================================================

/**
 * Fetch and parse an IES file from a URL.
 * Returns complete photometric data including intensity distribution.
 */
export async function fetchAndParseIES(url: string): Promise<IESData> {
  const response = await fetch(url)
  if (!response.ok) {
    throw new Error(`Failed to fetch IES file: ${response.status} ${response.statusText}`)
  }
  
  const content = await response.text()
  return parseIESContent(content, url)
}

/**
 * Parse IES file content string into structured data.
 */
export function parseIESContent(content: string, sourceUrl: string = ''): IESData {
  const lines = content.split(/\r?\n/)
  
  // Extract metadata from keyword lines
  const metadata = extractMetadata(lines)
  
  // Find TILT line (marks end of metadata)
  const tiltIndex = lines.findIndex(line => 
    line.trim().toUpperCase().startsWith('TILT=')
  )
  
  if (tiltIndex === -1) {
    throw new Error('Invalid IES file: TILT line not found')
  }
  
  // Parse numeric data after TILT line
  const numericLines = lines.slice(tiltIndex + 1)
  const tokens = numericLines
    .map(line => line.trim())
    .filter(Boolean)
    .join(' ')
    .split(/\s+/)
    .map(t => parseFloat(t))
    .filter(n => !isNaN(n))
  
  let cursor = 0
  const read = () => tokens[cursor++] ?? 0
  const readInt = () => Math.round(read())
  
  // Parse photometric data header
  // Line 1: lamp count, lumens/lamp, multiplier, #vert angles, #horiz angles,
  //         photometric type, units, width, length, height
  const lampCount = read()
  const lumensPerLamp = read()
  const candelaMultiplier = read()
  const numVerticalAngles = readInt()
  const numHorizontalAngles = readInt()
  const photometricType = readInt()
  const unitsType = readInt()
  const width = read()
  const length = read()
  const height = read()
  
  // Line 2: ballast factor, future use (usually 1), input watts
  const ballastFactor = read()
  read() // future use, skip
  const inputWatts = read()
  
  // Validate essential values
  if (numVerticalAngles <= 0 || numHorizontalAngles <= 0) {
    throw new Error('Invalid IES file: Invalid angle counts')
  }
  
  // Parse vertical angles (gamma)
  const verticalAngles: number[] = []
  for (let i = 0; i < numVerticalAngles; i++) {
    verticalAngles.push(read())
  }
  
  // Parse horizontal angles (C-planes)
  const horizontalAngles: number[] = []
  for (let i = 0; i < numHorizontalAngles; i++) {
    horizontalAngles.push(read())
  }
  
  // Parse candela values [horizontal][vertical]
  // IES format stores values in cd/1000lm, we keep them as-is
  const candelaValues: number[][] = []
  for (let h = 0; h < numHorizontalAngles; h++) {
    const row: number[] = []
    for (let v = 0; v < numVerticalAngles; v++) {
      row.push(read())
    }
    candelaValues.push(row)
  }
  
  // Convert dimensions to meters if in feet
  const toMeters = unitsType === 1 ? 0.3048 : 1
  const widthM = width * toMeters
  const lengthM = length * toMeters
  const heightM = height * toMeters
  
  // Calculate derived values.
  // NOTE: per IES LM-63, `candelaMultiplier` scales the *candela* values
  // (which are stored per 1000 lm), NOT the rated luminous flux.
  const totalLumens = lampCount * lumensPerLamp
  const efficacy = inputWatts > 0 ? totalLumens / inputWatts : 0
  
  // Find max candela for beam angle calculation
  let maxCandela = 0
  candelaValues.forEach(row => {
    row.forEach(cd => {
      if (cd > maxCandela) maxCandela = cd
    })
  })
  
  // Calculate beam angle (50% peak) and field angle (10% peak)
  const beamAngle = calculateBeamAngle(verticalAngles, candelaValues, maxCandela, 0.5)
  const fieldAngle = calculateBeamAngle(verticalAngles, candelaValues, maxCandela, 0.1)
  
  return {
    manufacturer: metadata.manufac || 'Unknown',
    luminaireCatalog: metadata.lumcat || '',
    luminaireDescription: metadata.luminaire || '',
    lampCatalog: metadata.lampcat || '',
    testLab: metadata.testlab || '',
    issueDate: metadata.issuedate || '',
    
    width: widthM,
    length: lengthM,
    height: heightM,
    luminousWidth: widthM,
    luminousLength: lengthM,
    luminousHeight: heightM,
    
    lampCount,
    lumensPerLamp,
    candelaMultiplier,
    inputWatts,
    ballastFactor,
    photometricType,
    unitsType,
    
    numVerticalAngles,
    numHorizontalAngles,
    verticalAngles,
    horizontalAngles,
    candelaValues,
    
    totalLumens,
    efficacy,
    beamAngle,
    fieldAngle,
    maxCandela,
    
    sourceUrl
  }
}

/**
 * Extract metadata keywords from IES file header.
 */
function extractMetadata(lines: string[]): Record<string, string> {
  const metadata: Record<string, string> = {}
  
  for (const line of lines) {
    const trimmed = line.trim()
    
    // Stop at TILT line
    if (trimmed.toUpperCase().startsWith('TILT=')) break
    
    // Parse [KEYWORD] value format
    const match = trimmed.match(/^\[([A-Z0-9_]+)\]\s*(.*)$/i)
    if (match) {
      const key = match[1].toLowerCase()
      const value = match[2].trim()
      metadata[key] = value
    }
  }
  
  return metadata
}

/**
 * Calculate beam/field angle from intensity distribution.
 * @param verticalAngles Array of gamma angles
 * @param candelaValues 2D array of candela values
 * @param maxCandela Peak intensity value
 * @param threshold Fraction of peak (0.5 for beam, 0.1 for field)
 */
function calculateBeamAngle(
  verticalAngles: number[],
  candelaValues: number[][],
  maxCandela: number,
  threshold: number
): number {
  if (verticalAngles.length === 0 || candelaValues.length === 0) {
    return 120 // default wide beam
  }
  
  // Average candela values across all horizontal angles for each vertical angle
  const avgByVertical: number[] = verticalAngles.map((_, vi) => {
    let sum = 0
    candelaValues.forEach(row => {
      sum += row[vi] || 0
    })
    return sum / candelaValues.length
  })
  
  // Find the angle where intensity drops below threshold
  const cutoff = maxCandela * threshold
  let halfAngle = verticalAngles[verticalAngles.length - 1]
  
  for (let i = 0; i < verticalAngles.length; i++) {
    if (avgByVertical[i] <= cutoff) {
      halfAngle = verticalAngles[i]
      break
    }
  }
  
  // Beam angle is twice the half-angle, capped at 180°
  return Math.min(halfAngle * 2, 180)
}

// =============================================================================
// Intensity Interpolation
// =============================================================================

/**
 * Get interpolated intensity at a specific angle from IES data.
 * Uses bilinear interpolation between grid points.
 * 
 * @param ies Parsed IES data
 * @param gamma Vertical angle from nadir (0° = straight down)
 * @param phi Horizontal angle (C-plane, 0-360°)
 * @returns Intensity in candelas (actual, not per 1000lm)
 */
export function getIntensity(ies: IESData, gamma: number, phi: number): number {
  gamma = Math.abs(gamma) // IES uses 0-180 typically
  phi = ((phi % 360) + 360) % 360 // Normalize to 0-360

  const { verticalAngles, horizontalAngles, candelaValues, candelaMultiplier, lumensPerLamp, lampCount } = ies

  if (verticalAngles.length === 0 || horizontalAngles.length === 0 || candelaValues.length === 0) {
    return 0
  }

  // Gamma beyond the measured range: a downlight distribution (last angle ≤ 90°)
  // emits no light above the horizontal plane. Do not "clamp" and invent uplight.
  const lastGamma = verticalAngles[verticalAngles.length - 1]
  if (gamma > lastGamma) {
    if (lastGamma <= 90.5) return 0
    gamma = lastGamma // full-sphere distribution (0-180): clamp to last sample
  }
  if (gamma < verticalAngles[0]) gamma = verticalAngles[0]

  const toCandela = candelaMultiplier * ((lumensPerLamp * lampCount) / 1000)

  // Symmetric fixture: a single C-plane, intensity depends only on gamma.
  if (horizontalAngles.length === 1) {
    return interpolate1D(verticalAngles, candelaValues[0], gamma) * toCandela
  }

  const nH = horizontalAngles.length
  const lastH = horizontalAngles[nH - 1]

  // C0-C180 symmetry (distribution stored 0..180).
  if (lastH <= 180.5 && phi > 180) {
    phi = 360 - phi
  }

  // Find the horizontal interpolation bracket [h1, h2].
  let h1 = 0
  let h2 = 0
  let found = false
  for (let i = 0; i < nH - 1; i++) {
    if (phi >= horizontalAngles[i] && phi <= horizontalAngles[i + 1]) {
      h1 = i
      h2 = i + 1
      found = true
      break
    }
  }

  if (!found) {
    if (lastH >= 359) {
      // Full 0..360 distribution: wrap around (360° === 0°).
      h1 = nH - 1
      h2 = 0
    } else {
      // Beyond stored range: clamp to last plane.
      h1 = nH - 1
      h2 = nH - 1
    }
  }

  const cd1 = interpolate1D(verticalAngles, candelaValues[h1], gamma)
  const cd2 = interpolate1D(verticalAngles, candelaValues[h2], gamma)

  const phi1 = horizontalAngles[h1]
  const phi2 = (h1 === nH - 1 && h2 === 0) ? 360 : horizontalAngles[h2]
  const span = phi2 - phi1
  const t = span > 0 ? Math.max(0, Math.min(1, (phi - phi1) / span)) : 0

  return (cd1 + (cd2 - cd1) * t) * toCandela
}

/**
 * 1D linear interpolation in a sorted array.
 */
function interpolate1D(angles: number[], values: number[], target: number): number {
  if (angles.length === 0) return 0
  if (angles.length === 1) return values[0]
  
  // Clamp to range
  if (target <= angles[0]) return values[0]
  if (target >= angles[angles.length - 1]) return values[values.length - 1]
  
  // Find surrounding indices
  let i1 = 0
  for (let i = 0; i < angles.length - 1; i++) {
    if (target >= angles[i] && target <= angles[i + 1]) {
      i1 = i
      break
    }
  }
  const i2 = i1 + 1
  
  // Linear interpolation
  const range = angles[i2] - angles[i1] || 1
  const t = (target - angles[i1]) / range
  
  return values[i1] + (values[i2] - values[i1]) * t
}

// =============================================================================
// Utility Functions
// =============================================================================

/**
 * Convert IESData to simplified IESProfile for UI.
 */
export function iesDataToProfile(ies: IESData, id: string, productSlug: string): IESProfile {
  return {
    id,
    productSlug,
    productName: formatProductName(productSlug),
    variantLabel: ies.luminaireDescription || ies.luminaireCatalog || 'Unknown',
    url: ies.sourceUrl,
    lumens: ies.totalLumens,
    watts: ies.inputWatts,
    beamAngle: ies.beamAngle,
    efficacy: ies.efficacy
  }
}

/**
 * Format product slug to display name.
 */
function formatProductName(slug: string): string {
  return slug
    .split('-')
    .map(segment => segment.charAt(0).toUpperCase() + segment.slice(1))
    .join(' ')
}

/**
 * Validate IES data for minimum requirements.
 */
export function validateIESData(ies: IESData): { valid: boolean; errors: string[] } {
  const errors: string[] = []
  
  if (ies.totalLumens <= 0) {
    errors.push('Total lumens must be greater than 0')
  }
  
  if (ies.numVerticalAngles <= 0 || ies.numHorizontalAngles <= 0) {
    errors.push('Invalid angle count')
  }
  
  if (ies.candelaValues.length !== ies.numHorizontalAngles) {
    errors.push('Candela array size mismatch')
  }
  
  if (ies.candelaValues.length > 0 && ies.candelaValues[0].length !== ies.numVerticalAngles) {
    errors.push('Candela row size mismatch')
  }
  
  return {
    valid: errors.length === 0,
    errors
  }
}

/**
 * Get a summary string for an IES profile.
 */
export function getIESSummary(ies: IESData): string {
  const parts: string[] = []
  
  if (ies.totalLumens > 0) {
    parts.push(`${Math.round(ies.totalLumens).toLocaleString()} lm`)
  }
  
  if (ies.inputWatts > 0) {
    parts.push(`${Math.round(ies.inputWatts)}W`)
  }
  
  if (ies.efficacy > 0) {
    parts.push(`${Math.round(ies.efficacy)} lm/W`)
  }
  
  if (ies.beamAngle > 0) {
    parts.push(`${Math.round(ies.beamAngle)}° beam`)
  }
  
  return parts.join(' | ')
}
