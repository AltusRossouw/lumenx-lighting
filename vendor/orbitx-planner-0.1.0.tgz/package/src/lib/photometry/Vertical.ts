/**
 * OrbitX Lighting Planner - Vertical & Cylindrical Illuminance
 *
 * EN 12464-1 specifies vertical illuminance (walls, shelving, task areas) and
 * cylindrical illuminance (facial / object modelling) in addition to the
 * horizontal work-plane illuminance.
 *
 * - Vertical illuminance (Ev): illuminance on a vertical plane, computed with
 *   the same point-by-point + radiosity engine using a horizontal surface normal.
 *
 * - Cylindrical illuminance (Ez): mean illuminance on a small vertical cylinder.
 *   For a point source: Ez = Σ I(γ) · sin(γ) / (π · d²), where the 1/π arises
 *   from averaging the vertical illuminance over the full 360° cylinder.
 */

import {
  calculateSingleLuminaireContribution,
  computeSurfaceExitances,
  getSurfaceGeometries,
  directionToPhotometricAngles,
} from './Calculator'
import { integrateSurfaceContribution } from './Radiosity'
import { getIntensity } from './IESParser'
import { getMaintenanceFactor } from './Maintenance'
import type { RoomConfig, LuminaireInstance, IESData } from './types'

function toMap(ies: Map<string, IESData> | Record<string, IESData>): Map<string, IESData> {
  return ies instanceof Map ? ies : new Map(Object.entries(ies))
}

function len(v: { x: number; y: number; z: number }): number {
  return Math.sqrt(v.x * v.x + v.y * v.y + v.z * v.z)
}

export interface VerticalResult {
  Evavg: number
  Evmin: number
  Evmax: number
}

/**
 * Mean vertical illuminance over the room's walls (from work-plane height up).
 */
export function calculateWallIlluminance(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>,
  gridSpacing: number = 1.0
): VerticalResult {
  const iesMap = toMap(iesDataMap)
  const mf = getMaintenanceFactor(room)
  const surfaces = getSurfaceGeometries(room)
  const exitances = computeSurfaceExitances(room, luminaires, iesMap)

  const values: number[] = []

  // Walls are surface indices 2..5 (North, South, East, West).
  for (let s = 2; s < 6; s++) {
    const wall = surfaces[s]
    const uLen = len(wall.uVec)
    const vLen = len(wall.vVec)
    const nu = Math.max(2, Math.round(uLen / gridSpacing))
    const nv = Math.max(2, Math.round(vLen / gridSpacing))

    for (let i = 0; i < nu; i++) {
      for (let j = 0; j < nv; j++) {
        const u = (i + 0.5) / nu
        const v = (j + 0.5) / nv
        const p = {
          x: wall.origin.x + wall.uVec.x * u + wall.vVec.x * v,
          y: wall.origin.y + wall.uVec.y * u + wall.vVec.y * v,
          z: wall.origin.z + wall.uVec.z * u + wall.vVec.z * v,
        }

        let E = 0

        // Direct component.
        for (const lum of luminaires) {
          const ies = iesMap.get(lum.iesProfileId)
          if (!ies || lum.dimming <= 0) continue
          E += calculateSingleLuminaireContribution(
            { x: p.x, z: p.z, y: p.y },
            room,
            lum,
            ies,
            wall.normal
          ) * lum.dimming
        }

        // Reflected component (all six room surfaces).
        for (let k = 0; k < 6; k++) {
          if (exitances[k] <= 0) continue
          const src = surfaces[k]
          E += integrateSurfaceContribution(
            p,
            src.origin,
            src.uVec,
            src.vVec,
            src.normal,
            exitances[k],
            8,
            wall.normal
          )
        }

        values.push(E * mf)
      }
    }
  }

  if (values.length === 0) return { Evavg: 0, Evmin: 0, Evmax: 0 }

  let min = values[0]
  let max = values[0]
  let sum = 0
  for (const v of values) {
    if (v < min) min = v
    if (v > max) max = v
    sum += v
  }

  return {
    Evavg: sum / values.length,
    Evmin: min,
    Evmax: max,
  }
}

export interface CylindricalResult {
  Ezavg: number
  Ezmin: number
}

/**
 * Mean cylindrical illuminance at eye height over the given (x, z) points.
 * Direct component from point sources; inter-reflections are a small diffuse
 * correction and are intentionally omitted for the first pass.
 */
export function calculateCylindricalIlluminance(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>,
  points: { x: number; z: number }[]
): CylindricalResult {
  const iesMap = toMap(iesDataMap)
  const mf = getMaintenanceFactor(room)
  const eyeHeight = room.workPlaneHeight + 1.2

  const values: number[] = []

  for (const p of points) {
    let Ez = 0
    for (const lum of luminaires) {
      const ies = iesMap.get(lum.iesProfileId)
      if (!ies || lum.dimming <= 0) continue

      const dx = p.x - lum.position.x
      const dy = eyeHeight - lum.position.y
      const dz = p.z - lum.position.z
      const distSq = dx * dx + dy * dy + dz * dz
      const dist = Math.sqrt(distSq)
      if (dist < 0.01) continue

      const dirX = dx / dist
      const dirY = dy / dist
      const dirZ = dz / dist

      const { gamma, cPlane } = directionToPhotometricAngles(dirX, dirY, dirZ, lum.rotation)
      const intensity = getIntensity(ies, gamma, cPlane) * lum.dimming
      if (intensity <= 0) continue

      const sinGamma = Math.sin((gamma * Math.PI) / 180)
      // Cylindrical illuminance: Ez = I·sinγ/(π·d²).
      Ez += (intensity * sinGamma) / (Math.PI * distSq)
    }
    values.push(Ez * mf)
  }

  if (values.length === 0) return { Ezavg: 0, Ezmin: 0 }

  let min = values[0]
  let sum = 0
  for (const v of values) {
    if (v < min) min = v
    sum += v
  }

  return { Ezavg: sum / values.length, Ezmin: min }
}
