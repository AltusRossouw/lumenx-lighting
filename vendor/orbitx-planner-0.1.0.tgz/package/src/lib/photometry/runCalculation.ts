/**
 * OrbitX Lighting Planner - shared synchronous calculation function.
 *
 * This is the single source of truth for the point-by-point illuminance run.
 * Both the Web Worker and the main-thread fallback call it, so results are
 * identical whether or not a Worker is available.
 */

import type { LuminaireInstance, IESData, CalculationResults, RoomConfig } from './types'
import { calculateIlluminance, computeSurfaceExitances } from './Calculator'
import { calculateWorstCaseUGR } from './UGR'
import { calculateWallIlluminance, calculateCylindricalIlluminance } from './Vertical'

export interface RunCalculationOptions {
  gridSpacing?: number
  calculateUGR?: boolean
}

export type ProgressFn = (percent: number, message?: string) => void

/**
 * Run the full illuminance calculation on the current thread.
 *
 * @param room Room configuration (width/length/height, work plane height, etc.)
 * @param luminaires Placed luminaires.
 * @param iesDataMap IES photometry data keyed by profile id (a Record).
 * @param options Grid spacing + whether to compute UGR.
 * @param onProgress Optional progress callback.
 */
export function runCalculation(
  room: RoomConfig,
  luminaires: LuminaireInstance[],
  iesDataMap: Map<string, IESData> | Record<string, IESData>,
  options: RunCalculationOptions = {},
  onProgress?: ProgressFn
): CalculationResults {
  const gridSpacing = options.gridSpacing ?? 0.5
  const calculateUGR = options.calculateUGR ?? true

  const iesMap = iesDataMap instanceof Map
    ? iesDataMap
    : new Map<string, IESData>(Object.entries(iesDataMap))

  onProgress?.(0, 'Starting calculation...')

  const results = calculateIlluminance(
    room,
    luminaires,
    iesMap,
    gridSpacing,
    (percent, message) => onProgress?.(percent, message)
  )

  if (luminaires.length > 0) {
    onProgress?.(90, 'Computing vertical & cylindrical illuminance...')
    const wall = calculateWallIlluminance(room, luminaires, iesMap)
    results.Evavg = wall.Evavg
    results.Evmin = wall.Evmin

    const points = results.grid.points.map((p) => ({ x: p.x, z: p.z }))
    const cyl = calculateCylindricalIlluminance(room, luminaires, iesMap, points)
    results.Ezavg = cyl.Ezavg
    results.Ezmin = cyl.Ezmin
  }

  if (calculateUGR && luminaires.length > 0) {
    onProgress?.(96, 'Computing UGR...')
    const exitances = computeSurfaceExitances(room, luminaires, iesMap)
    const ugr = calculateWorstCaseUGR(room, luminaires, iesMap, exitances)
    results.UGR = ugr.worstUGR
    results.UGRPositions = ugr.positions
  }

  onProgress?.(100, 'Complete')
  return results
}
