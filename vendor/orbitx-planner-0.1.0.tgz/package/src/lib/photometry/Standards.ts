/**
 * OrbitX Lighting Planner - Standards & Compliance
 * 
 * EN 12464-1 workplace lighting requirements and compliance checking.
 */

import type { ActivityRequirements, ComplianceResult, CalculationResults, ComplianceStatus } from './types'

// =============================================================================
// EN 12464-1 Activity Requirements Database
// =============================================================================

/**
 * Comprehensive database of activity types per EN 12464-1:2021.
 * Each entry specifies:
 * - Eavg: Maintained illuminance (lux)
 * - UGR: Maximum Unified Glare Rating
 * - Uo: Minimum overall uniformity (Emin/Eavg)
 * - Ra: Minimum colour rendering index
 */
export const ACTIVITY_REQUIREMENTS: Record<string, ActivityRequirements> = {
  // =========================================================================
  // Office Areas
  // =========================================================================
  'office-general': {
    id: 'office-general',
    name: 'Office - General areas',
    category: 'Office',
    Eavg: 300,
    UGR: 22,
    Uo: 0.4,
    Ra: 80,
    notes: 'Filing, copying, circulation areas'
  },
  'office-writing': {
    id: 'office-writing',
    name: 'Office - Writing, typing, reading',
    category: 'Office',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'office-technical': {
    id: 'office-technical',
    name: 'Office - Technical drawing',
    category: 'Office',
    Eavg: 750,
    UGR: 16,
    Uo: 0.7,
    Ra: 80
  },
  'office-cad': {
    id: 'office-cad',
    name: 'Office - CAD workstations',
    category: 'Office',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80,
    notes: 'Consider screen reflections'
  },
  'office-meeting': {
    id: 'office-meeting',
    name: 'Office - Meeting rooms',
    category: 'Office',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'office-reception': {
    id: 'office-reception',
    name: 'Office - Reception desk',
    category: 'Office',
    Eavg: 300,
    UGR: 22,
    Uo: 0.6,
    Ra: 80
  },
  'office-archives': {
    id: 'office-archives',
    name: 'Office - Archives',
    category: 'Office',
    Eavg: 200,
    UGR: 25,
    Uo: 0.4,
    Ra: 80
  },

  // =========================================================================
  // Industrial / Manufacturing
  // =========================================================================
  'industrial-general': {
    id: 'industrial-general',
    name: 'Industrial - General areas',
    category: 'Industrial',
    Eavg: 200,
    UGR: 25,
    Uo: 0.4,
    Ra: 60
  },
  'industrial-rough': {
    id: 'industrial-rough',
    name: 'Industrial - Rough work',
    category: 'Industrial',
    Eavg: 300,
    UGR: 25,
    Uo: 0.4,
    Ra: 60,
    notes: 'Rough machining, welding'
  },
  'industrial-medium': {
    id: 'industrial-medium',
    name: 'Industrial - Medium work',
    category: 'Industrial',
    Eavg: 500,
    UGR: 22,
    Uo: 0.6,
    Ra: 80,
    notes: 'Machining, sheet metal work'
  },
  'industrial-fine': {
    id: 'industrial-fine',
    name: 'Industrial - Fine work',
    category: 'Industrial',
    Eavg: 750,
    UGR: 19,
    Uo: 0.7,
    Ra: 80,
    notes: 'Fine machining, grinding'
  },
  'industrial-precision': {
    id: 'industrial-precision',
    name: 'Industrial - Precision work',
    category: 'Industrial',
    Eavg: 1000,
    UGR: 16,
    Uo: 0.7,
    Ra: 90,
    notes: 'Precision assembly, inspection'
  },
  'assembly-general': {
    id: 'assembly-general',
    name: 'Assembly - General',
    category: 'Industrial',
    Eavg: 300,
    UGR: 25,
    Uo: 0.6,
    Ra: 80
  },
  'assembly-medium': {
    id: 'assembly-medium',
    name: 'Assembly - Medium precision',
    category: 'Industrial',
    Eavg: 500,
    UGR: 22,
    Uo: 0.6,
    Ra: 80
  },
  'assembly-fine': {
    id: 'assembly-fine',
    name: 'Assembly - Fine precision',
    category: 'Industrial',
    Eavg: 750,
    UGR: 19,
    Uo: 0.7,
    Ra: 80
  },
  'quality-control': {
    id: 'quality-control',
    name: 'Quality control / Inspection',
    category: 'Industrial',
    Eavg: 1000,
    UGR: 16,
    Uo: 0.7,
    Ra: 90
  },

  // =========================================================================
  // Warehouse / Storage
  // =========================================================================
  'warehouse-inactive': {
    id: 'warehouse-inactive',
    name: 'Warehouse - Inactive storage',
    category: 'Warehouse',
    Eavg: 100,
    UGR: 28,
    Uo: 0.4,
    Ra: 60,
    notes: 'Long-term storage, minimal activity'
  },
  'warehouse-active': {
    id: 'warehouse-active',
    name: 'Warehouse - Active picking',
    category: 'Warehouse',
    Eavg: 200,
    UGR: 25,
    Uo: 0.4,
    Ra: 60,
    notes: 'Regular picking and packing'
  },
  'warehouse-dispatch': {
    id: 'warehouse-dispatch',
    name: 'Warehouse - Dispatch area',
    category: 'Warehouse',
    Eavg: 300,
    UGR: 25,
    Uo: 0.4,
    Ra: 60,
    notes: 'Loading docks, dispatch'
  },
  'cold-storage': {
    id: 'cold-storage',
    name: 'Cold storage / Freezer',
    category: 'Warehouse',
    Eavg: 200,
    UGR: 25,
    Uo: 0.4,
    Ra: 60,
    notes: 'Special fixtures required'
  },

  // =========================================================================
  // Retail
  // =========================================================================
  'retail-general': {
    id: 'retail-general',
    name: 'Retail - Sales area',
    category: 'Retail',
    Eavg: 300,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },
  'retail-checkout': {
    id: 'retail-checkout',
    name: 'Retail - Checkout / Counter',
    category: 'Retail',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'supermarket': {
    id: 'supermarket',
    name: 'Supermarket - Sales floor',
    category: 'Retail',
    Eavg: 500,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },

  // =========================================================================
  // Educational
  // =========================================================================
  'classroom': {
    id: 'classroom',
    name: 'Classroom - General',
    category: 'Educational',
    Eavg: 300,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'classroom-evening': {
    id: 'classroom-evening',
    name: 'Classroom - Evening classes',
    category: 'Educational',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'lecture-hall': {
    id: 'lecture-hall',
    name: 'Lecture hall / Auditorium',
    category: 'Educational',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'whiteboard': {
    id: 'whiteboard',
    name: 'Whiteboard / Chalkboard',
    category: 'Educational',
    Eavg: 500,
    UGR: 19,
    Uo: 0.7,
    Ra: 80,
    notes: 'Vertical illuminance'
  },
  'library-reading': {
    id: 'library-reading',
    name: 'Library - Reading areas',
    category: 'Educational',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },
  'library-shelves': {
    id: 'library-shelves',
    name: 'Library - Bookshelves',
    category: 'Educational',
    Eavg: 200,
    UGR: 19,
    Uo: 0.4,
    Ra: 80,
    notes: 'Vertical illuminance on spines'
  },
  'laboratory': {
    id: 'laboratory',
    name: 'Laboratory - General',
    category: 'Educational',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },

  // =========================================================================
  // Healthcare
  // =========================================================================
  'hospital-corridor': {
    id: 'hospital-corridor',
    name: 'Hospital - Corridors (day)',
    category: 'Healthcare',
    Eavg: 200,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },
  'hospital-ward': {
    id: 'hospital-ward',
    name: 'Hospital - Ward (general)',
    category: 'Healthcare',
    Eavg: 100,
    UGR: 19,
    Uo: 0.4,
    Ra: 80,
    notes: 'Dimmable for patient comfort'
  },
  'examination-room': {
    id: 'examination-room',
    name: 'Examination room',
    category: 'Healthcare',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 90
  },
  'pharmacy': {
    id: 'pharmacy',
    name: 'Pharmacy',
    category: 'Healthcare',
    Eavg: 500,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  },

  // =========================================================================
  // Circulation / Common Areas
  // =========================================================================
  'corridor': {
    id: 'corridor',
    name: 'Corridor / Passage',
    category: 'Circulation',
    Eavg: 100,
    UGR: 28,
    Uo: 0.4,
    Ra: 60
  },
  'stairway': {
    id: 'stairway',
    name: 'Stairs / Escalators',
    category: 'Circulation',
    Eavg: 150,
    UGR: 25,
    Uo: 0.4,
    Ra: 60
  },
  'lift-lobby': {
    id: 'lift-lobby',
    name: 'Lift lobby',
    category: 'Circulation',
    Eavg: 200,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },
  'entrance': {
    id: 'entrance',
    name: 'Entrance / Foyer',
    category: 'Circulation',
    Eavg: 200,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },
  'canteen': {
    id: 'canteen',
    name: 'Canteen / Breakroom',
    category: 'Circulation',
    Eavg: 200,
    UGR: 22,
    Uo: 0.4,
    Ra: 80
  },
  'restroom': {
    id: 'restroom',
    name: 'Restroom / Toilet',
    category: 'Circulation',
    Eavg: 200,
    UGR: 25,
    Uo: 0.4,
    Ra: 80
  },

  // =========================================================================
  // Parking / Outdoor
  // =========================================================================
  'parking-indoor': {
    id: 'parking-indoor',
    name: 'Parking - Indoor',
    category: 'Parking',
    Eavg: 75,
    UGR: 28,
    Uo: 0.4,
    Ra: 40
  },
  'parking-ramp': {
    id: 'parking-ramp',
    name: 'Parking - Ramps',
    category: 'Parking',
    Eavg: 100,
    UGR: 28,
    Uo: 0.4,
    Ra: 40
  },
  'loading-bay': {
    id: 'loading-bay',
    name: 'Loading bay',
    category: 'Parking',
    Eavg: 150,
    UGR: 25,
    Uo: 0.4,
    Ra: 60
  },

  // =========================================================================
  // Mining & Heavy Industry
  // =========================================================================
  'mining-general': {
    id: 'mining-general',
    name: 'Mining - General areas',
    category: 'Mining',
    Eavg: 50,
    UGR: 28,
    Uo: 0.4,
    Ra: 40,
    notes: 'Underground general circulation'
  },
  'mining-workshop': {
    id: 'mining-workshop',
    name: 'Mining - Workshop',
    category: 'Mining',
    Eavg: 300,
    UGR: 25,
    Uo: 0.4,
    Ra: 60
  },
  'mining-control': {
    id: 'mining-control',
    name: 'Mining - Control room',
    category: 'Mining',
    Eavg: 300,
    UGR: 19,
    Uo: 0.6,
    Ra: 80
  }
}

// =============================================================================
// Compliance Checking
// =============================================================================

/**
 * Check if calculation results meet requirements for an activity type.
 */
export function checkCompliance(
  results: CalculationResults,
  activityTypeId: string
): ComplianceResult {
  const requirements = ACTIVITY_REQUIREMENTS[activityTypeId]
  
  if (!requirements) {
    return {
      activityType: activityTypeId,
      requirements: ACTIVITY_REQUIREMENTS['office-general'],
      illuminancePass: false,
      illuminanceValue: results.Eavg,
      illuminanceTarget: 0,
      uniformityPass: false,
      uniformityValue: results.Uo,
      uniformityTarget: 0,
      ugrPass: false,
      ugrValue: results.UGR ?? null,
      ugrTarget: 0,
      overallPass: false,
      recommendations: ['Unknown activity type']
    }
  }
  
  // Check each metric
  const illuminancePass = results.Eavg >= requirements.Eavg
  const uniformityPass = results.Uo >= requirements.Uo
  const ugrPass = results.UGR != null ? results.UGR <= requirements.UGR : true
  
  const overallPass = illuminancePass && uniformityPass && ugrPass
  
  // Generate recommendations
  const recommendations: string[] = []
  
  if (!illuminancePass) {
    const deficit = requirements.Eavg - results.Eavg
    const percentIncrease = Math.ceil((deficit / results.Eavg) * 100)
    recommendations.push(
      `Increase lighting by ~${percentIncrease}% to achieve ${requirements.Eavg} lux (currently ${Math.round(results.Eavg)} lux)`
    )
  }
  
  if (!uniformityPass) {
    recommendations.push(
      `Improve uniformity from ${results.Uo.toFixed(2)} to ${requirements.Uo.toFixed(2)}. Consider adding more fixtures or adjusting spacing.`
    )
  }
  
  if (!ugrPass && results.UGR != null) {
    recommendations.push(
      `Reduce glare - UGR ${results.UGR} exceeds limit of ${requirements.UGR}. Consider using fixtures with better glare control.`
    )
  }
  
  return {
    activityType: activityTypeId,
    requirements,
    illuminancePass,
    illuminanceValue: results.Eavg,
    illuminanceTarget: requirements.Eavg,
    uniformityPass,
    uniformityValue: results.Uo,
    uniformityTarget: requirements.Uo,
    ugrPass,
    ugrValue: results.UGR ?? null,
    ugrTarget: requirements.UGR,
    overallPass,
    recommendations
  }
}

/**
 * Get compliance status for a single metric.
 */
export function getComplianceStatus(
  value: number,
  target: number,
  isMaximum: boolean = false
): ComplianceStatus {
  const margin = isMaximum ? target - value : value - target
  const percentMargin = Math.abs(margin / target) * 100
  
  if (isMaximum) {
    if (value <= target) return 'pass'
    if (percentMargin <= 10) return 'marginal'
    return 'fail'
  } else {
    if (value >= target) return 'pass'
    if (percentMargin <= 10) return 'marginal'
    return 'fail'
  }
}

/**
 * Get all activity types grouped by category.
 */
export function getActivityTypesByCategory(): Record<string, ActivityRequirements[]> {
  const byCategory: Record<string, ActivityRequirements[]> = {}
  
  for (const req of Object.values(ACTIVITY_REQUIREMENTS)) {
    if (!byCategory[req.category]) {
      byCategory[req.category] = []
    }
    byCategory[req.category].push(req)
  }
  
  // Sort each category by illuminance requirement
  for (const category of Object.keys(byCategory)) {
    byCategory[category].sort((a, b) => a.Eavg - b.Eavg)
  }
  
  return byCategory
}

/**
 * Get activity requirements by ID.
 */
export function getActivityRequirements(id: string): ActivityRequirements | null {
  return ACTIVITY_REQUIREMENTS[id] ?? null
}

/**
 * Get activity by ID (alias for getActivityRequirements).
 */
export function getActivityById(id: string): ActivityRequirements | undefined {
  return ACTIVITY_REQUIREMENTS[id]
}

/**
 * Get activities by category.
 */
export function getActivitiesByCategory(category: string): ActivityRequirements[] {
  return Object.values(ACTIVITY_REQUIREMENTS).filter(req => req.category === category)
}

/**
 * Array of all activity presets for easy iteration.
 */
export const ACTIVITY_PRESETS: ActivityRequirements[] = Object.values(ACTIVITY_REQUIREMENTS)

/**
 * Search activity types by name.
 */
export function searchActivityTypes(query: string): ActivityRequirements[] {
  const lower = query.toLowerCase()
  return Object.values(ACTIVITY_REQUIREMENTS).filter(
    req => req.name.toLowerCase().includes(lower) ||
           req.category.toLowerCase().includes(lower)
  )
}

/**
 * Get recommended activity type based on room type keyword.
 */
export function suggestActivityType(keyword: string): string {
  const lower = keyword.toLowerCase()
  
  const mappings: Record<string, string> = {
    'office': 'office-writing',
    'warehouse': 'warehouse-active',
    'factory': 'industrial-medium',
    'workshop': 'industrial-medium',
    'retail': 'retail-general',
    'shop': 'retail-general',
    'classroom': 'classroom',
    'school': 'classroom',
    'hospital': 'hospital-corridor',
    'clinic': 'examination-room',
    'parking': 'parking-indoor',
    'corridor': 'corridor',
    'storage': 'warehouse-inactive',
    'assembly': 'assembly-medium',
    'laboratory': 'laboratory',
    'library': 'library-reading',
    'canteen': 'canteen',
    'reception': 'office-reception',
    'meeting': 'office-meeting',
    'conference': 'office-meeting',
    'inspection': 'quality-control',
    'mining': 'mining-general'
  }
  
  for (const [key, value] of Object.entries(mappings)) {
    if (lower.includes(key)) {
      return value
    }
  }
  
  return 'office-general'
}
