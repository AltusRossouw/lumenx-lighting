/**
 * OrbitX Lighting Planner - Radiosity Engine
 * 
 * Implements a 6-surface radiosity method for rectangular rooms to calculate
 * inter-reflected light more accurately than the simple average reflection method.
 * 
 * The room is modeled as 6 surfaces:
 * 0: Floor
 * 1: Ceiling
 * 2: Wall North (-Z)
 * 3: Wall South (+Z)
 * 4: Wall East (+X)
 * 5: Wall West (-X)
 */

import { RoomConfig } from './types'

// Surface indices for clarity
export enum SurfaceType {
  Floor = 0,
  Ceiling = 1,
  WallNorth = 2, // -Z
  WallSouth = 3, // +Z
  WallEast = 4,  // +X
  WallWest = 5   // -X
}

export interface Surface {
  id: SurfaceType
  area: number
  reflectance: number
  initialFlux: number // Total lumens directly from luminaires
  exitance: number    // Final luminous exitance (lumens/m²)
}

/**
 * Calculate form factor from surface i to surface j (F_ij).
 * For a rectangular room, we use standard analytical formulas for:
 * - Parallel rectangles (Floor <-> Ceiling)
 * - Perpendicular rectangles (Wall <-> Floor/Ceiling, Wall <-> Wall)
 */
function calculateFormFactor(
  width: number,
  length: number,
  height: number,
  from: SurfaceType,
  to: SurfaceType
): number {
  // Self-viewing is 0 for flat rectangles
  if (from === to) return 0

  // Dimensions relative to the shared edge or distance
  // We simplify by using pre-calculated view factors for standard box geometry
  // approximate or analytical. 
  
  // Ref: "Radiative Heat Transfer", Modest, or standard HVAC view factor charts.
  // Using well-known formulas for parallel and perpendicular plates.
  
  // Normalized dimensions
  const X = width / height
  const Y = length / height
  
  // 1. Floor (0) to Ceiling (1) - Parallel aligned
  if ((from === SurfaceType.Floor && to === SurfaceType.Ceiling) || 
      (from === SurfaceType.Ceiling && to === SurfaceType.Floor)) {
      return getFormFactorParallel(width, length, height)
  }

  // 2. Floor/Ceiling to Walls - Perpendicular with shared edge
  if (isPerpendicular(from, to)) {
      // Determine common edge length (W or L) and other dimension
      // This requires careful mapping of which wall is which
      return getFormFactorPerpendicular(width, length, height, from, to)
  }

  // 3. Wall to Wall (Opposite) - Parallel
  if (isOppositeWall(from, to)) {
      const dist = (from === SurfaceType.WallNorth || from === SurfaceType.WallSouth) ? length : width
      const w = (from === SurfaceType.WallNorth || from === SurfaceType.WallSouth) ? width : length
      return getFormFactorParallelWalls(w, height, dist)
  }

  // 4. Wall to Wall (Adjacent) - Perpendicular
  if (isAdjacentWall(from, to)) {
     return getFormFactorPerpendicularWalls(width, length, height, from, to)
  }

  return 0
}

/**
 * Parallel rectangles (e.g. Floor to Ceiling)
 * W = width, L = length, H = separation distance
 */
function getFormFactorParallel(W: number, L: number, H: number): number {
  const x = W / H
  const y = L / H
  const x2 = x * x
  const y2 = y * y
  
  const part1 = (2 / (Math.PI * x * y))
  const part2 = Math.log(Math.sqrt(( (1 + x2) * (1 + y2) ) / (1 + x2 + y2)))
  const part3 = x * Math.sqrt(1 + y2) * Math.atan(x / Math.sqrt(1 + y2))
  const part4 = y * Math.sqrt(1 + x2) * Math.atan(y / Math.sqrt(1 + x2))
  const part5 = -x * Math.atan(x) - y * Math.atan(y)
  
  return Math.max(0, part1 * (part2 + part3 + part4 + part5))
}

/**
 * Perpendicular rectangles with common edge (e.g. Floor to Wall)
 * Need to identify the dimensions correctly.
 */
function getFormFactorPerpendicular(W: number, L: number, H: number, from: SurfaceType, to: SurfaceType): number {
    // Determine the common edge length (w) and the other two dimensions (h1, h2)
    // from surface is h1 x w
    // to surface is h2 x w
    
    // Floor/Ceiling is W x L
    // North/South Wall is W x H
    // East/West Wall is L x H

    let commonEdge = 0 // w
    let sizeFrom = 0   // h1 (dimension of 'from' perpendicular to common edge)
    let sizeTo = 0     // h2 (dimension of 'to' perpendicular to common edge)

    // Case A: Floor/Ceiling (WxL) <-> North/South Wall (WxH) -> Common edge is W
    if ((isFloorOrCeiling(from) && isNorthSouth(to)) || (isNorthSouth(from) && isFloorOrCeiling(to))) {
        commonEdge = W
        sizeFrom = isFloorOrCeiling(from) ? L : H
        sizeTo = isFloorOrCeiling(to) ? L : H
    }
    // Case B: Floor/Ceiling (WxL) <-> East/West Wall (LxH) -> Common edge is L
    else if ((isFloorOrCeiling(from) && isEastWest(to)) || (isEastWest(from) && isFloorOrCeiling(to))) {
        commonEdge = L
        sizeFrom = isFloorOrCeiling(from) ? W : H
        sizeTo = isFloorOrCeiling(to) ? W : H
    }
    else {
        return 0 // Should be covered by other cases
    }

    const H1 = sizeTo / commonEdge
    const W1 = sizeFrom / commonEdge
    
    const term1 = 1 / (Math.PI * W1)
    const term2 = 0.25 * Math.log(
        ( (1 + W1*W1) * (1 + H1*H1) / (1 + W1*W1 + H1*H1) ) *
        Math.pow( (W1*W1 * (1 + W1*W1 + H1*H1)) / ((1 + W1*W1) * (W1*W1 + H1*H1)), W1*W1 ) *
        Math.pow( (H1*H1 * (1 + W1*W1 + H1*H1)) / ((1 + H1*H1) * (W1*W1 + H1*H1)), H1*H1 )
    )
    const term3 = W1 * Math.atan(1/W1) + H1 * Math.atan(1/H1) - Math.sqrt(W1*W1 + H1*H1) * Math.atan(1/Math.sqrt(W1*W1 + H1*H1))
    
    return Math.max(0, term1 * (term2 + term3))
}

// Helpers for dimensions and relations
function isFloorOrCeiling(s: SurfaceType) { return s === SurfaceType.Floor || s === SurfaceType.Ceiling }
function isNorthSouth(s: SurfaceType) { return s === SurfaceType.WallNorth || s === SurfaceType.WallSouth }
function isEastWest(s: SurfaceType) { return s === SurfaceType.WallEast || s === SurfaceType.WallWest }

function isPerpendicular(s1: SurfaceType, s2: SurfaceType): boolean {
    if (isFloorOrCeiling(s1)) return !isFloorOrCeiling(s2)
    if (isFloorOrCeiling(s2)) return !isFloorOrCeiling(s1)
    return false // Wall-to-Wall is handled separately
}

function isOppositeWall(s1: SurfaceType, s2: SurfaceType): boolean {
    if (s1 === SurfaceType.WallNorth && s2 === SurfaceType.WallSouth) return true
    if (s1 === SurfaceType.WallSouth && s2 === SurfaceType.WallNorth) return true
    if (s1 === SurfaceType.WallEast && s2 === SurfaceType.WallWest) return true
    if (s1 === SurfaceType.WallWest && s2 === SurfaceType.WallEast) return true
    return false
}

function isAdjacentWall(s1: SurfaceType, s2: SurfaceType): boolean {
    if (isFloorOrCeiling(s1) || isFloorOrCeiling(s2)) return false
    return !isOppositeWall(s1, s2) && s1 !== s2
}

/**
 * Parallel Walls (Opposite)
 * w x h rectangles separated by dist
 */
function getFormFactorParallelWalls(w: number, h: number, dist: number): number {
    return getFormFactorParallel(w, h, dist)
}

/**
 * Perpendicular Walls (Adjacent)
 * Shared edge is height H. Widths are W1 and W2.
 */
function getFormFactorPerpendicularWalls(W: number, L: number, H: number, from: SurfaceType, to: SurfaceType): number {
    // Identifying W1 and W2 relative to common edge H
    let wFrom = 0
    let wTo = 0
    
    if (isNorthSouth(from)) wFrom = W; else wFrom = L
    if (isNorthSouth(to)) wTo = W; else wTo = L
    
    // Formula is same as perpendicular plates, identifying common edge as H
    const H_common = H
    const W1 = wFrom / H_common
    const H1 = wTo / H_common
    
    // Reuse the perpendicular formula logic
    // Map to variables: commonEdge = H, sizeFrom = wFrom, sizeTo = wTo
    const commonEdge = H
    const sizeFrom = wFrom
    const sizeTo = wTo

    const paramH = sizeTo / commonEdge
    const paramW = sizeFrom / commonEdge
    
    const term1 = 1 / (Math.PI * paramW)
    const term2 = 0.25 * Math.log(
        ( (1 + paramW*paramW) * (1 + paramH*paramH) / (1 + paramW*paramW + paramH*paramH) ) *
        Math.pow( (paramW*paramW * (1 + paramW*paramW + paramH*paramH)) / ((1 + paramW*paramW) * (paramW*paramW + paramH*paramH)), paramW*paramW ) *
        Math.pow( (paramH*paramH * (1 + paramW*paramW + paramH*paramH)) / ((1 + paramH*paramH) * (paramW*paramW + paramH*paramH)), paramH*paramH )
    )
    const term3 = paramW * Math.atan(1/paramW) + paramH * Math.atan(1/paramH) - Math.sqrt(paramW*paramW + paramH*paramH) * Math.atan(1/Math.sqrt(paramW*paramW + paramH*paramH))
    
    return Math.max(0, term1 * (term2 + term3))
}


/**
 * Solves the radiosity equation system iteratively.
 * M_i = E_i + rho_i * sum(F_ij * M_j)
 * Since we deal with initial flux directly from luminaires, E_i (emittance) is 0 for surfaces (they don't glow).
 * Instead, we have initial direct flux Phi_dir_i.
 * The total exitance M_i (lm/m^2) is:
 * M_i = (Phi_dir_i / Area_i) + rho_i * sum(F_ij * M_j)
 * 
 * We solve for M_i (Exitance).
 */
export function solveRadiosity(
  room: RoomConfig,
  initialFluxes: number[], // Array of 6 fluxes (lumens) matching SurfaceType
  iterations: number = 10
): number[] {
  const { width, length, height } = room
  
  // 1. Initialize Surfaces
  const surfaces: Surface[] = []
  const surfaceAreas = [
    width * length, // Floor
    width * length, // Ceiling
    width * height, // North
    width * height, // South
    length * height, // East
    length * height  // West
  ]
  
  const surfaceReflectances = [
    room.floorReflectance,
    room.ceilingReflectance,
    room.wallReflectance,
    room.wallReflectance,
    room.wallReflectance,
    room.wallReflectance
  ]

  // Initialize exitances with direct component
  let exitances = initialFluxes.map((flux, i) => {
     if (surfaceAreas[i] <= 0) return 0
     return (flux / surfaceAreas[i]) * surfaceReflectances[i]
  })
  
  // 2. Pre-calculate Form Factors Matrix F[i][j]
  // F[i][j] is fraction of energy leaving i that hits j
  // Reciprocity rule: A_i * F_ij = A_j * F_ji
  const F: number[][] = Array(6).fill(0).map(() => Array(6).fill(0))
  
  for (let i = 0; i < 6; i++) {
    for (let j = 0; j < 6; j++) {
      if (i === j) continue
      F[i][j] = calculateFormFactor(width, length, height, i, j)
    }
  }
  
  // 3. Iterative Solver
  // M_i^(k+1) = M_i^(0) + rho_i * sum(F_ij * M_j^(k))
  // Where M_i^(0) is the exitance due to direct flux: (Phi_dir_i / A_i) * rho_i
  // Note: Standard radiosity formulation usually separates source emittance.
  // Here surfaces reflect direct flux.
  // M_i = rho_i * (E_direct_i + sum(F_ij * M_j))
  // E_direct_i = Phi_dir_i / A_i
  
  const initialExitance = [...exitances] // Base exitance from direct flux
  
  for (let iter = 0; iter < iterations; iter++) {
    const nextExitances = [...exitances]
    
    for (let i = 0; i < 6; i++) {
      let incomingReflectedFluxDensity = 0
      for (let j = 0; j < 6; j++) {
         // Flux density from j arriving at i: M_j * F_ji ? 
         // Flux leaving j: M_j * A_j
         // Portion hitting i: M_j * A_j * F_ji
         // Flux density at i: (M_j * A_j * F_ji) / A_i
         // Using reciprocity: A_j * F_ji = A_i * F_ij
         // So: (M_j * A_i * F_ij) / A_i = M_j * F_ij
         
         incomingReflectedFluxDensity += exitances[j] * F[i][j]
      }
      
      // Total Exitance = (Direct + Reflected) * Reflectance
      // We already multiplied Direct by reflectance in initialExitance calculation
      nextExitances[i] = initialExitance[i] + surfaceReflectances[i] * incomingReflectedFluxDensity
    }
    
    exitances = nextExitances
  }
  
  return exitances
}

/**
 * Numerically integrate the illuminance produced on the work plane by a
 * diffuse (Lambertian) rectangular surface with uniform luminous exitance M.
 *
 *   E = Σ (L · cosθ_emit · cosθ_recv · dA) / d²
 *
 * where L = M/π (Lambertian luminance), θ_emit is the angle between the
 * surface normal and the ray toward the point, and θ_recv is the angle
 * between the ray and the receiving (horizontal work-plane) normal.
 *
 * This replaces the previous approximate configuration-factor approach with a
 * direct area-source integration that is correct for any of the 6 room faces.
 */
export function integrateSurfaceContribution(
  point: { x: number; y: number; z: number },
  origin: { x: number; y: number; z: number },
  uVec: { x: number; y: number; z: number },
  vVec: { x: number; y: number; z: number },
  normal: { x: number; y: number; z: number },
  exitance: number,
  subdivisions: number = 8,
  receiveNormal: { x: number; y: number; z: number } = { x: 0, y: 1, z: 0 }
): number {
  if (exitance <= 0) return 0

  const L = exitance / Math.PI // Lambertian luminance (cd/m²)

  const uLen = Math.sqrt(uVec.x * uVec.x + uVec.y * uVec.y + uVec.z * uVec.z)
  const vLen = Math.sqrt(vVec.x * vVec.x + vVec.y * vVec.y + vVec.z * vVec.z)
  const patchArea = (uLen * vLen) / (subdivisions * subdivisions)
  if (patchArea <= 0) return 0

  let E = 0

  for (let i = 0; i < subdivisions; i++) {
    for (let j = 0; j < subdivisions; j++) {
      const u = (i + 0.5) / subdivisions
      const v = (j + 0.5) / subdivisions

      const cx = origin.x + uVec.x * u + vVec.x * v
      const cy = origin.y + uVec.y * u + vVec.y * v
      const cz = origin.z + uVec.z * u + vVec.z * v

      const dx = point.x - cx
      const dy = point.y - cy
      const dz = point.z - cz
      const d2 = dx * dx + dy * dy + dz * dz
      if (d2 < 1e-6) continue

      const d = Math.sqrt(d2)
      const dirX = dx / d
      const dirY = dy / d
      const dirZ = dz / d

      // Emission angle: surface normal vs ray toward the point.
      const cosEmit = normal.x * dirX + normal.y * dirY + normal.z * dirZ
      if (cosEmit <= 0) continue

      // Receiving angle: ray vs the receiving surface normal (a front-facing
      // receiver has receiveNormal · dir < 0).
      const cosRecv = -(dirX * receiveNormal.x + dirY * receiveNormal.y + dirZ * receiveNormal.z)
      if (cosRecv <= 0) continue

      E += (L * cosEmit * cosRecv * patchArea) / d2
    }
  }

  return E
}
