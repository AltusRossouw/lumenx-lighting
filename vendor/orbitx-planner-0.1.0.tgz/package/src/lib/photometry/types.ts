/**
 * OrbitX Lighting Planner - Photometry Types
 * 
 * Comprehensive type definitions for the DIALux-inspired lighting calculation engine.
 */

// =============================================================================
// IES Photometric Data
// =============================================================================

/**
 * Complete IES file data with full intensity distribution table.
 * Parsed from IESNA LM-63 format files.
 */
export interface IESData {
  // Metadata
  manufacturer: string
  luminaireCatalog: string
  luminaireDescription: string
  lampCatalog: string
  testLab: string
  issueDate: string
  
  // Physical dimensions (meters)
  width: number
  length: number
  height: number
  
  // Luminous opening dimensions (meters)
  luminousWidth: number
  luminousLength: number
  luminousHeight: number
  
  // Photometric data
  lampCount: number
  lumensPerLamp: number
  candelaMultiplier: number
  inputWatts: number
  ballastFactor: number
  
  // Photometric type: 1=Type C, 2=Type B, 3=Type A
  photometricType: number
  
  // Units: 1=feet, 2=meters
  unitsType: number
  
  // Intensity distribution
  numVerticalAngles: number
  numHorizontalAngles: number
  verticalAngles: number[]      // gamma angles (0-180° typically)
  horizontalAngles: number[]    // C-planes (0-360° typically)
  candelaValues: number[][]     // [horizontalIndex][verticalIndex] in cd/1000lm
  
  // Derived/calculated values
  totalLumens: number
  efficacy: number              // lm/W
  beamAngle: number             // angle at 50% peak intensity
  fieldAngle: number            // angle at 10% peak intensity
  maxCandela: number            // peak intensity value
  
  // Original file URL for reference
  sourceUrl: string
}

/**
 * Simplified IES profile for listing/selection.
 * Used in dropdowns and fixture lists.
 */
export interface IESProfile {
  id: string
  productSlug: string
  productName: string
  variantLabel: string
  url: string
  lumens: number | null
  watts: number | null
  beamAngle: number | null
  efficacy: number | null
}

// =============================================================================
// Room Configuration
// =============================================================================

/**
 * Light loss / maintenance factor breakdown per CIE 97 / EN 12464-1.
 * The total maintenance factor is LLMF × LSF × LMF × RSMF.
 */
export interface MaintenanceFactors {
  /** Lamp Lumen Maintenance Factor — lumen depreciation of the light source. */
  llmf: number
  /** Lamp Survival Factor — fraction of lamps still operating. */
  lsf: number
  /** Luminaire Maintenance Factor — dirt accumulation on the luminaire. */
  lmf: number
  /** Room Surface Maintenance Factor — dirt on room surfaces. */
  rsmf: number
}

/**
 * Room geometry and surface properties.
 */
export interface RoomConfig {
  // Dimensions in meters
  width: number           // X axis
  length: number          // Z axis
  height: number          // Y axis
  
  // Work plane height from floor (meters)
  // Default 0.85m for desk height, 0m for floor
  workPlaneHeight: number
  
  // Surface reflectances (0-1, typically 0-0.9)
  ceilingReflectance: number
  wallReflectance: number
  floorReflectance: number
  
  // Legacy flat maintenance factor (kept for backward compatibility).
  // Prefer `maintenanceFactors` for a proper breakdown.
  maintenanceFactor: number

  // Detailed maintenance factor breakdown. When present, it overrides the
  // flat `maintenanceFactor` (the product is used).
  maintenanceFactors?: MaintenanceFactors

  // Annual operating hours used for LENI (kWh/m²/year). Default 2500 h.
  operatingHours?: number
  
  // Whether to include inter-reflections in calculation
  // When true, adds reflected light from surfaces (more accurate but slower)
  // Default true
  includeReflections: boolean
  
  // Optional: custom name for the room
  name?: string
}

/**
 * Default room configuration values.
 */
export const DEFAULT_ROOM_CONFIG: RoomConfig = {
  width: 8,
  length: 10,
  height: 3.5,
  workPlaneHeight: 0.85,
  ceilingReflectance: 0.7,
  wallReflectance: 0.5,
  floorReflectance: 0.2,
  maintenanceFactor: 0.8,
  includeReflections: true,
  name: 'Untitled Room'
}

// =============================================================================
// Luminaire Instances
// =============================================================================

/**
 * A single luminaire placed in the room.
 */
export interface LuminaireInstance {
  id: string
  
  // Reference to IES profile
  iesProfileId: string
  
  // Position in room coordinates (meters)
  // Origin is room center, Y is up
  position: {
    x: number   // -width/2 to +width/2
    y: number   // mounting height from floor
    z: number   // -length/2 to +length/2
  }
  
  // Rotation angles (degrees)
  rotation: {
    tilt: number        // forward/back tilt (0 = pointing down)
    orientation: number // rotation around Y axis (0 = facing -Z)
    roll: number        // rotation around light axis
  }
  
  // Dimming level (0-1, 1 = full output)
  dimming: number
  
  // Optional: custom label
  label?: string
  
  // Group ID for batch operations
  groupId?: string
}

/**
 * Default luminaire instance values.
 */
export const DEFAULT_LUMINAIRE: Omit<LuminaireInstance, 'id' | 'iesProfileId'> = {
  position: { x: 0, y: 3, z: 0 },
  rotation: { tilt: 0, orientation: 0, roll: 0 },
  dimming: 1.0
}

// =============================================================================
// Calculation Results
// =============================================================================

/**
 * Single calculation point on the work plane grid.
 */
export interface CalculationPoint {
  x: number               // position in room (meters)
  z: number               // position in room (meters)
  illuminance: number     // lux at this point
  
  // Optional: contribution breakdown per luminaire
  contributions?: Map<string, number>
}

/**
 * Grid of calculation results.
 */
export interface CalculationGrid {
  points: CalculationPoint[]
  
  // Grid dimensions
  gridWidth: number       // number of points in X
  gridHeight: number      // number of points in Z
  gridSpacing: number     // meters between points (0.5m default)
  
  // Room reference (for coordinate mapping)
  roomWidth: number
  roomLength: number
  workPlaneHeight: number
}

/**
 * Complete calculation results with all metrics.
 */
export interface CalculationResults {
  // Grid data
  grid: CalculationGrid
  
  // Summary illuminance metrics (lux)
  Emin: number            // minimum illuminance
  Emax: number            // maximum illuminance
  Eavg: number            // average illuminance
  Emedian: number         // median illuminance
  
  // Uniformity ratios
  Uo: number              // Emin/Eavg (overall uniformity)
  Ud: number              // Emin/Emax (diversity ratio)

  // Vertical illuminance on room walls (lux)
  Evavg?: number          // mean vertical illuminance
  Evmin?: number          // minimum vertical illuminance

  // Cylindrical illuminance (lux) — mean vertical illuminance on a small
  // vertical cylinder, used for facial/modelling visibility (EN 12464-1).
  Ezavg?: number          // mean cylindrical illuminance
  Ezmin?: number          // minimum cylindrical illuminance
  
  // Power metrics
  totalPower: number      // total watts
  powerDensity: number    // W/m²
  LENI: number            // Lighting Energy Numeric Indicator (kWh/m²/year)

  // Maintenance factor actually applied to the result.
  maintenanceFactor: number
  
  // Glare (optional, computed separately)
  UGR?: number            // Unified Glare Rating
  UGRPositions?: UGRResult[]
  
  // Luminaire summary
  luminaireCount: number
  totalLumens: number
  
  // Compliance status
  compliance?: ComplianceResult
  
  // Calculation metadata
  calculatedAt: string    // ISO timestamp
  calculationTime: number // milliseconds
}

/**
 * UGR calculation result for a specific observer position.
 */
export interface UGRResult {
  position: { x: number; z: number }
  viewDirection: number   // degrees
  value: number           // UGR value
}

// =============================================================================
// Standards & Compliance
// =============================================================================

/**
 * Requirements for a specific activity type per EN 12464-1.
 */
export interface ActivityRequirements {
  id: string
  name: string
  category: string
  
  // Required maintained illuminance (lux)
  Eavg: number
  
  // Maximum UGR limit
  UGR: number
  
  // Minimum uniformity (Uo = Emin/Eavg)
  Uo: number
  
  // Minimum color rendering index
  Ra: number
  
  // Optional: notes or special requirements
  notes?: string
}

/**
 * Result of compliance checking against requirements.
 */
export interface ComplianceResult {
  activityType: string
  requirements: ActivityRequirements
  
  // Individual checks
  illuminancePass: boolean
  illuminanceValue: number
  illuminanceTarget: number
  
  uniformityPass: boolean
  uniformityValue: number
  uniformityTarget: number
  
  ugrPass: boolean
  ugrValue: number | null
  ugrTarget: number
  
  // Overall status
  overallPass: boolean
  
  // Recommendations for failing metrics
  recommendations: string[]
}

/**
 * Compliance status indicator.
 */
export type ComplianceStatus = 'pass' | 'marginal' | 'fail' | 'unknown'

// =============================================================================
// Project Storage
// =============================================================================

/**
 * Complete project data for save/load.
 */
export interface Project {
  id: string
  name: string
  description?: string
  
  // Timestamps
  createdAt: string       // ISO timestamp
  updatedAt: string       // ISO timestamp
  
  // Configuration
  room: RoomConfig
  luminaires: LuminaireInstance[]
  
  // Standards
  activityType: string
  
  // Cached IES profile IDs used (for re-loading)
  iesProfileIds: string[]
  
  // Last calculation results (optional, can be recalculated)
  lastResults?: CalculationResults
  
  // User notes
  notes?: string
  
  // Thumbnail (base64 encoded PNG, optional)
  thumbnail?: string
}

/**
 * Project list item (for listing without full data).
 */
export interface ProjectListItem {
  id: string
  name: string
  updatedAt: string
  luminaireCount: number
  roomDimensions: string  // e.g., "8m x 10m x 3.5m"
  thumbnail?: string
}

// =============================================================================
// UI State
// =============================================================================

/**
 * Display options for the planner UI.
 */
export interface DisplayOptions {
  showHeatmap: boolean
  showIsolines: boolean
  showValues: boolean
  showFixtures: boolean
  showGrid: boolean
  showDimensions: boolean
  
  // Heatmap settings
  heatmapOpacity: number
  heatmapColorScale: 'dialux' | 'thermal' | 'grayscale'
  
  // Isoline settings
  isolineLevels: number[] // e.g., [100, 200, 300, 500]
  showIsolineLabels: boolean
  
  // Value grid settings
  valueGridDensity: number // show every Nth value
}

/**
 * Default display options.
 */
export const DEFAULT_DISPLAY_OPTIONS: DisplayOptions = {
  showHeatmap: true,
  showIsolines: false,
  showValues: false,
  showFixtures: true,
  showGrid: true,
  showDimensions: true,
  heatmapOpacity: 0.7,
  heatmapColorScale: 'dialux',
  isolineLevels: [100, 200, 300, 500],
  showIsolineLabels: true,
  valueGridDensity: 2
}

/**
 * View mode for the planner.
 */
export type ViewMode = '3d' | '2d'

/**
 * Active tab for mobile/tablet interface.
 */
export type PlannerTab = 'room' | 'fixtures' | 'results' | 'export'

// =============================================================================
// Calculation Worker Messages
// =============================================================================

/**
 * Message sent to the calculation web worker.
 */
export type CalculationWorkerInput = {
  type: 'calculate'
  room: RoomConfig
  luminaires: LuminaireInstance[]
  iesDataMap: Record<string, IESData>
  gridSpacing: number
  calculateUGR: boolean
}

/**
 * Message received from the calculation web worker.
 */
export type CalculationWorkerOutput =
  | { type: 'progress'; percent: number; message?: string }
  | { type: 'complete'; results: CalculationResults }
  | { type: 'error'; message: string }

// =============================================================================
// Utility Types
// =============================================================================

/**
 * 2D point for geometry operations.
 */
export interface Point2D {
  x: number
  z: number
}

/**
 * 3D point for geometry operations.
 */
export interface Point3D {
  x: number
  y: number
  z: number
}

/**
 * Isoline path data for visualization.
 */
export interface IsolinePath {
  level: number           // lux value
  segments: Point2D[][]   // array of line segments
  color: string           // hex color for this level
}

/**
 * Color scale stop for heatmap gradients.
 */
export interface ColorStop {
  position: number        // 0-1
  color: [number, number, number]  // RGB 0-255
}

/**
 * DIALux-style color scale (blue → cyan → green → yellow → red).
 */
export const DIALUX_COLOR_SCALE: ColorStop[] = [
  { position: 0.0, color: [37, 99, 235] },    // blue
  { position: 0.25, color: [34, 211, 238] },  // cyan
  { position: 0.5, color: [34, 197, 94] },    // green
  { position: 0.75, color: [250, 204, 21] },  // yellow
  { position: 1.0, color: [239, 68, 68] }     // red
]

/**
 * Thermal color scale (black → purple → red → yellow → white).
 */
export const THERMAL_COLOR_SCALE: ColorStop[] = [
  { position: 0.0, color: [0, 0, 0] },
  { position: 0.25, color: [128, 0, 128] },
  { position: 0.5, color: [255, 0, 0] },
  { position: 0.75, color: [255, 255, 0] },
  { position: 1.0, color: [255, 255, 255] }
]
