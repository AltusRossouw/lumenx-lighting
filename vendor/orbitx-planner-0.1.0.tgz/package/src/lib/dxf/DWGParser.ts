import { parseDXF } from './DXFParser'

/**
 * Interface for DWG conversion result
 */
export interface DWGImportResult {
  layers: string[]
  entities: any[]
  bounds: {
    min: { x: number, y: number }
    max: { x: number, y: number }
    width: number
    height: number
  }
}

/**
 * Convert and parse a DWG file content
 * 
 * Note: DWG is a proprietary binary format. In a browser environment, 
 * we typically need a server-side converter or a WebAssembly-based converter.
 * 
 * Since we don't have a backend service setup for this in the current scope,
 * and client-side DWG parsing is heavy and complex (often requiring Emscripten builds of LibreDWG),
 * we will implement a mock parser that warns the user or handles specifically formatted input if possible.
 * 
 * However, we installed `@mlightcad/libredwg-converter` which provides WASM bindings.
 * Let's try to use that if it works in the browser.
 */


// Import these types from the data-model package
import type { 
  AcDbDatabase,
} from '@mlightcad/data-model'

// Only import types if possible to avoid bundling issues
// import type { AcDbLibreDwgConverter } from '@mlightcad/libredwg-converter'
// import { AcDbLine, AcDbPolyline, AcDb2dPolyline, AcDb3dPolyline } from '@mlightcad/data-model'

// We will load the WASM module dynamically
// The WASM file should be in public/wasm/libredwg-web.wasm
// and the JS glue code in public/wasm/libredwg-web.js

/**
 * Parses a DWG file buffer using WebAssembly.
 * 
 * @param buffer ArrayBuffer of the DWG file
 * @returns Promise resolving to import result (compatible with DXF structure)
 */
export async function parseDWG(buffer: ArrayBuffer): Promise<DWGImportResult> {
  try {
    // 1. Load the WASM module
    if (typeof window === 'undefined') {
      throw new Error('DWG parsing is only supported in the browser')
    }

    console.log('Initializing DWG converter...')

    // Dynamic loading via script tags to avoid webpack recursive bundle issues
    // We expect the libs to be available in public/libs/
    
    // Helper to load script
    const loadScript = (src: string) => {
        return new Promise<void>((resolve, reject) => {
             // Check if already loaded
             if (document.querySelector(`script[src="${src}"]`)) {
                 resolve();
                 return;
             }
             const script = document.createElement('script')
             script.src = src
             script.onload = () => resolve()
             script.onerror = (e) => reject(new Error(`Failed to load script ${src}`))
             document.body.appendChild(script)
        })
    }
    
    // For data-model, the provided builds in dist/ are:
    // - data-model.js (ESM)
    // - data-model.cjs (CommonJS)
    // It doesn't seem to have a UMD build! 
    // This makes loading it via script tag tricky because CJS needs 'exports' and 'require', and ESM needs <script type="module">
    
    // However, libredwg-converter.umd.js CONFIRMS it expects a global called `VA.dataModel` or requires `@mlightcad/data-model`.
    // The UMD header of libredwg-converter says:
    // v(VA["libredwg-converter"]={},VA.dataModel)
    
    // So if we can't load data-model as UMD, we can't satisfy the global dependency easily unless we bundle it ourselves.
    // BUT, wait. The CJS build might be usable if we define a fake 'exports' and 'module' object before loading it?
    // Or we can try to use the ESM build with type="module" import?
    // But then we can't easily assign it to the global `dataModel` variable that libredwg-converter expects.
    
    // Let's try a "poor man's UMD wrapper" for data-model.cjs
    // We can define a minimal `exports` object on window, load the CJS script, and then assign exports to `window.dataModel`.
    
    // 1. Load data-model
    // Since we don't have a true UMD for data-model, let's try to polyfill the CJS environment
    if (typeof (window as any).exports === 'undefined') {
        (window as any).exports = {};
    }
    
    // We use the CJS file but we need to load it. 
    // Since we renamed it to .js in public (or need to), let's ensure we point to the CJS content.
    // I previously saw data-model.js in public/libs/data-model, which was ESM.
    // Let's use data-model.cjs (renamed to .js if needed or served as is).
    // The server seemed to fail on .cjs extension in script tag? No, it failed on import() of .cjs.
    // Script tag src should work with any extension if server serves it.
    
    await loadScript('/libs/data-model/data-model.cjs')
    
    // After loading CJS, the `exports` object should be populated.
    // We need to move it to `window.dataModel` because libredwg-converter UMD expects `VA.dataModel` (where VA is window).
    // Note: libredwg-converter UMD header: `v(VA["libredwg-converter"]={},VA.dataModel)`
    // So it looks for `window.dataModel`.
    
    if (!(window as any).dataModel && (window as any).exports) {
        (window as any).dataModel = (window as any).exports;
         // Reset exports for next script if needed, though libredwg is UMD and should handle itself
        (window as any).exports = {}; 
    }
    
    // Fallback: if data-model.cjs didn't populate exports (maybe it uses module.exports?), check that too.
    
    // 2. Load libredwg-converter
    await loadScript('/libs/libredwg-converter/libredwg-converter.umd.js')

    // UMD modules usually attach to window. We need to find the names.
    // Based on the file content analysis:
    // libredwg-converter UMD header: `VA["libredwg-converter"]={}`
    
    const DataModel = (window as any).dataModel || (window as any).MlightCaDataModel;
    const LibreDWGConverter = (window as any)['libredwg-converter'] || (window as any).LibreDwgConverter;
    
    // Let's log what we have on window to debug if it fails
    if (!DataModel || !LibreDWGConverter) {
         console.log('Window keys (debug):', Object.keys(window).filter(k => k.toLowerCase().includes('data') || k.toLowerCase().includes('dwg') || k.includes('libredwg')))
    }
    
    if (!DataModel) throw new Error('Failed to load DataModel UMD')
    if (!LibreDWGConverter) throw new Error('Failed to load LibreDWGConverter UMD')

    const { AcDbDatabaseConverterManager, AcDbFileType, AcDbDatabase, AcDbLine, AcDbPolyline, AcDb2dPolyline, AcDb3dPolyline } = DataModel
    const { AcDbLibreDwgConverter } = LibreDWGConverter
    // const libredwgModule = await import('@mlightcad/libredwg-web/wasm/libredwg-web')
    
    // NOTE: The previous import was causing build issues and "module not found" errors.
    // The correct way to load the WASM module factory from the npm package is a bit tricky
    // because it's an Emscripten module.
    
    // We will bypass the node module import for the factory and load it via a script tag
    // approach or use the one we copied to public/wasm if the import fails.
    
    // However, to make the build pass, we need to stop referencing `@mlightcad/libredwg-web` 
    // in a way that webpack tries to bundle its invalid exports.
    
    let libredwgModuleFactory: any;
    
    // Direct script injection approach to avoid Webpack bundling issues with the package
    if (typeof window !== 'undefined') {
        if ((window as any).createModule) {
            libredwgModuleFactory = (window as any).createModule
        } else {
             console.log('Loading libredwg-web.js via script tag...')
             await new Promise<void>((resolve, reject) => {
                 const script = document.createElement('script')
                 script.src = '/wasm/libredwg-web.js'
                 script.onload = () => resolve()
                 script.onerror = (e) => reject(e)
                 document.body.appendChild(script)
             })
             // After loading, the factory should be available globally usually as 'createModule'
             // Check the JS file content if unsure, but standard Emscripten is createModule or similar.
             // Based on package.json build script: -s EXPORT_NAME="createModule"
             // However, the file we read starts with: var createModule = ... export default createModule;
             // If we load it as a script tag, since it's an ES module (export default), it might fail if treated as classic script.
             // But we are not loading it as type="module".
             
             // Wait, the file has `export default createModule` at the end. This is an ES module.
             // Script tag loading without type="module" will fail on `export`.
             // And if we use type="module", it doesn't expose a global.
             
             // Since we have the file in public/wasm/libredwg-web.js, and it IS a module,
             // we should be able to import it directly using dynamic import!
             
             // The previous failure "Module not found" for the import might have been because of the path.
             // Let's try importing the file from public directly via valid URL.
             
             // @ts-ignore
             const mod = await import(/* webpackIgnore: true */ '/wasm/libredwg-web.js')
             libredwgModuleFactory = mod.default
        }
    }
    
    if (!libredwgModuleFactory) {
         // Fallback if somehow we are not in browser or script failed, 
         // though this function guards for window at the top.
         throw new Error('Could not load libredwg-web factory')
    }
    
    if (!libredwgModuleFactory) {
        throw new Error('Could not load libredwg-web factory')
    }
    
    const libredwgModule = await libredwgModuleFactory({
        locateFile: (path: string) => {
            if (path.endsWith('.wasm')) {
                return '/wasm/libredwg-web.wasm'
            }
            return path
        }
    })
    
    // 2. Setup Converter
    const dwgConverter = new AcDbLibreDwgConverter(libredwgModule)
    const manager = AcDbDatabaseConverterManager.instance
    
    // Register if not already registered
    try {
        manager.register(AcDbFileType.DWG, dwgConverter)
    } catch (e) {
        // Ignore if already registered
    }

    // 3. Convert
    const db = new AcDbDatabase()
    // Use the registered converter directly or retrieve it
    const converter = manager.get(AcDbFileType.DWG)
    
    if (!converter) {
        throw new Error('Failed to initialize DWG converter')
    }

    // convert/read the data
    await converter.read(buffer, db, 100)

    // 4. Extract entities
    // We already imported these classes
    return extractEntitiesFromDB(db, { AcDbLine, AcDbPolyline, AcDb2dPolyline, AcDb3dPolyline })

  } catch (error) {
    console.error('DWG Parse Error:', error)
    throw new Error(`Failed to parse DWG: ${(error as Error).message}`)
  }
}

/**
 * Extracts entities from the converted AcDbDatabase
 */
function extractEntitiesFromDB(db: AcDbDatabase, classes: any): DWGImportResult {
    const { AcDbLine, AcDbPolyline, AcDb2dPolyline, AcDb3dPolyline } = classes
    const layers = new Set<string>()
    const entities: any[] = [] // Using any to match DXFEntity structure
    
    let minX = Infinity, minY = Infinity
    let maxX = -Infinity, maxY = -Infinity

    // Iterate through model space entities
    const blockTable = db.tables.blockTable
    const modelSpace = blockTable.modelSpace
    const iterator = modelSpace.newIterator()
    
    let result = iterator.next()
    while (!result.done) {
        const entity = result.value as any
        
        // Add layer
        if (entity.layer) {
            layers.add(entity.layer)
        }

        let vertices: {x: number, y: number}[] = []
        let type = entity.type

        // Extract geometry based on type
        // Note: AcDbEntity.type returns the class name without 'AcDb' prefix (e.g. 'Line', 'Polyline')
        // DXF parser usually returns UPPERCASE types (LINE, LWPOLYLINE)
        
        if (entity instanceof AcDbLine) {
            type = 'LINE'
            const start = entity.startPoint
            const end = entity.endPoint
            vertices = [
                { x: start.x, y: start.y },
                { x: end.x, y: end.y }
            ]
        } else if (entity instanceof AcDbPolyline) {
            type = 'LWPOLYLINE' // Standard polyline is usually LWPOLYLINE in DXF terms
            const count = entity.numberOfVertices
            for (let i = 0; i < count; i++) {
                const pt = entity.getPoint2dAt(i)
                vertices.push({ x: pt.x, y: pt.y })
            }
            // If closed, we might want to ensure the loop is complete for some renderers, 
            // but standard DXF entities usually imply it via a flag.
            // Our DXF parser just returns vertices.
        } else if (entity instanceof AcDb2dPolyline) {
            type = 'POLYLINE'
            // AcDb2dPolyline uses AcDb2dVertex entities.
            // We need to iterate its vertices? 
            // The API reference for AcDb2dPolyline didn't show a simple getPointAt method,
            // but let's check if it behaves like a curve or we need to access vertices differently.
            // It inherits from AcDbCurve.
            // Actually, for legacy 2d polylines, vertices are often separate entities following the polyline.
            // But the library might abstract this.
            // Looking at the d.ts, it seems to have `subGetGripPoints()` which returns all vertices.
            const grips = entity.subGetGripPoints()
            vertices = grips.map((g: any) => ({ x: g.x, y: g.y }))
        } else if (entity instanceof AcDb3dPolyline) {
            type = 'POLYLINE' // 3D polyline
            const grips = entity.subGetGripPoints()
            vertices = grips.map((g: any) => ({ x: g.x, y: g.y }))
        }

        // Only add if we extracted valid geometry
        if (vertices.length > 0) {
            // Update bounds
            for (const v of vertices) {
                minX = Math.min(minX, v.x)
                minY = Math.min(minY, v.y)
                maxX = Math.max(maxX, v.x)
                maxY = Math.max(maxY, v.y)
            }

            entities.push({
                type,
                layer: entity.layer,
                vertices
            })
        }
        
        result = iterator.next()
    }

    // Handle empty file case
    if (minX === Infinity) {
        minX = 0; minY = 0; maxX = 0; maxY = 0
    }

    return {
        layers: Array.from(layers).sort(),
        entities,
        bounds: {
            min: { x: minX, y: minY },
            max: { x: maxX, y: maxY },
            width: maxX - minX,
            height: maxY - minY
        }
    }
}



/**
 * Validates if a file is a DWG based on magic bytes
 */
export function isDWG(buffer: ArrayBuffer): boolean {
  const view = new DataView(buffer)
  // Check for 'AC' signature (AutoCAD)
  // DWG files start with AC10xx
  if (view.byteLength < 6) return false
  
  const signature = String.fromCharCode(
    view.getUint8(0),
    view.getUint8(1)
  )
  
  return signature === 'AC'
}
