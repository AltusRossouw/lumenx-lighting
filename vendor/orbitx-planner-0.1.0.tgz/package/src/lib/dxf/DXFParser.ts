/**
 * OrbitX Lighting Planner - DXF Import Utility
 * 
 * Handles parsing and extraction of room geometry from DXF files.
 */

import DxfParser from 'dxf-parser'

export interface DXFImportResult {
  layers: string[]
  entities: DXFEntity[]
  bounds: {
    min: { x: number, y: number }
    max: { x: number, y: number }
    width: number
    height: number
  }
}

export interface DXFEntity {
  type: string
  layer: string
  vertices?: { x: number, y: number }[]
  // Add other properties as needed
}

/**
 * Parse a DXF file content string.
 */
export function parseDXF(dxfContent: string): DXFImportResult {
  const parser = new DxfParser()
  let dxf
  
  try {
    dxf = parser.parseSync(dxfContent)
  } catch (err) {
    console.error('DXF parse error:', err)
    throw new Error('Failed to parse DXF file')
  }
  
  const layers = new Set<string>()
  const entities: DXFEntity[] = []
  
  let minX = Infinity, minY = Infinity
  let maxX = -Infinity, maxY = -Infinity
  
  if (dxf && dxf.entities) {
    for (const entity of dxf.entities) {
      if (entity.layer) {
        layers.add(entity.layer)
      }
      
      // Extract geometry based on entity type
      // We are primarily interested in LWPOLYLINE, LINE, POLYLINE for walls
      
      if (entity.type === 'LWPOLYLINE' || entity.type === 'POLYLINE') {
        // Cast to any to access properties that might not be in the type definition but are in the object
        const poly = entity as any
        const vertices = poly.vertices ? poly.vertices.map((v: any) => ({ x: v.x, y: v.y })) : []
        
        // Update bounds
        for (const v of vertices) {
          minX = Math.min(minX, v.x)
          minY = Math.min(minY, v.y)
          maxX = Math.max(maxX, v.x)
          maxY = Math.max(maxY, v.y)
        }
        
        entities.push({
          type: entity.type,
          layer: entity.layer,
          vertices
        })
      } else if (entity.type === 'LINE') {
        const line = entity as any
        const vertices = [
            { x: line.vertices[0].x, y: line.vertices[0].y },
            { x: line.vertices[1].x, y: line.vertices[1].y }
        ]

        
        // Update bounds
        for (const v of vertices) {
            minX = Math.min(minX, v.x)
            minY = Math.min(minY, v.y)
            maxX = Math.max(maxX, v.x)
            maxY = Math.max(maxY, v.y)
        }

        entities.push({
            type: entity.type,
            layer: entity.layer,
            vertices
        })
      }
    }
  }
  
  // Handle empty file case
  if (minX === Infinity) {
    minX = 0; minY = 0; maxX = 0; maxY = 0
  }
  
  return {
    layers: Array.from(layers).sort(),
    entities,
    bounds: {
      min: { x: minX, y: minY },
      max: { x: maxX, y: maxY },
      width: maxX - minX,
      height: maxY - minY
    }
  }
}
