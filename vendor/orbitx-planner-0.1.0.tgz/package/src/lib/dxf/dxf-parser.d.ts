declare module 'dxf-parser' {
  export interface DxfEntity {
    type: string
    layer: string
    vertices?: { x: number; y: number; z?: number }[]
    // Add other properties as needed
    [key: string]: any
  }

  export interface DxfObject {
    entities: DxfEntity[]
    header: any
    tables: any
    blocks: any
  }

  export default class DxfParser {
    parseSync(source: string): DxfObject
  }
}
