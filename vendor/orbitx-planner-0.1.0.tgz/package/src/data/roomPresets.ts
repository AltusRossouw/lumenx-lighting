/**
 * OrbitX Lighting Planner - Room Presets
 * 
 * Common room configurations for quick setup.
 * Each preset includes dimensions and a suggested activity type.
 */

export interface RoomPreset {
  id: string
  name: string
  description: string
  icon: string
  width: number      // meters
  length: number     // meters
  height: number     // meters
  workPlaneHeight: number  // meters
  activityType: string
  // Typical reflectances for this room type
  ceilingReflectance: number
  wallReflectance: number
  floorReflectance: number
}

export const ROOM_PRESETS: RoomPreset[] = [
  {
    id: 'small-office',
    name: 'Small Office',
    description: 'Private office or meeting room for 2-4 people',
    icon: 'briefcase',
    width: 4,
    length: 5,
    height: 2.7,
    workPlaneHeight: 0.85,
    activityType: 'office-general',
    ceilingReflectance: 0.7,
    wallReflectance: 0.5,
    floorReflectance: 0.2
  },
  {
    id: 'open-plan',
    name: 'Open Plan Office',
    description: 'Large open workspace for 20+ people',
    icon: 'users',
    width: 12,
    length: 15,
    height: 3,
    workPlaneHeight: 0.85,
    activityType: 'office-general',
    ceilingReflectance: 0.7,
    wallReflectance: 0.5,
    floorReflectance: 0.2
  },
  {
    id: 'warehouse',
    name: 'Warehouse Bay',
    description: 'Industrial storage or distribution area',
    icon: 'warehouse',
    width: 20,
    length: 15,
    height: 8,
    workPlaneHeight: 0,  // Floor level for warehouses
    activityType: 'warehouse-active',
    ceilingReflectance: 0.5,
    wallReflectance: 0.3,
    floorReflectance: 0.2
  },
  {
    id: 'corridor',
    name: 'Corridor',
    description: 'Hallway or circulation area',
    icon: 'move-horizontal',
    width: 2.5,
    length: 15,
    height: 2.7,
    workPlaneHeight: 0,  // Floor level
    activityType: 'circulation',
    ceilingReflectance: 0.7,
    wallReflectance: 0.5,
    floorReflectance: 0.2
  },
  {
    id: 'classroom',
    name: 'Classroom',
    description: 'Educational space for 25-30 students',
    icon: 'graduation-cap',
    width: 8,
    length: 10,
    height: 3,
    workPlaneHeight: 0.85,
    activityType: 'educational-classroom',
    ceilingReflectance: 0.7,
    wallReflectance: 0.5,
    floorReflectance: 0.2
  },
  {
    id: 'retail',
    name: 'Retail Store',
    description: 'Shop floor or showroom',
    icon: 'shopping-bag',
    width: 10,
    length: 12,
    height: 4,
    workPlaneHeight: 0.85,
    activityType: 'retail-general',
    ceilingReflectance: 0.7,
    wallReflectance: 0.5,
    floorReflectance: 0.3
  },
  {
    id: 'workshop',
    name: 'Workshop',
    description: 'Manufacturing or assembly area',
    icon: 'wrench',
    width: 15,
    length: 20,
    height: 5,
    workPlaneHeight: 0.85,
    activityType: 'production-general',
    ceilingReflectance: 0.5,
    wallReflectance: 0.3,
    floorReflectance: 0.2
  },
  {
    id: 'parking',
    name: 'Parking Garage',
    description: 'Covered parking area',
    icon: 'car',
    width: 25,
    length: 30,
    height: 2.8,
    workPlaneHeight: 0,
    activityType: 'parking',
    ceilingReflectance: 0.5,
    wallReflectance: 0.3,
    floorReflectance: 0.2
  }
]

/**
 * Get a room preset by ID.
 */
export function getRoomPreset(id: string): RoomPreset | undefined {
  return ROOM_PRESETS.find(preset => preset.id === id)
}

/**
 * Get presets grouped by category.
 */
export function getPresetsByCategory(): { category: string; presets: RoomPreset[] }[] {
  return [
    {
      category: 'Office',
      presets: ROOM_PRESETS.filter(p => ['small-office', 'open-plan'].includes(p.id))
    },
    {
      category: 'Industrial',
      presets: ROOM_PRESETS.filter(p => ['warehouse', 'workshop', 'parking'].includes(p.id))
    },
    {
      category: 'Commercial',
      presets: ROOM_PRESETS.filter(p => ['retail', 'corridor'].includes(p.id))
    },
    {
      category: 'Educational',
      presets: ROOM_PRESETS.filter(p => ['classroom'].includes(p.id))
    }
  ]
}
