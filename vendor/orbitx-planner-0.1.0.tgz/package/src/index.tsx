'use client'

import React, { lazy, Suspense } from 'react'
import ConsumerPlanner from './components/ConsumerPlanner'

// Lazy-load the heavyweight Pro edition (and its zustand/dxf/three deps) so that
// simply importing this package for the Consumer edition does NOT pull those into
// the initial module graph. Keeps the eager graph small and bundler-friendly.
const ProPlanner = lazy(() => import('./components/ProPlanner'))

export type LightingPlannerProps = {
  /** Which edition to render. */
  variant?: 'consumer' | 'pro'
  /** Href for the "Pro edition" link on the Consumer edition. */
  proHref?: string
  /** Href for the "Contact" / help link (Consumer edition). */
  contactHref?: string
  /** Href for the "Back to home" link (Pro edition). */
  homeHref?: string
  /** Accent colour (any valid CSS colour), defaults to the OrbitX blue #0084ff. */
  accent?: string
  /** Optional className applied to the root wrapper. */
  className?: string
}

/**
 * OrbitX Lighting Planner.
 *
 * Self-contained, framework-agnostic planner. Import `@orbitx/planner/planner.css`
 * once in your app root to load the bundled styles.
 */
export function LightingPlanner({
  variant = 'consumer',
  proHref = '#pro-edition',
  contactHref = '#contact',
  homeHref = '#',
  accent = '#0084ff',
  className,
}: LightingPlannerProps) {
  const style = { '--op-accent': accent } as React.CSSProperties

  if (variant === 'pro') {
    return (
      <div className={className} style={style}>
        <Suspense fallback={<div className="h-screen flex items-center justify-center bg-gray-100">Loading planner…</div>}>
          <ProPlanner homeHref={homeHref} />
        </Suspense>
      </div>
    )
  }

  return (
    <div className={className} style={style}>
      <ConsumerPlanner proHref={proHref} contactHref={contactHref} />
    </div>
  )
}

export default LightingPlanner

export { ConsumerPlanner }

// Advanced/heavy exports live at '@orbitx/planner/planner' (see src/planner.ts) so
// importing this root entry stays light and doesn't pull zustand/dxf/three.
