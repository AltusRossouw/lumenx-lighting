# @orbitx/planner

OrbitX Lighting Planner — a **self-contained, framework-agnostic** React package
(Consumer + Pro editions) extracted from the OrbitX site so it can be dropped into
any **Next.js or Vite** app. It ships its own theme-agnostic stylesheet and does
**not** depend on the host's Tailwind, font, or OrbitX brand.

## What's inside

- **`<LightingPlanner variant="consumer" | "pro" />`** — the single public entry.
  The **root entry stays light**: it eagerly ships only the Consumer edition and
  lazily loads the Pro edition. The full component library, Zustand store,
  calculation hooks and 3D viewer live at the advanced subpath
  **`@orbitx/planner/planner`**.
- The full photometry engine (`src/lib/photometry`), DXF/DWG CAD import (`src/lib/dxf`),
  the Zustand planner store, project persistence (IndexedDB), PDF export, and a lazy
  WebGL 3D viewer.
- A pre-built stylesheet (`dist/planner.css`) generated from the package's own
  Tailwind config. The accent is exposed as `--op-accent` (override via the `accent` prop).
- No `next/*` imports — pure React, so it works in Vite too. Background photometry
  runs in a Web Worker when available and falls back to the main thread otherwise.

## Props

| Prop | Type | Default | Purpose |
|------|------|---------|---------|
| `variant` | `'consumer' \| 'pro'` | `'consumer'` | Which edition to render |
| `accent` | `string` (CSS colour) | `#0084ff` | Overrides the accent via `--op-accent` |
| `proHref` | `string` | `'#pro-edition'` | Consumer → Pro link destination |
| `contactHref` | `string` | `'#contact'` | Consumer help/contact link destination |
| `homeHref` | `string` | `'#'` | Pro "back to home" link destination |

```tsx
import { Suspense } from 'react'
import { LightingPlanner } from '@orbitx/planner'
import '@orbitx/planner/planner.css'   // once, at app root

<Suspense fallback={<div>Loading…</div>}>
  <LightingPlanner variant="pro" accent="#00d4ff" />
</Suspense>
```

## Consuming in Next.js (live dev)

The package ships **source** plus `transpilePackages` support, so you can symlink it
and hot-reload like any local package:

```bash
# sibling-folder example; `file:` symlinks the package
npm install @orbitx/planner@file:../Orbitx-Planner
```

Then in `next.config.js`:

```js
const nextConfig = { transpilePackages: ['@orbitx/planner'], /* ... */ }
```

Import `@orbitx/planner/planner.css` once in `app/layout.tsx`. Because `file:`
symlinks, the package resolves its deps from its **own `node_modules`** — keep a
checkout of this repo with `npm install` run inside it, and keep the host's
`@types/*` aligned with this repo's dev pins (`@types/three@0.182.0`,
`@types/react@19.2.8`, `@types/react-dom@19.2.3`).

## Consuming in Vite

Install it as a normal dependency (a `github:` url installs a real folder, so deps
resolve as singletons) and transform the source:

```bash
npm install @orbitx/planner@github:AltusRossouw/Orbitx-Planner
```

```ts
// vite.config.ts
import react from '@vitejs/plugin-react'
export default defineConfig({
  plugins: [react()],
  optimizeDeps: { include: ['@orbitx/planner'] },   // transform the TS source
  build: {
    rollupOptions: { external: [/^\/wasm\//] },     // DWG WASM loads at runtime
  },
})
```

Import `@orbitx/planner/planner.css` once (e.g. in `App.tsx`) and render `<LightingPlanner />`.

## Host requirements

- **IES data:** the Consumer edition calls `fetch('/api/ies')`; the host must expose it
  (returning `{ "profiles": [...] }`) or supply IES data via the store. Hosts without
  that endpoint still get the room/layout planner, just no per-fixture IES photometry.
- **DWG/DXF:** CAD import needs `@mlightcad/libredwg-converter` (a `dependency`, so it
  installs with the package) and expects `/wasm/libredwg-web.js|.wasm` in `public/wasm/`;
  if absent, DWG import simply won't work (DXF still does).
- **Peer deps:** `react`, `react-dom` (the package bundles/uses the host's React).

## Publishing (production, optional)

For versioned updates in deployed rigs, publish to a private registry / GitHub
Packages and install the published version (`@orbitx/planner@<version>`); consumers
then update via `npm update`. For local dev, prefer the `file:`/`github:` link above.
